# App-specific R8 rules.
# Library consumer rules are merged automatically by AGP (the mechanism the
# old hand-rolled pipeline lacked). The rules below are added on top.

# Our own code: referenced from the manifest and inflated from layout XML
# (SixBottomNavigationView), so keep it whole.
-keep class com.madrasarecord.app.** { *; }

# Firebase component registrars are instantiated reflectively by
# ComponentDiscovery (their class names come from manifest meta-data), so
# guarantee every registrar keeps its public constructor; getComponents()
# is additionally protected by firebase-components' own consumer rules.
-keep class * implements com.google.firebase.components.ComponentRegistrar {
    public <init>();
}

-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod
