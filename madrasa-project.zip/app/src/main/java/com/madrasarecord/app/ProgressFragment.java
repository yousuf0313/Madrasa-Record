package com.madrasarecord.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

// قرآنی پیش رفت (v1.2.0, approved preview): one card per ACTIVE
// student. Standing progress lives on the student doc — موجودہ سپارہ
// (currentPara), سبق کہاں ہے (sabaqPlace), سبقی (sabqi), مقدار
// خواندگی (dailyAmount) and the standing منزل کا پارہ (manzilPara).
// The day's منزل lives in madrasa_manzil, doc "<studentId>_<date>",
// fields para + status ("sunai"/"nahi") — the card's para selector
// shows the day record's para when one exists, else the standing
// manzilPara; picking a para saves the standing field and updates
// the day record when one exists; tapping the active status chip
// clears the status (the para stays). Selectors save on pick; text
// fields save on focus loss. BOTH roles can mark (equal powers).
public class ProgressFragment extends BaseFragment {
    private String date;
    private String lang = "ur";
    private final List<Db.Student> students = new ArrayList<>();
    private final List<Db.Student> shown = new ArrayList<>();
    private final Map<String, ManzilRec> manzil = new HashMap<>(); // sid -> record for `date`
    private SectionFilter sectionFilter;
    private Adapter adapter;
    private TextView chipSunai, chipNahi, hijriTv, emptyTv;
    private Button dateBtn;
    private List<String> paraItems;

    private static final class ManzilRec { Integer para; String status; }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup c, @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_progress, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle b) {
        super.onViewCreated(view, b);
        lang = Ui.lang(requireContext());
        date = Db.today();
        dateBtn = view.findViewById(R.id.progressDateBtn);
        hijriTv = view.findViewById(R.id.progressHijri);
        chipSunai = view.findViewById(R.id.progChipSunai);
        chipNahi = view.findViewById(R.id.progChipNahi);
        emptyTv = view.findViewById(R.id.progressEmpty);
        paraItems = new ArrayList<>();
        paraItems.add(getString(R.string.prog_not_set));
        for (int n = 1; n <= 30; n++) paraItems.add(Ui.latinDigits(getString(R.string.prog_para_word) + " " + n));
        sectionFilter = new SectionFilter(requireContext(),
                view.findViewById(R.id.progressSectionRow), f -> refresh());
        dateBtn.setOnClickListener(v -> pickDate());
        view.findViewById(R.id.progressHijriFix).setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        hijriTv.setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        Button add = view.findViewById(R.id.progressAddStudent);
        add.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        add.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        RecyclerView list = view.findViewById(R.id.progressList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        refreshHeader();
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void refreshHeader() {
        dateBtn.setText(Hijri.gregorianShort(date, lang) + "  ▾");
        hijriTv.setText(Hijri.format(date, lang));
    }

    private void pickDate() {
        java.time.LocalDate cur = java.time.LocalDate.parse(date);
        new DatePickerDialog(requireContext(), (v, y, m, d) -> {
            date = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refreshHeader();
            load();
        }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (!s.graduated) students.add(s);
            }
            Db.assignSerials(students);
            Db.sortBySerial(students);
            Db.fs().collection(Db.MANZIL).whereEqualTo("date", date).get()
                    .addOnSuccessListener(qs -> {
                        manzil.clear();
                        if (qs != null) {
                            for (DocumentSnapshot d : qs.getDocuments()) {
                                Object sid = d.get("studentId");
                                if (sid == null) continue;
                                ManzilRec r = new ManzilRec();
                                Object p = d.get("para");
                                r.para = p instanceof Number ? ((Number) p).intValue() : null;
                                Object st = d.get("status");
                                r.status = st instanceof String ? (String) st : null;
                                manzil.put(String.valueOf(sid), r);
                            }
                        }
                        refresh();
                    })
                    .addOnFailureListener(e -> refresh());
        });
    }

    private void refresh() {
        shown.clear();
        shown.addAll(SectionFilter.apply(students,
                sectionFilter == null ? SectionFilter.ALL : sectionFilter.current()));
        boolean filterActive = sectionFilter != null && !SectionFilter.ALL.equals(sectionFilter.current());
        emptyTv.setText(filterActive && !students.isEmpty()
                ? R.string.no_students_section : R.string.no_students_msg);
        emptyTv.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        int sunai = 0, nahi = 0;
        for (Db.Student s : shown) {
            ManzilRec r = manzil.get(s.id);
            if (r == null) continue;
            if (Db.MANZIL_SUNAI.equals(r.status)) sunai++;
            else if (Db.MANZIL_NAHI.equals(r.status)) nahi++;
        }
        chipSunai.setText(getString(R.string.manzil_sunai) + ": " + sunai);
        chipNahi.setText(getString(R.string.manzil_nahi) + ": " + nahi);
        applyFonts(getView());
    }

    // The para a card shows for the manzil selector: the day record's
    // para when a record exists, else the standing manzilPara.
    private Integer shownManzilPara(Db.Student s) {
        ManzilRec r = manzil.get(s.id);
        return r != null && r.para != null ? r.para : s.manzilPara;
    }

    private void pickCurrentPara(Db.Student s, Integer val) {
        if (Objects.equals(val, s.currentPara)) return;
        s.currentPara = val;
        Db.saveStudentField(s.id, "currentPara", val == null ? null : (long) val);
    }

    private void pickManzilPara(Db.Student s, Integer val) {
        if (Objects.equals(val, shownManzilPara(s))) return;
        s.manzilPara = val;
        Db.saveStudentField(s.id, "manzilPara", val == null ? null : (long) val);
        ManzilRec r = manzil.get(s.id);
        if (r != null) {
            r.para = val;
            Db.saveManzil(s.id, date, r.para, r.status);
            if (r.para == null && r.status == null) manzil.remove(s.id);
            adapter.notifyDataSetChanged(); // the «منزل — سپارہ N» label follows
        }
    }

    private void toggleManzil(Db.Student s, String value) {
        if (!MadrasaApp.get().canMark()) return;
        ManzilRec r = manzil.get(s.id);
        String cur = r == null ? null : r.status;
        String next = value.equals(cur) ? null : value;
        Integer para = r != null && r.para != null ? r.para : s.manzilPara;
        if (next == null && para == null) {
            manzil.remove(s.id);
        } else {
            ManzilRec nr = new ManzilRec();
            nr.para = para;
            nr.status = next;
            manzil.put(s.id, nr);
        }
        Db.saveManzil(s.id, date, para, next);
        refresh();
    }

    private void saveText(Db.Student s, String field, String value) {
        String cur = "sabaqPlace".equals(field) ? s.sabaqPlace
                : "sabqi".equals(field) ? s.sabqi : s.dailyAmount;
        if (value.equals(cur)) return;
        if ("sabaqPlace".equals(field)) s.sabaqPlace = value;
        else if ("sabqi".equals(field)) s.sabqi = value;
        else s.dailyAmount = value;
        Db.saveStudentField(s.id, field, value.isEmpty() ? null : value);
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_progress_card, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = shown.get(position);
            h.name.setText(s.name);
            h.father.setText(s.fatherName);
            Ui.fitOneLine(h.name, 13.5f, 8f);
            Ui.fitOneLine(h.father, 12.5f, 8f);
            h.name.setOnClickListener(v -> openStudent(s));
            h.father.setOnClickListener(v -> openStudent(s));

            bindParaSpinner(h.paraSpinner, s.currentPara, val -> pickCurrentPara(s, val));
            bindParaSpinner(h.manzilSpinner, shownManzilPara(s), val -> pickManzilPara(s, val));

            bindText(h.sabaqPlaceEt, s.sabaqPlace, v -> saveText(s, "sabaqPlace", v));
            bindText(h.sabqiEt, s.sabqi, v -> saveText(s, "sabqi", v));
            bindText(h.amountEt, s.dailyAmount, v -> saveText(s, "dailyAmount", v));

            Integer mp = shownManzilPara(s);
            h.manzilLbl.setText(getString(R.string.prog_manzil) + (mp != null
                    ? " — " + Ui.latinDigits(getString(R.string.prog_para_word) + " " + mp) : ""));
            ManzilRec r = manzil.get(s.id);
            String status = r == null ? null : r.status;
            bindChip(h.sunaiChip, Db.MANZIL_SUNAI.equals(status), R.drawable.bg_status_on_time, R.color.green_c,
                    v -> toggleManzil(s, Db.MANZIL_SUNAI));
            bindChip(h.nahiChip, Db.MANZIL_NAHI.equals(status), R.drawable.bg_status_none, R.color.red_c,
                    v -> toggleManzil(s, Db.MANZIL_NAHI));
            Ui.applyFont(h.itemView, requireContext());
        }

        private interface ParaPick { void onPick(Integer val); }

        private void bindParaSpinner(Spinner spinner, Integer current, ParaPick pick) {
            ArrayAdapter<String> aa = new ArrayAdapter<>(spinner.getContext(),
                    android.R.layout.simple_spinner_item, paraItems);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setOnItemSelectedListener(null);
            spinner.setAdapter(aa);
            spinner.setSelection(current == null ? 0 : current);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    pick.onPick(pos == 0 ? null : pos);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) { }
            });
            Ui.applyFont(spinner, spinner.getContext());
        }

        private interface TextSave { void onSave(String value); }

        private void bindText(EditText et, String current, TextSave save) {
            et.setOnFocusChangeListener(null);
            if (!current.equals(et.getText().toString())) et.setText(current);
            et.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) save.onSave(et.getText().toString().trim());
            });
        }

        private void bindChip(TextView chip, boolean active, int activeBg, int activeColor, View.OnClickListener tap) {
            chip.setBackgroundResource(active ? activeBg : R.drawable.bg_status_off);
            chip.setTextColor(getResources().getColor(active ? activeColor : R.color.muted, null));
            boolean canMark = MadrasaApp.get().canMark();
            chip.setOnClickListener(canMark ? tap : null);
            chip.setClickable(canMark);
        }

        @Override
        public int getItemCount() { return shown.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, father, manzilLbl, sunaiChip, nahiChip;
            Spinner paraSpinner, manzilSpinner;
            EditText sabaqPlaceEt, sabqiEt, amountEt;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.progName);
                father = v.findViewById(R.id.progFather);
                paraSpinner = v.findViewById(R.id.progParaSpinner);
                manzilSpinner = v.findViewById(R.id.progManzilSpinner);
                sabaqPlaceEt = v.findViewById(R.id.progSabaqPlaceEt);
                sabqiEt = v.findViewById(R.id.progSabqiEt);
                amountEt = v.findViewById(R.id.progAmountEt);
                manzilLbl = v.findViewById(R.id.progManzilLbl);
                sunaiChip = v.findViewById(R.id.progSunaiChip);
                nahiChip = v.findViewById(R.id.progNahiChip);
            }
        }
    }

    private void openStudent(Db.Student s) {
        Intent i = new Intent(getContext(), StudentDetailActivity.class);
        i.putExtra("studentId", s.id);
        i.putExtra("serial", s.serial);
        startActivity(i);
    }
}
