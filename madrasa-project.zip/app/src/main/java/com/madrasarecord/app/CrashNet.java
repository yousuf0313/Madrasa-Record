package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.ScrollView;
import android.widget.TextView;

// Last-crash safety net (v1.0.5): MadrasaApp installs a default
// uncaught-exception handler that records {exception class, message,
// top stack frames, app version, timestamp} to SharedPreferences and
// then delegates to the previous handler (the process still dies the
// usual way — nothing is swallowed). On the next launch, SplashActivity
// shows the saved crash in a scrollable dialog so the exact cause can
// be read off the phone instead of guessed. Every method here is fully
// wrapped: the net itself must never be able to crash the app.
public final class CrashNet {
    private static final String PREFS = "crash_prefs";
    private static final String KEY_TEXT = "last_crash_text";

    private static boolean installed;

    private CrashNet() {}

    public static void install(Context appCtx) {
        try {
            if (installed) return;
            installed = true;
            final Context app = appCtx.getApplicationContext();
            final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((thread, e) -> {
                try {
                    save(app, e);
                } catch (Throwable ignored) {
                    // The net must never interfere with the normal crash path.
                }
                if (prev != null) {
                    prev.uncaughtException(thread, e);
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static void save(Context app, Throwable e) {
        StringBuilder sb = new StringBuilder();
        try {
            String version = "?";
            try {
                version = app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName;
            } catch (Exception ignored) {
            }
            sb.append("Version: ").append(version).append('\n');
            sb.append("Time: ").append(new java.util.Date().toString()).append('\n');
            sb.append("Android: ").append(Build.VERSION.RELEASE)
                    .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
            Throwable t = e;
            int depth = 0;
            while (t != null && depth < 4) {
                sb.append('\n').append(t.getClass().getName()).append(": ")
                        .append(String.valueOf(t.getMessage())).append('\n');
                StackTraceElement[] st = t.getStackTrace();
                int n = Math.min(st == null ? 0 : st.length, 14);
                for (int i = 0; i < n; i++) sb.append("  at ").append(st[i]).append('\n');
                t = t.getCause();
                depth++;
            }
        } catch (Throwable ignored) {
        }
        try {
            // commit() (synchronous) — the process is about to die, apply()
            // could lose the record.
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_TEXT, sb.toString()).commit();
        } catch (Throwable ignored) {
        }
    }

    /** Returns the saved crash text, or null when there is none. */
    public static String peek(Context ctx) {
        try {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String s = p.getString(KEY_TEXT, null);
            return (s == null || s.trim().isEmpty()) ? null : s;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static void clear(Context ctx) {
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_TEXT).commit();
        } catch (Throwable ignored) {
        }
    }

    /** Shows the saved-crash dialog; runs {@code proceed} when dismissed. */
    public static void showSavedCrash(Context ctx, String text, Runnable proceed) {
        try {
            TextView tv = new TextView(ctx);
            tv.setText(text);
            tv.setTextSize(13);
            tv.setPadding(48, 32, 48, 16);
            tv.setTextIsSelectable(true);
            ScrollView sv = new ScrollView(ctx);
            sv.addView(tv);
            new AlertDialog.Builder(ctx)
                    .setTitle(R.string.crash_title)
                    .setView(sv)
                    .setPositiveButton(R.string.crash_continue, (d, w) -> { if (proceed != null) proceed.run(); })
                    .setOnCancelListener(d -> { if (proceed != null) proceed.run(); })
                    .show();
        } catch (Throwable ignored) {
            if (proceed != null) proceed.run();
        }
    }
}
