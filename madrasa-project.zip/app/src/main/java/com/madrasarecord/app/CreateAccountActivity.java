package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

// «نیا اکاؤنٹ بنائیں» (v1.1.0) — from the login screen, for when the old
// account is completely forgotten. Creates a NEW teacher account (name,
// mobile, password, recovery code, madrasa name) and signs in with it
// immediately. Students and all records stay exactly as they are: this
// only adds a user doc — and, when a madrasa name is typed, updates the
// config's madrasaName via merge (owner fields are never touched).
//
// The account is created through a secondary FirebaseApp (the
// UsersActivity pattern) so the flow never depends on the signed-out
// main auth instance; afterwards the main auth signs in normally.
public class CreateAccountActivity extends BaseActivity {
    private TextInputEditText nameIn, emailIn, passIn, recoveryIn, madrasaIn;
    private TextView errorTv;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        ((TextView) findViewById(R.id.authTitle)).setText(R.string.create_account_title);
        ((TextView) findViewById(R.id.authSubtitle)).setText(R.string.create_account_sub);
        ((TextInputLayout) findViewById(R.id.nameBox)).setVisibility(View.VISIBLE);
        ((TextInputLayout) findViewById(R.id.recoveryBox)).setVisibility(View.VISIBLE);
        ((TextInputLayout) findViewById(R.id.madrasaBox)).setVisibility(View.VISIBLE);
        nameIn = findViewById(R.id.nameInput);
        emailIn = findViewById(R.id.emailInput);
        passIn = findViewById(R.id.passwordInput);
        recoveryIn = findViewById(R.id.recoveryInput);
        madrasaIn = findViewById(R.id.madrasaInput);
        Db.loadMadrasaName(n -> { if (madrasaIn.getText().toString().trim().isEmpty()) madrasaIn.setText(n); });
        errorTv = findViewById(R.id.authError);
        btn = findViewById(R.id.authButton);
        btn.setText(R.string.create_account_btn);
        btn.setOnClickListener(v -> create());
    }

    private void showError(int res) {
        errorTv.setText(res);
        errorTv.setVisibility(View.VISIBLE);
    }

    private void create() {
        String name = text(nameIn), number = text(emailIn), pass = text(passIn);
        String recovery = text(recoveryIn);
        String madrasaName = text(madrasaIn);
        if (name.isEmpty() || number.isEmpty() || pass.isEmpty()) { showError(R.string.fill_all_fields); return; }
        if (pass.length() < 6) { showError(R.string.password_short); return; }
        if (recovery.length() < 4) { showError(R.string.recovery_short); return; }
        String mobileCanon = AuthHelp.canonicalMobile(number);
        if (mobileCanon == null) { showError(R.string.err_mobile_invalid); return; }
        String authEmail = AuthHelp.pseudoEmail(mobileCanon);
        btn.setEnabled(false);
        btn.setText(R.string.creating);

        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(FbConfig.API_KEY)
                .setApplicationId(FbConfig.APP_ID)
                .setProjectId(FbConfig.PROJECT_ID)
                .setGcmSenderId(FbConfig.SENDER_ID)
                .setStorageBucket(FbConfig.STORAGE_BUCKET)
                .build();
        FirebaseApp secondary;
        try {
            secondary = FirebaseApp.initializeApp(this, options, "secondary");
        } catch (IllegalStateException dup) {
            secondary = FirebaseApp.getInstance("secondary");
        }
        FirebaseAuth secAuth = FirebaseAuth.getInstance(secondary);
        FirebaseApp secApp = secondary;
        secAuth.createUserWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Map<String, Object> doc = new HashMap<>();
                    doc.put("name", name);
                    doc.put("email", authEmail);
                    doc.put("mobile", mobileCanon);
                    doc.put("role", "teacher");
                    doc.put("loginType", "mobile");
                    doc.put("recoveryHash", AuthHelp.recoveryHash(mobileCanon, recovery));
                    Db.fs().collection(Db.USERS).document(uid).set(doc)
                            .addOnSuccessListener(x -> {
                                secAuth.signOut();
                                secApp.delete();
                                if (!madrasaName.isEmpty()) {
                                    Map<String, Object> cm = new HashMap<>();
                                    cm.put("madrasaName", madrasaName);
                                    Db.fs().collection(Db.CONFIG).document(Db.CONFIG_DOC)
                                            .set(cm, SetOptions.merge());
                                }
                                signInMain(authEmail, pass, name);
                            })
                            .addOnFailureListener(e -> {
                                secAuth.signOut();
                                secApp.delete();
                                fail(AuthHelp.errorRes(e));
                            });
                })
                .addOnFailureListener(e -> {
                    secApp.delete();
                    fail(AuthHelp.errorRes(e));
                });
    }

    private void signInMain(String authEmail, String pass, String name) {
        MadrasaApp.get().auth().signInWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(res -> {
                    MadrasaApp.get().setSession("teacher", name);
                    Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                })
                .addOnFailureListener(e -> {
                    // Account exists but the immediate sign-in failed
                    // (e.g. network): the login screen will take it.
                    startActivity(new Intent(this, LoginActivity.class));
                    finish();
                });
    }

    private void fail(int res) {
        btn.setEnabled(true);
        btn.setText(R.string.create_account_btn);
        showError(res);
        Toast.makeText(this, res, Toast.LENGTH_LONG).show();
    }

    private static String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}
