package com.madrasarecord.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Accounts management: list madrasa accounts, create new sign-in
// accounts (Teacher or Muhtamim) and remove an account's access.
// Open to BOTH roles, EQUAL powers (v1.2.0 standing rule).
// v1.2.0: Settings now opens this screen in a ROLE MODE (intent extra
// "role" = "teacher" or "muhtamim") — the list then shows only that
// role's accounts and new accounts are created with that role fixed
// (the «استاد کا اکاؤنٹ» section mirrors «محتمم صاحب کا اکاؤنٹ»).
// Every row also carries a TPIN button: the manager sets the
// account's TPIN (= its recovery code, AuthHelp.recoveryHash of the
// account's mobile) for the Forgot Password flow. Delete guards: a
// user can never delete their OWN account, and the LAST teacher
// account can never be deleted.
public class UsersActivity extends BaseActivity {
    private static final class UserRow {
        String uid, name, email, role, mobile, loginType;
        Map<String, Object> data;
    }

    private final List<UserRow> rows = new ArrayList<>();        // ALL accounts
    private final List<UserRow> displayRows = new ArrayList<>(); // role-filtered view
    private Adapter adapter;
    private String modeRole; // null = show all (legacy entry)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);
        modeRole = getIntent().getStringExtra("role");
        TextView title = findViewById(R.id.usersTitle);
        if ("teacher".equals(modeRole)) title.setText(R.string.teacher_section);
        else if ("muhtamim".equals(modeRole)) title.setText(R.string.muhtamim_section);
        RecyclerView list = findViewById(R.id.usersList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter();
        list.setAdapter(adapter);
        findViewById(R.id.addUserBtn).setOnClickListener(v -> showAddDialog());
        load();
    }

    private void load() {
        Db.fs().collection(Db.USERS).get().addOnSuccessListener(q -> {
            rows.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                UserRow r = new UserRow();
                r.uid = d.getId();
                r.name = d.getString("name");
                r.email = d.getString("email");
                r.role = d.getString("role");
                r.mobile = d.getString("mobile");
                r.loginType = d.getString("loginType");
                r.data = d.getData();
                rows.add(r);
            }
            displayRows.clear();
            for (UserRow r : rows) {
                if (modeRole == null || modeRole.equals(r.role)) displayRows.add(r);
            }
            adapter.notifyDataSetChanged();
            applyFonts();
        });
    }

    private int teacherCount() {
        int n = 0;
        for (UserRow r : rows) if ("teacher".equals(r.role)) n++;
        return n;
    }

    private String myUid() {
        return MadrasaApp.get().auth().getCurrentUser() != null
                ? MadrasaApp.get().auth().getCurrentUser().getUid() : "";
    }

    private void showAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        EditText name = new EditText(this); name.setHint(getString(R.string.full_name));
        // Accounts are mobile-number-only: the identifier field is the
        // mobile number (phone input); there is no email field at all.
        EditText email = new EditText(this); email.setHint(getString(R.string.mobile_number));
        email.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        EditText pass = new EditText(this); pass.setHint(getString(R.string.password));
        pass.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Spinner role = new Spinner(this);
        role.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{getString(R.string.role_muhtamim), getString(R.string.role_teacher)}));
        box.addView(name); box.addView(email); box.addView(pass);
        // In a role mode the new account's role is FIXED to the
        // section the manager came from — no role picker.
        if (modeRole == null) box.addView(role);
        new AlertDialog.Builder(this)
                .setTitle(R.string.add_user)
                .setView(box)
                .setPositiveButton(R.string.create_account_btn, (d, w) -> {
                    String n = name.getText().toString().trim();
                    String identifier = email.getText().toString().trim();
                    String p = pass.getText().toString();
                    String r = modeRole != null ? modeRole
                            : (role.getSelectedItemPosition() == 1 ? "teacher" : "muhtamim");
                    if (n.isEmpty() || identifier.isEmpty()) {
                        Toast.makeText(this, R.string.fill_all_fields, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (p.length() < 6) {
                        Toast.makeText(this, R.string.password_short, Toast.LENGTH_LONG).show();
                        return;
                    }
                    String mobileCanon = AuthHelp.canonicalMobile(identifier);
                    if (mobileCanon == null) {
                        Toast.makeText(this, R.string.err_mobile_invalid, Toast.LENGTH_LONG).show();
                        return;
                    }
                    createAccount(n, AuthHelp.pseudoEmail(mobileCanon), p, r, mobileCanon);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void createAccount(String name, String email, String pass, String role, String mobileCanon) {
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(FbConfig.API_KEY)
                .setApplicationId(FbConfig.APP_ID)
                .setProjectId(FbConfig.PROJECT_ID)
                .setGcmSenderId(FbConfig.SENDER_ID)
                .setStorageBucket(FbConfig.STORAGE_BUCKET)
                .build();
        FirebaseApp secondary;
        try {
            secondary = FirebaseApp.initializeApp(this, options, "secondary");
        } catch (IllegalStateException dup) {
            secondary = FirebaseApp.getInstance("secondary");
        }
        FirebaseAuth secAuth = FirebaseAuth.getInstance(secondary);
        FirebaseApp secApp = secondary;
        secAuth.createUserWithEmailAndPassword(email, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Map<String, Object> doc = new HashMap<>();
                    doc.put("name", name);
                    doc.put("email", email);
                    doc.put("role", role);
                    doc.put("loginType", "mobile");
                    doc.put("mobile", mobileCanon);
                    Db.fs().collection(Db.USERS).document(uid).set(doc)
                            .addOnSuccessListener(x -> {
                                secAuth.signOut();
                                secApp.delete();
                                Toast.makeText(this, R.string.user_added, Toast.LENGTH_LONG).show();
                                load();
                            })
                            .addOnFailureListener(e -> {
                                secAuth.signOut();
                                secApp.delete();
                                Toast.makeText(this, AuthHelp.errorRes(e), Toast.LENGTH_LONG).show();
                            });
                })
                .addOnFailureListener(e -> {
                    secApp.delete();
                    Toast.makeText(this, AuthHelp.errorRes(e), Toast.LENGTH_LONG).show();
                });
    }

    // Reset a user's password (v1.0.11): the account is replaced under
    // the hood (AccountReset) with the new password; the teacher then
    // tells the user the new password himself (see the success toast).
    private void showResetDialog(UserRow r) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        EditText pass = new EditText(this); pass.setHint(getString(R.string.new_password));
        pass.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(pass);
        new AlertDialog.Builder(this)
                .setTitle(R.string.reset_password_title)
                .setView(box)
                .setPositiveButton(R.string.change_password_btn, (d, w) -> {
                    String p = pass.getText().toString();
                    if (p.length() < 6) {
                        Toast.makeText(this, R.string.password_short, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (r.mobile == null || r.mobile.isEmpty()) {
                        Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                        return;
                    }
                    AccountReset.replacePassword(this, r.uid, r.data, r.mobile, p,
                            (ok, newUid, newEmail) -> {
                                if (ok) {
                                    Toast.makeText(this, R.string.reset_done_teacher, Toast.LENGTH_LONG).show();
                                    load();
                                } else {
                                    Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                                }
                            });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // Set another account's TPIN (v1.2.0): the native TPIN is the
    // recovery code — its hash is stored on the account's user doc
    // keyed to the account's own mobile, exactly like the code a user
    // sets for themselves in Settings. Digits only, at least 4 (the
    // approved preview's rule).
    private void showTpinDialog(UserRow r) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        EditText code = new EditText(this);
        code.setHint(getString(R.string.tpin_ph));
        code.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        code.setFilters(new android.text.InputFilter[]{
                new android.text.InputFilter.LengthFilter(64)});
        box.addView(code);
        new AlertDialog.Builder(this)
                .setTitle(R.string.tpin_lbl)
                .setView(box)
                .setPositiveButton(R.string.save, (d, w) -> {
                    String c = code.getText().toString().trim();
                    if (!c.matches("^\\d{4,}$")) {
                        Toast.makeText(this, R.string.err_bad_tpin, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (r.mobile == null || r.mobile.isEmpty()) {
                        Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                        return;
                    }
                    Db.fs().collection(Db.USERS).document(r.uid)
                            .update("recoveryHash", AuthHelp.recoveryHash(r.mobile, c))
                            .addOnSuccessListener(x -> Toast.makeText(this, R.string.tpin_saved, Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e -> Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show());
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmDelete(UserRow r) {
        // Guards (v1.2.0): never one's OWN account; never the LAST
        // teacher account.
        if (r.uid.equals(myUid())) {
            Toast.makeText(this, R.string.err_self_remove, Toast.LENGTH_LONG).show();
            return;
        }
        if ("teacher".equals(r.role) && teacherCount() <= 1) {
            Toast.makeText(this, R.string.err_last_teacher, Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_user_q)
                .setPositiveButton(R.string.yes, (d, w) ->
                        Db.fs().collection(Db.USERS).document(r.uid).delete()
                                .addOnSuccessListener(x -> {
                                    Toast.makeText(this, R.string.user_deleted, Toast.LENGTH_SHORT).show();
                                    load();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show()))
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            UserRow r = displayRows.get(position);
            h.name.setText(r.name == null ? "" : r.name);
            // Mobile accounts display their number, never the pseudo-email.
            String display = (r.mobile != null && !r.mobile.isEmpty()) ? r.mobile
                    : (AuthHelp.isPseudoEmail(r.email) ? "" : (r.email == null ? "" : r.email));
            h.email.setText(display);
            h.role.setText("teacher".equals(r.role) ? getString(R.string.role_teacher) : getString(R.string.role_muhtamim));
            String myUid = myUid();
            h.del.setVisibility(r.uid.equals(myUid) ? View.GONE : View.VISIBLE);
            h.del.setOnClickListener(v -> confirmDelete(r));
            h.tpin.setOnClickListener(v -> showTpinDialog(r));
            // Password reset (v1.0.11): tapping a user (never one's own
            // row) offers "make a new password" for them.
            h.itemView.setOnClickListener(v -> {
                if (!r.uid.equals(myUid)) showResetDialog(r);
            });
            Ui.applyFont(h.itemView, UsersActivity.this);
        }

        @Override
        public int getItemCount() { return displayRows.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, email, role; View del, tpin;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.userName);
                email = v.findViewById(R.id.userEmail);
                role = v.findViewById(R.id.userRole);
                del = v.findViewById(R.id.userDelete);
                tpin = v.findViewById(R.id.userTpin);
            }
        }
    }
}
