package com.madrasarecord.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Teacher-only: list madrasa accounts, create new sign-in accounts
// (Teacher or Muhtamim) and remove an account's access.
public class UsersActivity extends BaseActivity {
    private static final class UserRow {
        String uid, name, email, role, mobile, loginType;
    }

    private final List<UserRow> rows = new ArrayList<>();
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);
        RecyclerView list = findViewById(R.id.usersList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter();
        list.setAdapter(adapter);
        findViewById(R.id.addUserBtn).setOnClickListener(v -> showAddDialog());
        load();
    }

    private void load() {
        Db.fs().collection(Db.USERS).get().addOnSuccessListener(q -> {
            rows.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                UserRow r = new UserRow();
                r.uid = d.getId();
                r.name = d.getString("name");
                r.email = d.getString("email");
                r.role = d.getString("role");
                r.mobile = d.getString("mobile");
                r.loginType = d.getString("loginType");
                rows.add(r);
            }
            adapter.notifyDataSetChanged();
            applyFonts();
        });
    }

    private void showAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        EditText name = new EditText(this); name.setHint(getString(R.string.full_name));
        // Accounts are mobile-number-only: the identifier field is the
        // mobile number (phone input); there is no email field at all.
        EditText email = new EditText(this); email.setHint(getString(R.string.mobile_number));
        email.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        EditText pass = new EditText(this); pass.setHint(getString(R.string.password));
        pass.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Spinner role = new Spinner(this);
        role.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{getString(R.string.role_muhtamim), getString(R.string.role_teacher)}));
        box.addView(name); box.addView(email); box.addView(pass); box.addView(role);
        new AlertDialog.Builder(this)
                .setTitle(R.string.add_user)
                .setView(box)
                .setPositiveButton(R.string.create_account_btn, (d, w) -> {
                    String n = name.getText().toString().trim();
                    String identifier = email.getText().toString().trim();
                    String p = pass.getText().toString();
                    String r = role.getSelectedItemPosition() == 1 ? "teacher" : "muhtamim";
                    if (n.isEmpty() || identifier.isEmpty()) {
                        Toast.makeText(this, R.string.fill_all_fields, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (p.length() < 6) {
                        Toast.makeText(this, R.string.password_short, Toast.LENGTH_LONG).show();
                        return;
                    }
                    String mobileCanon = AuthHelp.canonicalMobile(identifier);
                    if (mobileCanon == null) {
                        Toast.makeText(this, R.string.err_mobile_invalid, Toast.LENGTH_LONG).show();
                        return;
                    }
                    createAccount(n, AuthHelp.pseudoEmail(mobileCanon), p, r, mobileCanon);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void createAccount(String name, String email, String pass, String role, String mobileCanon) {
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(FbConfig.API_KEY)
                .setApplicationId(FbConfig.APP_ID)
                .setProjectId(FbConfig.PROJECT_ID)
                .setGcmSenderId(FbConfig.SENDER_ID)
                .setStorageBucket(FbConfig.STORAGE_BUCKET)
                .build();
        FirebaseApp secondary;
        try {
            secondary = FirebaseApp.initializeApp(this, options, "secondary");
        } catch (IllegalStateException dup) {
            secondary = FirebaseApp.getInstance("secondary");
        }
        FirebaseAuth secAuth = FirebaseAuth.getInstance(secondary);
        FirebaseApp secApp = secondary;
        secAuth.createUserWithEmailAndPassword(email, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Map<String, Object> doc = new HashMap<>();
                    doc.put("name", name);
                    doc.put("email", email);
                    doc.put("role", role);
                    doc.put("loginType", "mobile");
                    doc.put("mobile", mobileCanon);
                    Db.fs().collection(Db.USERS).document(uid).set(doc)
                            .addOnSuccessListener(x -> {
                                secAuth.signOut();
                                secApp.delete();
                                Toast.makeText(this, R.string.user_added, Toast.LENGTH_LONG).show();
                                load();
                            })
                            .addOnFailureListener(e -> {
                                secAuth.signOut();
                                secApp.delete();
                                Toast.makeText(this, AuthHelp.errorRes(e), Toast.LENGTH_LONG).show();
                            });
                })
                .addOnFailureListener(e -> {
                    secApp.delete();
                    Toast.makeText(this, AuthHelp.errorRes(e), Toast.LENGTH_LONG).show();
                });
    }

    private void confirmDelete(UserRow r) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_user_q)
                .setPositiveButton(R.string.yes, (d, w) ->
                        Db.fs().collection(Db.USERS).document(r.uid).delete()
                                .addOnSuccessListener(x -> {
                                    Toast.makeText(this, R.string.user_deleted, Toast.LENGTH_SHORT).show();
                                    load();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show()))
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            UserRow r = rows.get(position);
            h.name.setText(r.name == null ? "" : r.name);
            // Mobile accounts display their number, never the pseudo-email.
            String display = (r.mobile != null && !r.mobile.isEmpty()) ? r.mobile
                    : (AuthHelp.isPseudoEmail(r.email) ? "" : (r.email == null ? "" : r.email));
            h.email.setText(display);
            h.role.setText("teacher".equals(r.role) ? getString(R.string.role_teacher) : getString(R.string.role_muhtamim));
            String myUid = MadrasaApp.get().auth().getCurrentUser() != null
                    ? MadrasaApp.get().auth().getCurrentUser().getUid() : "";
            h.del.setVisibility(r.uid.equals(myUid) ? View.GONE : View.VISIBLE);
            h.del.setOnClickListener(v -> confirmDelete(r));
            Ui.applyFont(h.itemView, UsersActivity.this);
        }

        @Override
        public int getItemCount() { return rows.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, email, role; View del;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.userName);
                email = v.findViewById(R.id.userEmail);
                role = v.findViewById(R.id.userRole);
                del = v.findViewById(R.id.userDelete);
            }
        }
    }
}
