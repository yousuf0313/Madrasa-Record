package com.madrasarecord.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.widget.ImageView;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

// Shared data helpers: collection names, student model, photos, dates.
public final class Db {
    public static final String STUDENTS = "madrasa_students";
    public static final String ATTENDANCE = "madrasa_attendance";
    public static final String USERS = "madrasa_users";
    public static final String CONFIG = "madrasa_config";
    public static final String PHOTO_DIR = "madrasa_photos";

    public static final String SESSION_MORNING = "morning";
    public static final String SESSION_EVENING = "evening";

    public static final String MARK_PRESENT = "P";
    public static final String MARK_ABSENT = "A";
    public static final String MARK_LEAVE = "L";

    private Db() {}

    public static FirebaseFirestore fs() { return MadrasaApp.get().db(); }

    // ---- madrasa name: lives in madrasa_config/setup as key "madrasaName".
    // When the value is absent (first run / pre-v1.0.2 installs) it is seeded
    // with the default name so the header is never blank. Additive only. ----
    public static final String CONFIG_DOC = "setup";
    public static final String DEFAULT_MADRASA_NAME = "مدرسہ عربیہ سیدنا فاروق اعظم، پل ہزارہ";

    public interface MadrasaNameCallback { void onName(String name); }

    public static void loadMadrasaName(MadrasaNameCallback cb) {
        fs().collection(CONFIG).document(CONFIG_DOC).get()
                .addOnSuccessListener(doc -> {
                    String name = null;
                    if (doc != null) {
                        Object mv = doc.get("madrasaName");
                        if (mv instanceof String) name = (String) mv;
                    }
                    if (name == null || name.trim().isEmpty()) {
                        name = DEFAULT_MADRASA_NAME;
                        Map<String, Object> seed = new HashMap<>();
                        seed.put("madrasaName", name);
                        fs().collection(CONFIG).document(CONFIG_DOC)
                                .set(seed, SetOptions.merge());
                    }
                    cb.onName(name);
                })
                .addOnFailureListener(e -> cb.onName(DEFAULT_MADRASA_NAME));
    }

    public static Task<Void> saveMadrasaName(String name) {
        Map<String, Object> m = new HashMap<>();
        m.put("madrasaName", name);
        return fs().collection(CONFIG).document(CONFIG_DOC).set(m, SetOptions.merge());
    }

    public static final class Student {
        public String id, name, fatherName, bform, classGroup, admissionDate, notes, photoUrl;
        public String registrationNumber, dateOfBirth, completionDate, ageManual;
        public long createdAtMillis;
        public int serial;
        public List<String> mobiles = new ArrayList<>();
        public Student() {}
        public Student(DocumentSnapshot d) {
            id = d.getId();
            name = str(d.get("name"));
            fatherName = str(d.get("fatherName"));
            bform = str(d.get("bform"));
            Object m = d.get("mobiles");
            if (m instanceof List) for (Object o : (List<?>) m) if (o != null) mobiles.add(String.valueOf(o));
            classGroup = str(d.get("classGroup"));
            admissionDate = str(d.get("admissionDate"));
            notes = str(d.get("notes"));
            photoUrl = str(d.get("photoUrl"));
            registrationNumber = str(d.get("registrationNumber"));
            dateOfBirth = str(d.get("dateOfBirth"));
            completionDate = str(d.get("completionDate"));
            ageManual = str(d.get("ageManual"));
            // A non-Timestamp createdAt (legacy/foreign write) yields 0
            // instead of throwing inside getTimestamp.
            Object ca = d.get("createdAt");
            createdAtMillis = ca instanceof com.google.firebase.Timestamp
                    ? ((com.google.firebase.Timestamp) ca).toDate().getTime() : 0L;
        }
        private static String str(String s) { return s == null ? "" : s; }
        // Hardened read (v1.0.10): a field stored as a non-String yields ""
        // instead of the ClassCastException doc.getString would throw.
        private static String str(Object o) { return o instanceof String ? (String) o : ""; }
    }

    // ---- serial numbers: position in registration order (createdAt asc;
    // legacy docs without createdAt fall back to admissionDate, then name) ----
    public static void assignSerials(List<Student> students) {
        List<Student> sorted = new ArrayList<>(students);
        sorted.sort((a, b) -> {
            long ka = serialKey(a), kb = serialKey(b);
            if (ka != kb) return Long.compare(ka, kb);
            int byName = a.name.toLowerCase(Locale.US).compareTo(b.name.toLowerCase(Locale.US));
            if (byName != 0) return byName;
            return String.valueOf(a.id).compareTo(String.valueOf(b.id));
        });
        for (int i = 0; i < sorted.size(); i++) sorted.get(i).serial = i + 1;
    }

    private static long serialKey(Student s) {
        if (s.createdAtMillis > 0) return s.createdAtMillis;
        try {
            return new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s.admissionDate).getTime();
        } catch (Exception e) { return Long.MAX_VALUE; }
    }

    public static void sortBySerial(List<Student> students) {
        students.sort((a, b) -> Integer.compare(a.serial, b.serial));
    }

    // ---- age (manual override wins) and completion duration: computed ----
    public static String ageText(Context c, Student s) {
        if (s.ageManual != null && !s.ageManual.trim().isEmpty()) return s.ageManual.trim();
        java.time.Period p = periodBetween(s.dateOfBirth, today());
        if (p == null) return "—";
        return c.getString(R.string.age_years_months, p.getYears(), p.getMonths());
    }

    public static String durationText(Context c, Student s) {
        java.time.Period p = periodBetween(s.admissionDate, s.completionDate);
        if (p == null) return "—";
        return c.getString(R.string.age_years_months, p.getYears(), p.getMonths());
    }

    private static java.time.Period periodBetween(String from, String to) {
        try {
            if (from == null || from.isEmpty() || to == null || to.isEmpty()) return null;
            java.time.LocalDate a = java.time.LocalDate.parse(from);
            java.time.LocalDate b = java.time.LocalDate.parse(to);
            if (b.isBefore(a)) return null;
            return java.time.Period.between(a, b);
        } catch (Exception e) { return null; }
    }

    public static String groupLabel(Context c, String key) {
        if ("nazra".equals(key)) return c.getString(R.string.grp_nazra);
        if ("qaida".equals(key)) return c.getString(R.string.grp_qaida);
        return c.getString(R.string.grp_hifz);
    }

    // ---- dates ----
    public static String today() { return fmt(new Date()); }
    public static String fmt(Date d) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d); }
    public static String pretty(Context c, String yyyyMmDd) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(yyyyMmDd);
            // Latin numbering system forced (nu=latn): Urdu month names stay
            // Urdu, but every digit in the formatted date is 0-9.
            Locale loc = Locale.forLanguageTag(Ui.lang(c) + "-u-nu-latn");
            String out = new SimpleDateFormat("EEEE، d MMMM yyyy", loc).format(d);
            return Ui.latinDigits(out);
        } catch (Exception e) { return Ui.latinDigits(yyyyMmDd); }
    }
    public static String docId(String date, String session) { return date + "_" + session; }

    public static List<String> last7Days() {
        List<String> out = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -6);
        for (int i = 0; i < 7; i++) { out.add(fmt(cal.getTime())); cal.add(Calendar.DAY_OF_YEAR, 1); }
        return out;
    }

    public static String monthPrefix(String yyyyMmDd) { return yyyyMmDd.substring(0, 7); }

    // ---- delete a student COMPLETELY (v1.0.3, centralized): used by both
    // the detail page and the register-list long-press flow. Deletes (a) the
    // student's photo from Firebase Storage (by stored download URL when
    // present, else by the canonical madrasa_photos/<id>.jpg path — cleanup
    // is best-effort and never blocks the delete), (b) the student's id from
    // the marks map of every attendance document, and (c) the student
    // document itself. The local cached photo is removed too. ----
    public interface DeleteCallback { void onDone(boolean ok); }

    public static void deleteStudentCompletely(Context ctx, String studentId, String photoUrl, DeleteCallback cb) {
        if (studentId == null) { if (cb != null) cb.onDone(false); return; }
        // (a) photo cleanup — best effort
        try {
            StorageReference pref = null;
            if (photoUrl != null && photoUrl.startsWith("http")) {
                try { pref = MadrasaApp.get().storage().getReferenceFromUrl(photoUrl); }
                catch (Exception ignored) { pref = null; }
            }
            if (pref == null) {
                pref = MadrasaApp.get().storage().getReference().child(PHOTO_DIR + "/" + studentId + ".jpg");
            }
            pref.delete().addOnFailureListener(e -> { /* photo may not exist; not an error */ });
        } catch (Exception ignored) {}
        try {
            photoMemCache.remove(studentId);
            File local = photoFile(ctx, studentId);
            if (local.exists()) local.delete();
        } catch (Exception ignored) {}
        // (b) scrub attendance marks, then (c) delete the document
        fs().collection(ATTENDANCE).get().addOnCompleteListener(t -> {
            if (t.isSuccessful() && t.getResult() != null) {
                for (DocumentSnapshot d : t.getResult().getDocuments()) {
                    Object marksObj = d.get("marks");
                    if (marksObj instanceof Map && ((Map<?, ?>) marksObj).containsKey(studentId)) {
                        Map<String, Object> upd = new HashMap<>();
                        upd.put("marks." + studentId, FieldValue.delete());
                        d.getReference().update(upd);
                    }
                }
            }
            fs().collection(STUDENTS).document(studentId).delete()
                    .addOnSuccessListener(x -> { if (cb != null) cb.onDone(true); })
                    .addOnFailureListener(e -> { if (cb != null) cb.onDone(false); });
        });
    }

    // ---- photos: local compressed copy + Firebase Storage upload ----
    public static File photoFile(Context c, String studentId) {
        File dir = new File(c.getFilesDir(), "photos");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, studentId + ".jpg");
    }

    // Save a picked/captured image as a compressed local JPEG (max side 720px); returns the file.
    // v1.0.11 (owner's order): the EXIF orientation of the source is applied
    // to the bitmap BEFORE it is scaled/compressed, so the saved local JPEG —
    // and therefore the copy uploadPhoto() sends to Firebase Storage — is
    // upright for camera captures and gallery picks alike. (Camera JPEGs
    // usually carry a rotate-90 EXIF flag and no rotation in the pixels;
    // BitmapFactory ignores the flag, which is why photos showed sideways.)
    public static File saveCompressed(Context c, String studentId, Uri uri) throws Exception {
        int exifOrientation = ExifInterface.ORIENTATION_NORMAL;
        try {
            InputStream ein = c.getContentResolver().openInputStream(uri);
            if (ein != null) {
                exifOrientation = new ExifInterface(ein).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                ein.close();
            }
        } catch (Exception ignored) {
            // No readable EXIF: fall through with NORMAL and save as before.
        }
        InputStream in = c.getContentResolver().openInputStream(uri);
        Bitmap bmp = BitmapFactory.decodeStream(in);
        if (in != null) in.close();
        if (bmp == null) throw new IllegalStateException("decode failed");
        bmp = applyExifOrientation(bmp, exifOrientation);
        int w = bmp.getWidth(), h = bmp.getHeight();
        float scale = Math.min(1f, 720f / Math.max(w, h));
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
        File f = photoFile(c, studentId);
        FileOutputStream out = new FileOutputStream(f);
        bmp.compress(Bitmap.CompressFormat.JPEG, 78, out);
        out.close();
        return f;
    }

    // Rotate/flip a decoded bitmap per its EXIF orientation value.
    private static Bitmap applyExifOrientation(Bitmap bmp, int orientation) {
        Matrix m = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.setScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.setRotate(180); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                m.setRotate(180); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE:
                m.setRotate(90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_90: m.setRotate(90); break;
            case ExifInterface.ORIENTATION_TRANSVERSE:
                m.setRotate(-90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.setRotate(-90); break;
            default: return bmp; // NORMAL / UNDEFINED: pixels already upright
        }
        try {
            Bitmap out = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            return out != null ? out : bmp;
        } catch (Exception e) {
            return bmp;
        }
    }

    public static void uploadPhoto(String studentId) {
        File f = photoFile(MadrasaApp.get(), studentId);
        if (!f.exists()) return;
        StorageReference ref = MadrasaApp.get().storage().getReference().child(PHOTO_DIR + "/" + studentId + ".jpg");
        ref.putFile(Uri.fromFile(f)).addOnSuccessListener(snap ->
                ref.getDownloadUrl().addOnSuccessListener(url ->
                        fs().collection(STUDENTS).document(studentId)
                                .update("photoUrl", url.toString())));
    }

    private static final java.util.Map<String, Bitmap> photoMemCache = new java.util.HashMap<>();

    public static void loadPhoto(Context c, Student s, ImageView iv) {
        iv.setImageResource(R.drawable.ic_person_placeholder);
        if (s == null || s.id == null) return;
        Bitmap cached = photoMemCache.get(s.id);
        if (cached != null) { iv.setImageBitmap(cached); return; }
        File local = photoFile(c, s.id);
        if (local.exists()) {
            Bitmap b = BitmapFactory.decodeFile(local.getAbsolutePath());
            if (b != null) { photoMemCache.put(s.id, b); iv.setImageBitmap(b); return; }
        }
        if (s.photoUrl != null && !s.photoUrl.isEmpty()) {
            MadrasaApp.get().storage().getReference().child(PHOTO_DIR + "/" + s.id + ".jpg")
                    .getBytes(3 * 1024 * 1024).addOnSuccessListener(bytes -> {
                        Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        if (b != null) { photoMemCache.put(s.id, b); iv.setImageBitmap(b); }
                    });
        }
    }
}
