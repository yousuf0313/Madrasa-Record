package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

// فارغ التحصیل list (v1.1.0): graduated students with a total count.
// Their records are never deleted and open from here like any other.
public class GraduatesFragment extends BaseFragment {
    private final List<Db.Student> grads = new ArrayList<>();
    private Adapter adapter;
    private TextView countTv;
    private View emptyBox;
    private String lang = "ur";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup c, @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_graduates, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle b) {
        super.onViewCreated(view, b);
        lang = Ui.lang(requireContext());
        countTv = view.findViewById(R.id.gradCount);
        emptyBox = view.findViewById(R.id.gradEmpty);
        RecyclerView list = view.findViewById(R.id.gradList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            grads.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (s.graduated) grads.add(s);
            }
            Db.assignSerials(grads);
            Db.sortBySerial(grads);
            countTv.setText(String.valueOf(grads.size()));
            emptyBox.setVisibility(grads.isEmpty() ? View.VISIBLE : View.GONE);
            adapter.notifyDataSetChanged();
            applyFonts(getView());
        });
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_graduate_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = grads.get(position);
            h.name.setText(s.name);
            h.father.setText(s.fatherName);
            Ui.fitOneLine(h.name, 14f, 8f);
            Ui.fitOneLine(h.father, 12.5f, 8f);
            if (s.completionDate.isEmpty()) {
                h.date.setText(getString(R.string.completion_date) + ": " + getString(R.string.not_recorded));
            } else {
                h.date.setText(getString(R.string.completion_date) + ": " + Hijri.bothLine(s.completionDate, lang));
            }
            h.label.setText(s.completionLabel.isEmpty() ? "—" : "🎓 " + s.completionLabel);
            Db.loadPhoto(requireContext(), s, h.photo);
            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(getContext(), StudentDetailActivity.class);
                i.putExtra("studentId", s.id);
                i.putExtra("serial", s.serial);
                startActivity(i);
            });
            Ui.applyFont(h.itemView, requireContext());
        }

        @Override
        public int getItemCount() { return grads.size(); }

        class Holder extends RecyclerView.ViewHolder {
            ImageView photo; TextView name, father, date, label;
            Holder(View v) {
                super(v);
                photo = v.findViewById(R.id.gradPhoto);
                name = v.findViewById(R.id.gradName);
                father = v.findViewById(R.id.gradFather);
                date = v.findViewById(R.id.gradCompletionDate);
                label = v.findViewById(R.id.gradCompletionLabel);
            }
        }
    }
}
