package com.madrasarecord.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// سبق حاضری (v1.1.0): one card per student — وقت پر سنایا / لیٹ سنایا /
// نہیں سنایا. Tapping the active chip again clears it. Saves
// immediately into the day's "lesson" doc in madrasa_attendance.
// v1.2.0: BOTH roles mark (equal powers). Single scroll — only the
// navy header stays pinned; the section filter (تمام شعبے / بنین /
// بنات) filters the list + counts, and the madrasa banner scrolls
// away with the page.
public class SabaqFragment extends BaseFragment {
    private String date;
    private String lang = "ur";
    private final List<Db.Student> students = new ArrayList<>();
    private final List<Db.Student> shown = new ArrayList<>();
    private SectionFilter sectionFilter;
    private boolean chromeCollapsed;
    private final Map<String, String> marks = new HashMap<>(); // sid -> ontime/late/none
    private Adapter adapter;
    private TextView chipTotal, chipOnTime, chipLate, chipNone, hijriTv, emptyTv;
    private Button dateBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup c, @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_sabaq, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle b) {
        super.onViewCreated(view, b);
        lang = Ui.lang(requireContext());
        date = Db.today();
        dateBtn = view.findViewById(R.id.sabaqDateBtn);
        hijriTv = view.findViewById(R.id.sabaqHijri);
        chipTotal = view.findViewById(R.id.sabaqChipTotal);
        chipOnTime = view.findViewById(R.id.sabaqChipOnTime);
        chipLate = view.findViewById(R.id.sabaqChipLate);
        chipNone = view.findViewById(R.id.sabaqChipNone);
        emptyTv = view.findViewById(R.id.sabaqEmpty);
        boolean canMark = MadrasaApp.get().canMark();
        view.findViewById(R.id.sabaqNoMarkNote).setVisibility(canMark ? View.GONE : View.VISIBLE);
        sectionFilter = new SectionFilter(requireContext(),
                view.findViewById(R.id.sabaqSectionRow), f -> refresh());
        androidx.core.widget.NestedScrollView scroller = view.findViewById(R.id.sabaqScroll);
        scroller.setOnScrollChangeListener((androidx.core.widget.NestedScrollView.OnScrollChangeListener)
                (v, sx, sy, osx, osy) -> {
                    boolean want = sy > 24;
                    if (sy <= 2) want = false;
                    else if (!want) return;
                    if (want == chromeCollapsed) return;
                    chromeCollapsed = want;
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).setBannerCollapsed(want);
                    }
                });
        dateBtn.setOnClickListener(v -> pickDate());
        view.findViewById(R.id.sabaqHijriFix).setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        hijriTv.setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        Button add = view.findViewById(R.id.sabaqAddStudent);
        add.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        add.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        RecyclerView list = view.findViewById(R.id.sabaqList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        refreshHeader();
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void refreshHeader() {
        dateBtn.setText(Hijri.gregorianShort(date, lang) + "  ▾");
        hijriTv.setText(Hijri.format(date, lang));
    }

    private void pickDate() {
        java.time.LocalDate cur = java.time.LocalDate.parse(date);
        new DatePickerDialog(requireContext(), (v, y, m, d) -> {
            date = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refreshHeader();
            load();
        }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (!s.graduated) students.add(s);
            }
            Db.assignSerials(students);
            Db.sortBySerial(students);
            Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, Db.SESSION_LESSON)).get()
                    .addOnSuccessListener(doc -> {
                        marks.clear();
                        if (doc != null && doc.exists()) {
                            Object raw = doc.get("marks");
                            if (raw instanceof Map) {
                                for (Map.Entry<?, ?> e : ((Map<?, ?>) raw).entrySet()) {
                                    if (e.getKey() != null && e.getValue() instanceof String) {
                                        marks.put(String.valueOf(e.getKey()), (String) e.getValue());
                                    }
                                }
                            }
                        }
                        refresh();
                    })
                    .addOnFailureListener(e -> refresh());
        });
    }

    private void refresh() {
        shown.clear();
        shown.addAll(SectionFilter.apply(students,
                sectionFilter == null ? SectionFilter.ALL : sectionFilter.current()));
        boolean filterActive = sectionFilter != null && !SectionFilter.ALL.equals(sectionFilter.current());
        emptyTv.setText(filterActive && !students.isEmpty()
                ? R.string.no_students_section : R.string.no_students_msg);
        emptyTv.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        int on = 0, late = 0, none = 0;
        for (Db.Student s : shown) {
            String m = marks.get(s.id);
            if (Db.MARK_ONTIME.equals(m)) on++;
            else if (Db.MARK_LATE.equals(m)) late++;
            else if (Db.MARK_NONE.equals(m)) none++;
        }
        chipTotal.setText(getString(R.string.total_students) + ": " + shown.size());
        chipOnTime.setText(getString(R.string.sabaq_ontime) + ": " + on);
        chipLate.setText(getString(R.string.sabaq_late) + ": " + late);
        chipNone.setText(getString(R.string.sabaq_none) + ": " + none);
        applyFonts(getView());
    }

    private void toggle(Db.Student s, String value) {
        if (!MadrasaApp.get().canMark()) return;
        String cur = marks.get(s.id);
        String next = value.equals(cur) ? null : value;
        if (next == null) marks.remove(s.id); else marks.put(s.id, next);
        Db.saveMark(date, Db.SESSION_LESSON, s.id, next);
        refresh();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sabaq_card, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = shown.get(position);
            h.name.setText(s.name);
            h.father.setText(s.fatherName);
            Ui.fitOneLine(h.name, 13.5f, 8f);
            Ui.fitOneLine(h.father, 12.5f, 8f);
            h.name.setOnClickListener(v -> openStudent(s));
            h.father.setOnClickListener(v -> openStudent(s));
            String m = marks.get(s.id);
            bindChip(h.onTime, Db.MARK_ONTIME.equals(m), R.drawable.bg_status_on_time, R.color.green_c,
                    v -> toggle(s, Db.MARK_ONTIME));
            bindChip(h.late, Db.MARK_LATE.equals(m), R.drawable.bg_status_late, R.color.amber_c,
                    v -> toggle(s, Db.MARK_LATE));
            bindChip(h.none, Db.MARK_NONE.equals(m), R.drawable.bg_status_none, R.color.red_c,
                    v -> toggle(s, Db.MARK_NONE));
            Ui.applyFont(h.itemView, requireContext());
        }

        private void bindChip(TextView chip, boolean active, int activeBg, int activeColor, View.OnClickListener tap) {
            chip.setBackgroundResource(active ? activeBg : R.drawable.bg_status_off);
            chip.setTextColor(getResources().getColor(active ? activeColor : R.color.muted, null));
            boolean canMark = MadrasaApp.get().canMark();
            chip.setOnClickListener(canMark ? tap : null);
            chip.setClickable(canMark);
        }

        @Override
        public int getItemCount() { return shown.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, father, onTime, late, none;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.sabaqName);
                father = v.findViewById(R.id.sabaqFather);
                onTime = v.findViewById(R.id.chipSabaqOnTime);
                late = v.findViewById(R.id.chipSabaqLate);
                none = v.findViewById(R.id.chipSabaqNone);
            }
        }
    }

    private void openStudent(Db.Student s) {
        Intent i = new Intent(getContext(), StudentDetailActivity.class);
        i.putExtra("studentId", s.id);
        i.putExtra("serial", s.serial);
        startActivity(i);
    }
}
