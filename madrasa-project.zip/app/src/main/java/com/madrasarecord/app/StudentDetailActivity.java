package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class StudentDetailActivity extends BaseActivity {
    private String studentId;
    private Db.Student student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);
        studentId = getIntent().getStringExtra("studentId");
        boolean teacher = MadrasaApp.get().isTeacher();
        findViewById(R.id.detailActions).setVisibility(teacher ? View.VISIBLE : View.GONE);
        findViewById(R.id.detailEditBtn).setOnClickListener(v -> {
            Intent i = new Intent(this, StudentEditActivity.class);
            i.putExtra("studentId", studentId);
            startActivity(i);
        });
        findViewById(R.id.detailDeleteBtn).setOnClickListener(v -> confirmDelete());
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_student_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    // Centralized complete delete: document + Storage photo +
                    // the student's marks in every attendance register.
                    String photoUrl = student != null ? student.photoUrl : null;
                    Db.deleteStudentCompletely(this, studentId, photoUrl, ok -> {
                        if (ok) {
                            Toast.makeText(this, R.string.student_deleted, Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).document(studentId).get().addOnSuccessListener(doc -> {
            if (!doc.exists()) { finish(); return; }
            student = new Db.Student(doc);
            student.serial = getIntent().getIntExtra("serial", 0);
            ((TextView) findViewById(R.id.detailName)).setText(student.name);
            Db.loadPhoto(this, student, findViewById(R.id.detailPhoto));
            if (student.serial > 0) {
                renderBody();
            } else {
                // serial not passed in: compute it from the full register order
                Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
                    List<Db.Student> allSt = new ArrayList<>();
                    for (DocumentSnapshot d : q.getDocuments()) allSt.add(new Db.Student(d));
                    Db.assignSerials(allSt);
                    for (Db.Student x : allSt) if (x.id.equals(studentId)) student.serial = x.serial;
                    renderBody();
                }).addOnFailureListener(e -> renderBody());
            }
            loadAttendance();
            applyFonts();
        });
    }

    private void renderBody() {
        if (student == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append(getString(R.string.serial_number)).append(": ").append(student.serial > 0 ? String.valueOf(student.serial) : "—").append("\n");
        sb.append(getString(R.string.father_name)).append(": ").append(student.fatherName).append("\n");
        sb.append(getString(R.string.bform_number)).append(": ").append(student.bform.isEmpty() ? "—" : student.bform).append("\n");
        sb.append(getString(R.string.registration_number)).append(": ").append(student.registrationNumber.isEmpty() ? "—" : student.registrationNumber).append("\n");
        sb.append(getString(R.string.class_group)).append(": ").append(Db.groupLabel(this, student.classGroup)).append("\n");
        sb.append(getString(R.string.admission_date)).append(": ").append(student.admissionDate.isEmpty() ? "—" : student.admissionDate).append("\n");
        sb.append(getString(R.string.date_of_birth)).append(": ").append(student.dateOfBirth.isEmpty() ? "—" : student.dateOfBirth).append("\n");
        sb.append(getString(R.string.age_lbl)).append(": ").append(Db.ageText(this, student)).append("\n");
        sb.append(getString(R.string.completion_date)).append(": ").append(student.completionDate.isEmpty() ? "—" : student.completionDate).append("\n");
        sb.append(getString(R.string.completion_duration)).append(": ").append(Db.durationText(this, student));
        if (!student.notes.isEmpty()) sb.append("\n").append(getString(R.string.notes)).append(": ").append(student.notes);
        ((TextView) findViewById(R.id.detailBody)).setText(sb.toString());
        renderMobiles();
        applyFonts();
    }

    // Father's mobile numbers as individual tap-to-call rows (ACTION_DIAL:
    // opens the dialer pre-filled; no CALL_PHONE permission needed).
    // Visible and tappable for BOTH roles — the Muhtamim needs them to call
    // a student's father; this grants no editing power anywhere.
    private void renderMobiles() {
        LinearLayout box = findViewById(R.id.detailMobiles);
        if (box == null || student == null) return;
        box.removeAllViews();
        if (student.mobiles.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("—");
            tv.setTextColor(getResources().getColor(R.color.muted, null));
            tv.setTextSize(15);
            box.addView(tv);
            return;
        }
        for (String m : student.mobiles) {
            final String number = m.trim();
            if (number.isEmpty()) continue;
            TextView tv = new TextView(this);
            tv.setText(number);
            tv.setTextSize(16);
            tv.setTextColor(getResources().getColor(R.color.green_dark, null));
            tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
            tv.setPaintFlags(tv.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            tv.setPadding(0, 10, 0, 10);
            tv.setContentDescription(getString(R.string.mobile_numbers) + ": " + number);
            tv.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
                } catch (Exception e) {
                    Toast.makeText(this, R.string.err_generic, Toast.LENGTH_SHORT).show();
                }
            });
            box.addView(tv);
        }
    }

    private void loadAttendance() {
        LinearLayout box = findViewById(R.id.detailHistory);
        TextView monthTv = findViewById(R.id.detailMonth);
        Db.fs().collection(Db.ATTENDANCE).orderBy("date").get().addOnSuccessListener(q -> {
            box.removeAllViews();
            List<DocumentSnapshot> docs = new ArrayList<>(q.getDocuments());
            Collections.reverse(docs);
            String thisMonth = Db.today().substring(0, 7);
            int mTotal = 0, mPresent = 0, shown = 0;
            for (DocumentSnapshot doc : docs) {
                Map<String, Object> marks = (Map<String, Object>) doc.get("marks");
                if (marks == null || !marks.containsKey(studentId)) continue;
                String mark = String.valueOf(marks.get(studentId));
                String date = doc.getString("date");
                String session = doc.getString("session");
                if (date != null && date.startsWith(thisMonth)) {
                    mTotal++;
                    if (Db.MARK_PRESENT.equals(mark)) mPresent++;
                }
                if (shown < 40) {
                    shown++;
                    TextView tv = new TextView(this);
                    String markLabel = Db.MARK_PRESENT.equals(mark) ? getString(R.string.present)
                            : Db.MARK_ABSENT.equals(mark) ? getString(R.string.absent) : getString(R.string.leave_lbl);
                    String sessLabel = getString(Db.SESSION_EVENING.equals(session) ? R.string.evening : R.string.morning);
                    tv.setText(Db.pretty(this, date) + " — " + sessLabel + ": " + markLabel);
                    tv.setTextSize(14);
                    tv.setTextColor(getResources().getColor(R.color.ink, null));
                    tv.setPadding(0, 7, 0, 7);
                    box.addView(tv);
                }
            }
            if (shown == 0) {
                TextView tv = new TextView(this);
                tv.setText(R.string.no_history);
                tv.setTextColor(getResources().getColor(R.color.muted, null));
                box.addView(tv);
            }
            if (mTotal == 0) {
                monthTv.setText(getString(R.string.no_history));
            } else {
                String pct = String.format(java.util.Locale.US, "%.0f", mPresent * 100.0 / mTotal);
                monthTv.setText(getString(R.string.percent_line, pct, mPresent, mTotal));
            }
            applyFonts();
        });
    }
}
