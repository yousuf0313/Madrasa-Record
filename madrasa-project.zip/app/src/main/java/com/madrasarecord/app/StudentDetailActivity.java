package com.madrasarecord.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Student record page (v1.1.0): photo header + chips, the 3 sections,
// the عہد نامہ section with the per-student clause-2 strike + print,
// graduation / reactivation, and class-attendance history. Edit,
// delete, graduate and reactivate are open to BOTH roles (the Muhtamim
// holds every teacher power except marking — v1.1.0 role split).
public class StudentDetailActivity extends BaseActivity {
    private String studentId;
    private Db.Student student;
    private String lang = "ur";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);
        lang = Ui.lang(this);
        studentId = getIntent().getStringExtra("studentId");
        boolean manage = MadrasaApp.get().canManage();
        findViewById(R.id.detailActions).setVisibility(manage ? View.VISIBLE : View.GONE);
        findViewById(R.id.gradBox).setVisibility(manage ? View.VISIBLE : View.GONE);
        findViewById(R.id.detailEditBtn).setOnClickListener(v -> {
            Intent i = new Intent(this, StudentEditActivity.class);
            i.putExtra("studentId", studentId);
            startActivity(i);
        });
        findViewById(R.id.detailDeleteBtn).setOnClickListener(v -> confirmDelete());
        findViewById(R.id.detailGraduateBtn).setOnClickListener(v -> showGraduateDialog());
        findViewById(R.id.detailReactivateBtn).setOnClickListener(v -> reactivate());
        CheckBox strike = findViewById(R.id.pledgeStrike);
        strike.setOnCheckedChangeListener((b, checked) -> {
            if (student == null) return;
            student.pledgeClause2Struck = checked;
            applyStrike();
            Map<String, Object> m = new HashMap<>();
            m.put("pledgeClause2Struck", checked);
            Db.fs().collection(Db.STUDENTS).document(studentId).set(m, SetOptions.merge());
        });
        findViewById(R.id.pledgePrintBtn).setOnClickListener(v -> printPledge());
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_student_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    String photoUrl = student != null ? student.photoUrl : null;
                    Db.deleteStudentCompletely(this, studentId, photoUrl, ok -> {
                        if (ok) {
                            Toast.makeText(this, R.string.student_deleted, Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).document(studentId).get().addOnSuccessListener(doc -> {
            if (!doc.exists()) { finish(); return; }
            student = new Db.Student(doc);
            student.serial = getIntent().getIntExtra("serial", 0);
            ((TextView) findViewById(R.id.detailName)).setText(student.name);
            ((TextView) findViewById(R.id.detailFather)).setText(
                    student.fatherName.isEmpty() ? "" : getString(R.string.son_of) + " " + student.fatherName);
            Db.loadPhoto(this, student, findViewById(R.id.detailPhoto));
            findViewById(R.id.detailGradBadge).setVisibility(student.graduated ? View.VISIBLE : View.GONE);
            ((TextView) findViewById(R.id.chipClass)).setText(Db.groupLabel(this, student.classGroup));
            ((TextView) findViewById(R.id.chipReg)).setText(getString(R.string.registration_number) + ": "
                    + (student.registrationNumber.isEmpty() ? "—" : student.registrationNumber));
            ((TextView) findViewById(R.id.chipAge)).setText(getString(R.string.age_lbl) + ": " + Db.ageText(this, student));
            if (student.serial > 0) {
                renderBody();
            } else {
                Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
                    List<Db.Student> allSt = new ArrayList<>();
                    for (DocumentSnapshot d : q.getDocuments()) allSt.add(new Db.Student(d));
                    Db.assignSerials(allSt);
                    for (Db.Student x : allSt) if (x.id.equals(studentId)) student.serial = x.serial;
                    renderBody();
                }).addOnFailureListener(e -> renderBody());
            }
            loadAttendance();
            applyFonts();
        });
    }

    private String dualDate(String iso) {
        return iso == null || iso.isEmpty() ? "—" : Hijri.bothLine(iso, lang);
    }

    private void renderBody() {
        if (student == null) return;
        StringBuilder personal = new StringBuilder();
        personal.append(getString(R.string.serial_number)).append(": ").append(student.serial > 0 ? String.valueOf(student.serial) : "—").append("\n");
        personal.append(getString(R.string.student_name_lbl)).append(": ").append(student.name).append("\n");
        personal.append(getString(R.string.father_name)).append(": ").append(student.fatherName).append("\n");
        personal.append(getString(R.string.bform_number)).append(": ").append(student.bform.isEmpty() ? "—" : student.bform).append("\n");
        personal.append(getString(R.string.date_of_birth)).append(": ").append(dualDate(student.dateOfBirth)).append("\n");
        personal.append(getString(R.string.age_lbl)).append(": ").append(Db.ageText(this, student));
        ((TextView) findViewById(R.id.detailPersonal)).setText(personal.toString());

        StringBuilder adm = new StringBuilder();
        adm.append(getString(R.string.class_group)).append(": ").append(Db.groupLabel(this, student.classGroup)).append("\n");
        adm.append(getString(R.string.registration_number)).append(": ").append(student.registrationNumber.isEmpty() ? "—" : student.registrationNumber).append("\n");
        adm.append(getString(R.string.admission_date)).append(": ").append(dualDate(student.admissionDate)).append("\n");
        adm.append(getString(R.string.completion_date)).append(": ").append(dualDate(student.completionDate)).append("\n");
        adm.append(getString(R.string.completion_label)).append(": ").append(student.completionLabel.isEmpty() ? "—" : student.completionLabel).append("\n");
        adm.append(getString(R.string.completion_duration)).append(": ").append(Db.durationText(this, student));
        if (!student.notes.isEmpty()) adm.append("\n").append(getString(R.string.notes)).append(": ").append(student.notes);
        ((TextView) findViewById(R.id.detailAdmission)).setText(adm.toString());

        // Graduation actions: graduate button only for active students;
        // reactivate (with its note) only for graduated ones.
        findViewById(R.id.detailGraduateBtn).setVisibility(student.graduated ? View.GONE : View.VISIBLE);
        findViewById(R.id.detailReactivateNote).setVisibility(student.graduated ? View.VISIBLE : View.GONE);
        findViewById(R.id.detailReactivateBtn).setVisibility(student.graduated ? View.VISIBLE : View.GONE);

        CheckBox strike = findViewById(R.id.pledgeStrike);
        strike.setChecked(student.pledgeClause2Struck);
        applyStrike();
        renderMobiles();
        applyFonts();
    }

    private void applyStrike() {
        TextView c2 = findViewById(R.id.pledgeClause2);
        if (student != null && student.pledgeClause2Struck) {
            c2.setPaintFlags(c2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            c2.setTextColor(getResources().getColor(R.color.red_c, null));
        } else {
            c2.setPaintFlags(c2.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            c2.setTextColor(getResources().getColor(R.color.ink, null));
        }
    }

    // Print ONLY the pledge (title, clauses, note, blank signature
    // lines) via a WebView print adapter; clause 2 is struck through
    // when the student's flag is set.
    private void printPledge() {
        if (student == null) return;
        boolean struck = student.pledgeClause2Struck;
        String c2Style = struck ? " style=\"text-decoration: line-through; color:#b00;\"" : "";
        String html = "<html dir=\"rtl\"><head><meta charset=\"utf-8\"><style>"
                + "body{font-family:sans-serif;padding:24px;color:#111}"
                + "h1{text-align:center;font-size:22px;margin-bottom:2px}"
                + ".rule{border-top:3px double #123;height:4px;border-bottom:1px solid #123;margin-bottom:14px}"
                + "p{font-size:15px;line-height:1.9;text-align:justify}"
                + ".note{color:#444;font-size:13.5px}"
                + ".sigs{margin-top:56px;width:100%}.sigs td{width:33%;text-align:center;padding:0 10px}"
                + ".line{border-top:1.5px dotted #111;height:1px}"
                + ".cap{font-size:12.5px;color:#333;padding-top:5px}"
                + "</style></head><body>"
                + "<h1>" + getString(R.string.pledge_title) + "</h1><div class=\"rule\"></div>"
                + "<p>" + getString(R.string.pledge_clause1) + "</p>"
                + "<p" + c2Style + ">" + getString(R.string.pledge_clause2) + "</p>"
                + "<p class=\"note\">" + getString(R.string.pledge_note) + "</p>"
                + "<table class=\"sigs\"><tr>"
                + "<td><div class=\"line\"></div><div class=\"cap\">" + getString(R.string.sig_student) + "</div></td>"
                + "<td><div class=\"line\"></div><div class=\"cap\">" + getString(R.string.sig_guardian) + "</div></td>"
                + "<td><div class=\"line\"></div><div class=\"cap\">" + getString(R.string.date_lbl) + "</div></td>"
                + "</tr></table></body></html>";
        WebView wv = new WebView(this);
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        wv.setWebViewClient(new android.webkit.WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm != null) {
                    pm.print(getString(R.string.pledge_title),
                            view.createPrintDocumentAdapter(getString(R.string.pledge_title)),
                            new PrintAttributes.Builder().build());
                }
            }
        });
    }

    // Graduation: completion date (default today, dual display in the
    // dialog) + what-was-completed label. The record is never deleted.
    private void showGraduateDialog() {
        if (student == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        final String[] chosen = {Db.today()};
        Button dateBtn = new Button(this);
        Runnable upd = () -> dateBtn.setText(getString(R.string.completion_date) + ": " + Hijri.bothLine(chosen[0], lang));
        upd.run();
        dateBtn.setOnClickListener(v -> {
            java.time.LocalDate cur = java.time.LocalDate.parse(chosen[0]);
            new DatePickerDialog(this, (vv, y, m, d) -> {
                chosen[0] = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d);
                upd.run();
            }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
        });
        EditText label = new EditText(this);
        label.setHint(R.string.completion_label_hint);
        box.addView(dateBtn);
        box.addView(label);
        new AlertDialog.Builder(this)
                .setTitle(R.string.mark_graduated)
                .setView(box)
                .setPositiveButton(R.string.graduate_btn, (d, w) -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("graduated", true);
                    m.put("completionDate", chosen[0]);
                    m.put("completionLabel", label.getText().toString().trim());
                    Db.fs().collection(Db.STUDENTS).document(studentId).set(m, SetOptions.merge())
                            .addOnSuccessListener(x -> {
                                Toast.makeText(this, R.string.graduated_done, Toast.LENGTH_SHORT).show();
                                load();
                            })
                            .addOnFailureListener(e -> Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show());
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        Ui.applyFont(box, this);
    }

    private void reactivate() {
        Map<String, Object> m = new HashMap<>();
        m.put("graduated", false);
        Db.fs().collection(Db.STUDENTS).document(studentId).set(m, SetOptions.merge())
                .addOnSuccessListener(x -> {
                    Toast.makeText(this, R.string.reactivated_done, Toast.LENGTH_SHORT).show();
                    load();
                })
                .addOnFailureListener(e -> Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show());
    }

    // Father's mobile numbers as individual tap-to-call rows (ACTION_DIAL:
    // opens the dialer pre-filled; no CALL_PHONE permission needed).
    private void renderMobiles() {
        LinearLayout box = findViewById(R.id.detailMobiles);
        if (box == null || student == null) return;
        box.removeAllViews();
        if (student.mobiles.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("—");
            tv.setTextColor(getResources().getColor(R.color.muted, null));
            tv.setTextSize(15);
            box.addView(tv);
            return;
        }
        for (String m : student.mobiles) {
            final String number = m.trim();
            if (number.isEmpty()) continue;
            TextView tv = new TextView(this);
            tv.setText(number);
            tv.setTextSize(16);
            tv.setTextColor(getResources().getColor(R.color.navy, null));
            tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
            tv.setPaintFlags(tv.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            tv.setPadding(0, 10, 0, 10);
            tv.setContentDescription(getString(R.string.mobile_numbers) + ": " + number);
            tv.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
                } catch (Exception e) {
                    Toast.makeText(this, R.string.err_generic, Toast.LENGTH_SHORT).show();
                }
            });
            box.addView(tv);
        }
    }

    // History: CLASS sessions only (the shared attendance collection now
    // also holds punc_*/lesson docs — those are not class attendance).
    private void loadAttendance() {
        LinearLayout box = findViewById(R.id.detailHistory);
        TextView monthTv = findViewById(R.id.detailMonth);
        Db.fs().collection(Db.ATTENDANCE).orderBy("date").get().addOnSuccessListener(q -> {
            box.removeAllViews();
            List<DocumentSnapshot> docs = new ArrayList<>(q.getDocuments());
            Collections.reverse(docs);
            String thisMonth = Db.today().substring(0, 7);
            int mTotal = 0, mPresent = 0, shown = 0;
            for (DocumentSnapshot doc : docs) {
                Object sessObj = doc.get("session");
                String session = sessObj instanceof String ? (String) sessObj : null;
                if (!Db.isClassSession(session)) continue;
                Object marksObj = doc.get("marks");
                Map<String, Object> marks = marksObj instanceof Map ? (Map<String, Object>) marksObj : null;
                if (marks == null || !marks.containsKey(studentId)) continue;
                String mark = String.valueOf(marks.get(studentId));
                if (!Db.MARK_PRESENT.equals(mark) && !Db.MARK_ABSENT.equals(mark) && !Db.MARK_LEAVE.equals(mark)) continue;
                String date = doc.getString("date");
                if (date != null && date.startsWith(thisMonth)) {
                    mTotal++;
                    if (Db.MARK_PRESENT.equals(mark)) mPresent++;
                }
                if (shown < 40) {
                    shown++;
                    TextView tv = new TextView(this);
                    String markLabel = Db.MARK_PRESENT.equals(mark) ? getString(R.string.present)
                            : Db.MARK_ABSENT.equals(mark) ? getString(R.string.absent) : getString(R.string.leave_lbl);
                    String sessLabel = Db.SESSION_MIDDAY.equals(session) ? getString(R.string.midday)
                            : Db.SESSION_EVENING.equals(session) ? getString(R.string.evening) : getString(R.string.morning);
                    tv.setText(Db.pretty(this, date) + " — " + sessLabel + ": " + markLabel);
                    tv.setTextSize(14);
                    tv.setTextColor(getResources().getColor(R.color.ink, null));
                    tv.setPadding(0, 7, 0, 7);
                    box.addView(tv);
                }
            }
            if (shown == 0) {
                TextView tv = new TextView(this);
                tv.setText(R.string.no_history);
                tv.setTextColor(getResources().getColor(R.color.muted, null));
                box.addView(tv);
            }
            if (mTotal == 0) {
                monthTv.setText(getString(R.string.no_history));
            } else {
                String pct = String.format(java.util.Locale.US, "%.0f", mPresent * 100.0 / mTotal);
                monthTv.setText(getString(R.string.percent_line, pct, mPresent, mTotal));
            }
            applyFonts();
        });
    }
}
