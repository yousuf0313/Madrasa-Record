package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;

public class SplashActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Crash safety net, hardened (v1.0.7 audit): read the saved crash
        // BEFORE setContentView, and only clear() it after the dialog has
        // been dismissed (the proceed callback below) — so if showing the
        // dialog itself is what fails, the record survives for the next
        // launch instead of being silently discarded. The whole check is
        // wrapped — the net can never block or crash startup.
        String saved = null;
        try {
            saved = CrashNet.peek(this);
        } catch (Throwable ignored) {
        }
        setContentView(R.layout.activity_splash);
        if (saved != null) {
            final String text = saved;
            CrashNet.showSavedCrash(this, text, () -> {
                CrashNet.clear(this);
                route();
            });
            return;
        }
        route();
    }

    private void route() {
        FirebaseUser user = MadrasaApp.get().auth().getCurrentUser();
        if (user != null) {
            Db.fs().collection(Db.USERS).document(user.getUid()).get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            MadrasaApp.get().setSession(strField(doc, "role"), strField(doc, "name"));
                            go(MainActivity.class);
                        } else {
                            go(NotAuthorizedActivity.class);
                        }
                    })
                    .addOnFailureListener(e -> go(LoginActivity.class));
        } else {
            Db.fs().collection(Db.CONFIG).document("setup").get()
                    .addOnSuccessListener(doc -> go(doc.exists() ? LoginActivity.class : SetupActivity.class))
                    .addOnFailureListener(e -> go(SetupActivity.class));
        }
    }

    // Type-safe field read: DocumentSnapshot.getString() throws a
    // RuntimeException when the stored field is not a String, and an
    // exception inside a Tasks success listener is NOT routed to the
    // failure listener — it kills the process. Read via get() +
    // instanceof instead (hardening, v1.0.5).
    private static String strField(DocumentSnapshot doc, String field) {
        try {
            Object v = doc.get(field);
            return v instanceof String ? (String) v : null;
        } catch (Exception e) {
            return null;
        }
    }

    private void go(Class<?> cls) {
        startActivity(new Intent(this, cls));
        finish();
    }
}
