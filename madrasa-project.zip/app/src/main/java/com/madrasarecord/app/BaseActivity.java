package com.madrasarecord.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(Ui.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        View root = findViewById(android.R.id.content);
        if (root != null) {
            root.post(() -> Ui.applyFont(root, this));
        }
    }

    protected void applyFonts() {
        View root = findViewById(android.R.id.content);
        if (root != null) Ui.applyFont(root, this);
    }
}
