package com.madrasarecord.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// Class tab (v1.1.0): three sub-views — حاضری (marking), رجسٹر (paper
// register = StudentsFragment), 🎓 فارغ التحصیل (GraduatesFragment).
// Marking: 3 sessions on one screen, boxed rows, identity boxes distinct
// from the session boxes; a tap CYCLES حاضر → غیر حاضر → رخصت → خالی and
// saves immediately. Manual only: nothing is pre-marked.
// v1.2.0: BOTH roles mark (equal powers — canMark is any signed-in
// account now). The marking view is a SINGLE SCROLL: the navy header
// stays pinned; the sub-tab bar above and the madrasa-name banner
// (MainActivity) scroll away with the page and return at the top. A
// section filter (تمام شعبے / بنین / بنات) filters rows + summary, and
// the saved class times show in a gold strip under the header.
public class ClassFragment extends BaseFragment {
    private static final int SUB_MARK = 0, SUB_REGISTER = 1, SUB_GRADUATES = 2;
    private TextView subAtt, subRegister, subGraduates;
    private View subTabBar;
    private boolean chromeCollapsed;
    private FrameLayoutRef container;

    // marking state
    private View markView;
    private String date;
    private String lang = "ur";
    private final List<Db.Student> students = new ArrayList<>();
    private final List<Db.Student> rows = new ArrayList<>();
    private final Map<String, Map<String, String>> marks = new HashMap<>(); // session -> sid -> P/A/L
    private final Map<String, Set<String>> excluded = new HashMap<>();     // session -> sids
    private MarkAdapter markAdapter;
    private TextView chipTotal, chipPresent, chipAbsent, chipLeave, hijriTv, emptyTv;
    private Button dateBtn;
    private SectionFilter sectionFilter;

    private static final class FrameLayoutRef { ViewGroup group; }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup c, @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_class, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle b) {
        super.onViewCreated(view, b);
        lang = Ui.lang(requireContext());
        date = Db.today();
        subTabBar = view.findViewById(R.id.subTabBar);
        subAtt = view.findViewById(R.id.subTabAtt);
        subRegister = view.findViewById(R.id.subTabRegister);
        subGraduates = view.findViewById(R.id.subTabGraduates);
        container = new FrameLayoutRef();
        container.group = view.findViewById(R.id.classSubContainer);
        subAtt.setOnClickListener(v -> showSub(SUB_MARK));
        subRegister.setOnClickListener(v -> showSub(SUB_REGISTER));
        subGraduates.setOnClickListener(v -> showSub(SUB_GRADUATES));
        showSub(SUB_MARK);
    }

    private void styleTabs(int active) {
        TextView[] tabs = {subAtt, subRegister, subGraduates};
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == active;
            tabs[i].setBackgroundResource(on ? R.drawable.bg_subtab_active : R.drawable.bg_subtab_inactive);
            tabs[i].setTextColor(getResources().getColor(on ? R.color.white : R.color.muted, null));
        }
    }

    // v1.2.0 collapsing chrome for the marking page's single scroll:
    // the sub-tab bar here + the madrasa banner in MainActivity hide
    // together while scrolling down and return at the top / on any
    // sub-view switch.
    private void setChromeCollapsed(boolean collapsed) {
        if (collapsed == chromeCollapsed) return;
        chromeCollapsed = collapsed;
        if (subTabBar != null) subTabBar.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setBannerCollapsed(collapsed);
        }
    }

    private void showSub(int which) {
        setChromeCollapsed(false);
        styleTabs(which);
        // Remove any child fragment FIRST (the FragmentManager owns its
        // view), then clear the marking view if one is showing.
        Fragment cur = getChildFragmentManager().findFragmentById(R.id.classSubContainer);
        if (cur != null) getChildFragmentManager().beginTransaction().remove(cur).commitNow();
        container.group.removeAllViews();
        if (which == SUB_MARK) {
            buildMarkView();
            container.group.addView(markView);
        } else {
            Fragment f = which == SUB_REGISTER ? new StudentsFragment() : new GraduatesFragment();
            getChildFragmentManager().beginTransaction()
                    .replace(R.id.classSubContainer, f).commitNow();
        }
        applyFonts(getView());
    }

    // ---------------- marking view ----------------

    private void buildMarkView() {
        markView = LayoutInflater.from(requireContext()).inflate(R.layout.layout_class_mark, container.group, false);
        dateBtn = markView.findViewById(R.id.classDateBtn);
        hijriTv = markView.findViewById(R.id.classHijri);
        chipTotal = markView.findViewById(R.id.chipTotal);
        chipPresent = markView.findViewById(R.id.chipPresent);
        chipAbsent = markView.findViewById(R.id.chipAbsent);
        chipLeave = markView.findViewById(R.id.chipLeave);
        emptyTv = markView.findViewById(R.id.classEmpty);
        boolean canMark = MadrasaApp.get().canMark();
        markView.findViewById(R.id.classNoMarkNote).setVisibility(canMark ? View.GONE : View.VISIBLE);
        markView.findViewById(R.id.markAllRow).setVisibility(canMark ? View.VISIBLE : View.GONE);
        markView.findViewById(R.id.classAutoSaved).setVisibility(canMark ? View.VISIBLE : View.GONE);
        // v1.2.0: section filter + class-times strip + single-scroll chrome.
        sectionFilter = new SectionFilter(requireContext(),
                markView.findViewById(R.id.classSectionRow), f -> rebuildRows());
        android.widget.LinearLayout strip = markView.findViewById(R.id.classTimesStrip);
        Db.loadClassTimes(times -> { if (markView != null) Db.fillTimesStrip(requireContext(), strip, times); });
        androidx.core.widget.NestedScrollView scroller = markView.findViewById(R.id.classScroll);
        scroller.setOnScrollChangeListener((androidx.core.widget.NestedScrollView.OnScrollChangeListener)
                (v, sx, sy, osx, osy) -> {
                    if (sy > 24) setChromeCollapsed(true);
                    else if (sy <= 2) setChromeCollapsed(false);
                });
        dateBtn.setOnClickListener(v -> pickDate());
        View fix = markView.findViewById(R.id.classHijriFix);
        fix.setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        hijriTv.setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        Button[] all = {markView.findViewById(R.id.markAllMorning),
                markView.findViewById(R.id.markAllMidday), markView.findViewById(R.id.markAllEvening)};
        for (int i = 0; i < 3; i++) {
            final String session = Db.CLASS_SESSIONS[i];
            all[i].setText(sessionLabel(session) + ": " + getString(R.string.mark_all_short));
            all[i].setOnClickListener(v -> markAll(session));
        }
        Button add = markView.findViewById(R.id.classAddStudent);
        add.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        add.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        RecyclerView list = markView.findViewById(R.id.classList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        markAdapter = new MarkAdapter();
        list.setAdapter(markAdapter);
        refreshHeader();
        loadMarkData();
        applyFonts(markView);
    }

    private String sessionLabel(String session) {
        if (Db.SESSION_MIDDAY.equals(session)) return getString(R.string.midday);
        if (Db.SESSION_EVENING.equals(session)) return getString(R.string.evening);
        return getString(R.string.morning);
    }

    private void refreshHeader() {
        if (dateBtn == null) return;
        dateBtn.setText(Hijri.gregorianShort(date, lang) + "  ▾");
        hijriTv.setText(Hijri.format(date, lang));
    }

    private void pickDate() {
        java.time.LocalDate cur = java.time.LocalDate.parse(date);
        new DatePickerDialog(requireContext(), (v, y, m, d) -> {
            date = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refreshHeader();
            loadMarkData();
        }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
    }

    private void loadMarkData() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (!s.graduated) students.add(s);
            }
            Db.assignSerials(students);
            Db.sortBySerial(students);
            marks.clear();
            excluded.clear();
            final int[] pending = {Db.CLASS_SESSIONS.length};
            for (String session : Db.CLASS_SESSIONS) {
                Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).get()
                        .addOnCompleteListener(t -> {
                            if (t.isSuccessful() && t.getResult() != null && t.getResult().exists()) {
                                DocumentSnapshot doc = t.getResult();
                                Map<String, String> mm = new HashMap<>();
                                Object raw = doc.get("marks");
                                if (raw instanceof Map) {
                                    for (Map.Entry<?, ?> e : ((Map<?, ?>) raw).entrySet()) {
                                        if (e.getKey() != null && e.getValue() instanceof String) {
                                            mm.put(String.valueOf(e.getKey()), (String) e.getValue());
                                        }
                                    }
                                }
                                marks.put(session, mm);
                                Set<String> ex = new HashSet<>();
                                Object exRaw = doc.get("excluded");
                                if (exRaw instanceof List) {
                                    for (Object o : (List<?>) exRaw) if (o != null) ex.add(String.valueOf(o));
                                }
                                excluded.put(session, ex);
                            }
                            if (--pending[0] == 0) rebuildRows();
                        });
            }
            if (Db.CLASS_SESSIONS.length == 0) rebuildRows();
        });
    }

    private void rebuildRows() {
        rows.clear();
        String filter = sectionFilter == null ? SectionFilter.ALL : sectionFilter.current();
        for (Db.Student s : students) {
            if (!SectionFilter.matches(s, filter)) continue;
            boolean anyExcluded = false;
            for (String session : Db.CLASS_SESSIONS) {
                Set<String> ex = excluded.get(session);
                if (ex != null && ex.contains(s.id)) { anyExcluded = true; break; }
            }
            // A student removed from one session's register for the day is
            // removed for the whole day in this combined view.
            if (!anyExcluded) rows.add(s);
        }
        boolean filterActive = !SectionFilter.ALL.equals(filter);
        emptyTv.setText(filterActive && !students.isEmpty()
                ? R.string.no_students_section : R.string.no_students_msg);
        emptyTv.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
        markAdapter.notifyDataSetChanged();
        updateSummary();
        applyFonts(markView);
    }

    private String markOf(String session, String sid) {
        Map<String, String> mm = marks.get(session);
        return mm == null ? null : mm.get(sid);
    }

    private void updateSummary() {
        int p = 0, a = 0, l = 0;
        for (Db.Student s : rows) {
            for (String session : Db.CLASS_SESSIONS) {
                String m = markOf(session, s.id);
                if (Db.MARK_PRESENT.equals(m)) p++;
                else if (Db.MARK_ABSENT.equals(m)) a++;
                else if (Db.MARK_LEAVE.equals(m)) l++;
            }
        }
        // بنات filter renames the first summary card (owner's order).
        boolean banat = sectionFilter != null && sectionFilter.isBanat();
        chipTotal.setText(getString(banat ? R.string.total_students_banat : R.string.total_students) + ": " + rows.size());
        chipPresent.setText(getString(R.string.present) + ": " + p);
        chipAbsent.setText(getString(R.string.absent) + ": " + a);
        chipLeave.setText(getString(R.string.leave_lbl) + ": " + l);
    }

    private void cycle(String session, Db.Student s) {
        if (!MadrasaApp.get().canMark()) return;
        String cur = markOf(session, s.id);
        String next;
        if (cur == null) next = Db.MARK_PRESENT;
        else if (Db.MARK_PRESENT.equals(cur)) next = Db.MARK_ABSENT;
        else if (Db.MARK_ABSENT.equals(cur)) next = Db.MARK_LEAVE;
        else next = null;
        Map<String, String> mm = marks.get(session);
        if (mm == null) { mm = new HashMap<>(); marks.put(session, mm); }
        if (next == null) mm.remove(s.id); else mm.put(s.id, next);
        Db.saveMark(date, session, s.id, next);
        markAdapter.notifyDataSetChanged();
        updateSummary();
    }

    private void markAll(String session) {
        if (!MadrasaApp.get().canMark()) return;
        Map<String, Object> batch = new HashMap<>();
        Map<String, String> mm = marks.get(session);
        if (mm == null) { mm = new HashMap<>(); marks.put(session, mm); }
        for (Db.Student s : rows) {
            batch.put(s.id, Db.MARK_PRESENT);
            mm.put(s.id, Db.MARK_PRESENT);
        }
        Map<String, Object> doc = new HashMap<>();
        doc.put("date", date);
        doc.put("session", session);
        doc.put("marks", batch);
        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session))
                .set(doc, SetOptions.merge())
                .addOnSuccessListener(x -> {
                    markAdapter.notifyDataSetChanged();
                    updateSummary();
                    Toast.makeText(requireContext(), R.string.marked_done, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(requireContext(), R.string.err_generic, Toast.LENGTH_LONG).show());
    }

    // Long-press (either role — equal powers): remove the student from
    // today's register for the whole day — all three sessions —
    // keeping the record itself.
    private void confirmRemoveFromDay(Db.Student s) {
        new AlertDialog.Builder(requireContext())
                .setMessage(R.string.reg_remove_confirm_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    for (String session : Db.CLASS_SESSIONS) {
                        Map<String, Object> doc = new HashMap<>();
                        doc.put("date", date);
                        doc.put("session", session);
                        doc.put("excluded", FieldValue.arrayUnion(s.id));
                        Map<String, Object> mm = new HashMap<>();
                        mm.put(s.id, FieldValue.delete());
                        doc.put("marks", mm);
                        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session))
                                .set(doc, SetOptions.merge());
                        Map<String, String> local = marks.get(session);
                        if (local != null) local.remove(s.id);
                        Set<String> ex = excluded.get(session);
                        if (ex == null) { ex = new HashSet<>(); excluded.put(session, ex); }
                        ex.add(s.id);
                    }
                    Toast.makeText(requireContext(), R.string.reg_name_removed, Toast.LENGTH_SHORT).show();
                    rebuildRows();
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private class MarkAdapter extends RecyclerView.Adapter<MarkAdapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_class_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = rows.get(position);
            h.name.setText(s.name);
            h.father.setText(s.fatherName);
            // Names COMPLETE on ONE line: shrink to fit, never wrap/cut.
            Ui.fitOneLine(h.name, 13.5f, 8f);
            Ui.fitOneLine(h.father, 12.5f, 8f);
            h.name.setOnClickListener(v -> openStudent(s));
            h.father.setOnClickListener(v -> openStudent(s));
            bindCell(h.morning, markOf(Db.SESSION_MORNING, s.id), v -> cycle(Db.SESSION_MORNING, s));
            bindCell(h.midday, markOf(Db.SESSION_MIDDAY, s.id), v -> cycle(Db.SESSION_MIDDAY, s));
            bindCell(h.evening, markOf(Db.SESSION_EVENING, s.id), v -> cycle(Db.SESSION_EVENING, s));
            if (MadrasaApp.get().canMark()) {
                h.itemView.setOnLongClickListener(v -> { confirmRemoveFromDay(s); return true; });
            } else {
                h.itemView.setOnLongClickListener(null);
            }
            Ui.applyFont(h.itemView, requireContext());
        }

        private void bindCell(TextView cell, String mark, View.OnClickListener tap) {
            if (Db.MARK_PRESENT.equals(mark)) {
                cell.setBackgroundResource(R.drawable.bg_mark_p);
                cell.setText("✓");
            } else if (Db.MARK_ABSENT.equals(mark)) {
                cell.setBackgroundResource(R.drawable.bg_mark_a);
                cell.setText("✕");
            } else if (Db.MARK_LEAVE.equals(mark)) {
                cell.setBackgroundResource(R.drawable.bg_mark_l);
                // Preview glyph: «ر» (for رخصت) in Urdu; other locales use
                // their day_l letter.
                cell.setText("ur".equals(lang) ? "ر" : getString(R.string.day_l));
            } else {
                cell.setBackgroundResource(R.drawable.bg_mark_none);
                cell.setText("");
            }
            cell.setOnClickListener(MadrasaApp.get().canMark() ? tap : null);
            cell.setClickable(MadrasaApp.get().canMark());
        }

        @Override
        public int getItemCount() { return rows.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, father, morning, midday, evening;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.cellName);
                father = v.findViewById(R.id.cellFather);
                morning = v.findViewById(R.id.cellMorning);
                midday = v.findViewById(R.id.cellMidday);
                evening = v.findViewById(R.id.cellEvening);
            }
        }
    }

    private void openStudent(Db.Student s) {
        Intent i = new Intent(getContext(), StudentDetailActivity.class);
        i.putExtra("studentId", s.id);
        i.putExtra("serial", s.serial);
        startActivity(i);
    }
}
