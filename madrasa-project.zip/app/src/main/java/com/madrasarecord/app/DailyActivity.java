package com.madrasarecord.app;

import android.os.Bundle;
import android.widget.TextView;

// آج کی آیت و حدیث — a separate page (v1.1.0), opened from the prominent
// entry at the TOP of Settings. It lives ONLY here (owner's correction
// 2026-11-05: verses on the register screen get buried under the rows).
// Top: today's Hijri (stored offset honored) + Gregorian dates in large
// bold type; below, the day's verse and hadith from the built-in 30+30
// collection, rotating by epoch-day. Arabic renders in Naskh.
public class DailyActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily);
        String lang = Ui.lang(this);
        String today = Db.today();
        Db.loadHijriOffset();

        findViewById(R.id.dailyBack).setOnClickListener(v -> finish());

        TextView hijri = findViewById(R.id.dailyHijri);
        TextView greg = findViewById(R.id.dailyGreg);
        hijri.setText(Hijri.format(today, lang));
        greg.setText(Hijri.gregorianShort(today, lang));

        Content.Item ayah = Content.dailyAyah(today);
        Content.Item hadith = Content.dailyHadith(today);

        TextView ayahAr = findViewById(R.id.dailyAyahArabic);
        TextView hadithAr = findViewById(R.id.dailyHadithArabic);
        ((TextView) findViewById(R.id.dailyAyahUrdu)).setText(ayah.urdu);
        ((TextView) findViewById(R.id.dailyAyahRef)).setText(ayah.ref);
        ((TextView) findViewById(R.id.dailyHadithUrdu)).setText(hadith.urdu);
        ((TextView) findViewById(R.id.dailyHadithRef)).setText(hadith.ref);
        ayahAr.setText(ayah.arabic);
        hadithAr.setText(hadith.arabic);
        applyFonts();
        // Arabic scripture stays in Naskh (owner's rule) — set AFTER the
        // general font pass so it is not overridden.
        Ui.applyNaskh(ayahAr, this);
        Ui.applyNaskh(hadithAr, this);
    }
}
