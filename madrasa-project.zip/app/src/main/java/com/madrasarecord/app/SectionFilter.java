package com.madrasarecord.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

// v1.2.0 — the بنات section filter: one shared chip row («تمام شعبے /
// بنین / بنات») used by the class, waqt, sabaq, register, progress and
// report screens. Chips are built in code (styled exactly like the
// class screen's sub-tabs) into an empty horizontal LinearLayout the
// host layout provides. The value is "all" or Db.SECTION_BANIN /
// Db.SECTION_BANAT; a student matches when the filter is "all" or the
// student's section equals it (legacy students are بنین — see Db).
public final class SectionFilter {

    public static final String ALL = "all";

    public interface Listener { void onSection(String section); }

    private final TextView[] chips = new TextView[3];
    private final String[] values = {ALL, Db.SECTION_BANIN, Db.SECTION_BANAT};
    private String current = ALL;
    private Listener listener;

    public SectionFilter(Context ctx, ViewGroup container, Listener l) {
        this.listener = l;
        int[] labels = {R.string.section_all, R.string.section_banin_short, R.string.section_banat_short};
        int padH = Ui.dp(ctx, 4), padV = Ui.dp(ctx, 7);
        for (int i = 0; i < 3; i++) {
            TextView tv = new TextView(ctx);
            tv.setText(labels[i]);
            tv.setTextSize(13);
            tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(padH, padV, padH, padV);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(Ui.dp(ctx, 6));
            tv.setLayoutParams(lp);
            final int idx = i;
            tv.setOnClickListener(v -> select(values[idx], true));
            chips[i] = tv;
            container.addView(tv);
        }
        style();
    }

    private void style() {
        Context ctx = chips[0].getContext();
        for (int i = 0; i < 3; i++) {
            boolean on = values[i].equals(current);
            chips[i].setBackgroundResource(on ? R.drawable.bg_subtab_active : R.drawable.bg_subtab_inactive);
            chips[i].setTextColor(ctx.getColor(on ? R.color.white : R.color.muted));
        }
    }

    public void select(String value, boolean notify) {
        current = value == null ? ALL : value;
        style();
        if (notify && listener != null) listener.onSection(current);
    }

    public String current() { return current; }

    public boolean isBanat() { return Db.SECTION_BANAT.equals(current); }

    public static boolean matches(Db.Student s, String filter) {
        return filter == null || ALL.equals(filter) || filter.equals(s.section);
    }

    public static java.util.List<Db.Student> apply(java.util.List<Db.Student> in, String filter) {
        java.util.List<Db.Student> out = new java.util.ArrayList<>();
        for (Db.Student s : in) if (matches(s, filter)) out.add(s);
        return out;
    }
}
