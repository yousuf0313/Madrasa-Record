package com.madrasarecord.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// وقت حاضری (v1.1.0): per class session, two round dots — وقت پر (green)
// and لیٹ (amber). Tapping a dot sets it; tapping the active dot again
// clears it. Every tap saves immediately into madrasa_attendance docs
// keyed punc_morning / punc_midday / punc_evening.
// v1.2.0: BOTH roles mark (equal powers). Single scroll — only the
// navy header stays pinned; the section filter (تمام شعبے / بنین /
// بنات) filters the list + counts, the saved class times show in a
// gold strip, and the madrasa banner scrolls away with the page.
public class WaqtFragment extends BaseFragment {
    private String date;
    private String lang = "ur";
    private final List<Db.Student> students = new ArrayList<>();
    private final List<Db.Student> shown = new ArrayList<>();
    private SectionFilter sectionFilter;
    private boolean chromeCollapsed;
    private final Map<String, Map<String, String>> marks = new HashMap<>(); // punc session -> sid -> ontime/late
    private Adapter adapter;
    private TextView chipTotal, chipOnTime, chipLate, hijriTv, emptyTv;
    private Button dateBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup c, @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_waqt, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle b) {
        super.onViewCreated(view, b);
        lang = Ui.lang(requireContext());
        date = Db.today();
        dateBtn = view.findViewById(R.id.waqtDateBtn);
        hijriTv = view.findViewById(R.id.waqtHijri);
        chipTotal = view.findViewById(R.id.waqtChipTotal);
        chipOnTime = view.findViewById(R.id.waqtChipOnTime);
        chipLate = view.findViewById(R.id.waqtChipLate);
        emptyTv = view.findViewById(R.id.waqtEmpty);
        boolean canMark = MadrasaApp.get().canMark();
        view.findViewById(R.id.waqtNoMarkNote).setVisibility(canMark ? View.GONE : View.VISIBLE);
        sectionFilter = new SectionFilter(requireContext(),
                view.findViewById(R.id.waqtSectionRow), f -> refresh());
        android.widget.LinearLayout strip = view.findViewById(R.id.waqtTimesStrip);
        Db.loadClassTimes(times -> { if (getView() != null) Db.fillTimesStrip(requireContext(), strip, times); });
        androidx.core.widget.NestedScrollView scroller = view.findViewById(R.id.waqtScroll);
        scroller.setOnScrollChangeListener((androidx.core.widget.NestedScrollView.OnScrollChangeListener)
                (v, sx, sy, osx, osy) -> {
                    boolean want = sy > 24;
                    if (sy <= 2) want = false;
                    else if (!want) return;
                    if (want == chromeCollapsed) return;
                    chromeCollapsed = want;
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).setBannerCollapsed(want);
                    }
                });
        dateBtn.setOnClickListener(v -> pickDate());
        view.findViewById(R.id.waqtHijriFix).setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        hijriTv.setOnClickListener(v -> HijriAdjust.show(requireContext(), this::refreshHeader));
        Button add = view.findViewById(R.id.waqtAddStudent);
        add.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        add.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        RecyclerView list = view.findViewById(R.id.waqtList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        refreshHeader();
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void refreshHeader() {
        dateBtn.setText(Hijri.gregorianShort(date, lang) + "  ▾");
        hijriTv.setText(Hijri.format(date, lang));
    }

    private void pickDate() {
        java.time.LocalDate cur = java.time.LocalDate.parse(date);
        new DatePickerDialog(requireContext(), (v, y, m, d) -> {
            date = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refreshHeader();
            load();
        }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (!s.graduated) students.add(s);
            }
            Db.assignSerials(students);
            Db.sortBySerial(students);
            marks.clear();
            final int[] pending = {Db.PUNC_SESSIONS.length};
            for (String session : Db.PUNC_SESSIONS) {
                Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).get()
                        .addOnCompleteListener(t -> {
                            if (t.isSuccessful() && t.getResult() != null && t.getResult().exists()) {
                                Map<String, String> mm = new HashMap<>();
                                Object raw = t.getResult().get("marks");
                                if (raw instanceof Map) {
                                    for (Map.Entry<?, ?> e : ((Map<?, ?>) raw).entrySet()) {
                                        if (e.getKey() != null && e.getValue() instanceof String) {
                                            mm.put(String.valueOf(e.getKey()), (String) e.getValue());
                                        }
                                    }
                                }
                                marks.put(session, mm);
                            }
                            if (--pending[0] == 0) refresh();
                        });
            }
        });
    }

    private void refresh() {
        shown.clear();
        shown.addAll(SectionFilter.apply(students,
                sectionFilter == null ? SectionFilter.ALL : sectionFilter.current()));
        boolean filterActive = sectionFilter != null && !SectionFilter.ALL.equals(sectionFilter.current());
        emptyTv.setText(filterActive && !students.isEmpty()
                ? R.string.no_students_section : R.string.no_students_msg);
        emptyTv.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        int on = 0, late = 0;
        for (Db.Student s : shown) {
            for (String session : Db.PUNC_SESSIONS) {
                String m = markOf(session, s.id);
                if (Db.MARK_ONTIME.equals(m)) on++;
                else if (Db.MARK_LATE.equals(m)) late++;
            }
        }
        chipTotal.setText(getString(R.string.total_students) + ": " + shown.size());
        chipOnTime.setText(getString(R.string.on_time) + ": " + on);
        chipLate.setText(getString(R.string.late_lbl) + ": " + late);
        applyFonts(getView());
    }

    private String markOf(String puncSession, String sid) {
        Map<String, String> mm = marks.get(puncSession);
        return mm == null ? null : mm.get(sid);
    }

    private void toggle(String puncSession, Db.Student s, String value) {
        if (!MadrasaApp.get().canMark()) return;
        String cur = markOf(puncSession, s.id);
        String next = value.equals(cur) ? null : value;
        Map<String, String> mm = marks.get(puncSession);
        if (mm == null) { mm = new HashMap<>(); marks.put(puncSession, mm); }
        if (next == null) mm.remove(s.id); else mm.put(s.id, next);
        Db.saveMark(date, puncSession, s.id, next);
        refresh();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_waqt_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = shown.get(position);
            h.name.setText(s.name);
            Ui.fitOneLine(h.name, 13f, 8f);
            h.name.setOnClickListener(v -> openStudent(s));
            TextView[] onDots = {h.mOn, h.dOn, h.eOn};
            TextView[] lateDots = {h.mLate, h.dLate, h.eLate};
            for (int i = 0; i < 3; i++) {
                final String session = Db.PUNC_SESSIONS[i];
                String m = markOf(session, s.id);
                bindDot(onDots[i], Db.MARK_ONTIME.equals(m), true, v -> toggle(session, s, Db.MARK_ONTIME));
                bindDot(lateDots[i], Db.MARK_LATE.equals(m), false, v -> toggle(session, s, Db.MARK_LATE));
            }
            Ui.applyFont(h.itemView, requireContext());
        }

        private void bindDot(TextView dot, boolean active, boolean onTime, View.OnClickListener tap) {
            if (active) {
                dot.setBackgroundResource(onTime ? R.drawable.bg_dot_on_time : R.drawable.bg_dot_late);
                dot.setText("✓");
            } else {
                dot.setBackgroundResource(R.drawable.bg_dot_off);
                dot.setText("");
            }
            boolean canMark = MadrasaApp.get().canMark();
            dot.setOnClickListener(canMark ? tap : null);
            dot.setClickable(canMark);
        }

        @Override
        public int getItemCount() { return shown.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView name, mOn, mLate, dOn, dLate, eOn, eLate;
            Holder(View v) {
                super(v);
                name = v.findViewById(R.id.waqtName);
                mOn = v.findViewById(R.id.dotMOn);
                mLate = v.findViewById(R.id.dotMLate);
                dOn = v.findViewById(R.id.dotDOn);
                dLate = v.findViewById(R.id.dotDLate);
                eOn = v.findViewById(R.id.dotEOn);
                eLate = v.findViewById(R.id.dotELate);
            }
        }
    }

    private void openStudent(Db.Student s) {
        Intent i = new Intent(getContext(), StudentDetailActivity.class);
        i.putExtra("studentId", s.id);
        i.putExtra("serial", s.serial);
        startActivity(i);
    }
}
