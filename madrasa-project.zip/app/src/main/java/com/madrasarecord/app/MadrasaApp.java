package com.madrasarecord.app;

import android.app.Application;
import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.storage.FirebaseStorage;

public class MadrasaApp extends Application {
    private static MadrasaApp instance;
    private FirebaseFirestore db;
    private String currentRole;   // "teacher" | "muhtamim"
    private String currentName;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        // Crash safety net, hardened (v1.0.7 audit): install the handler at
        // the earliest point in the process lifecycle — before onCreate — so
        // even a crash during Application.onCreate itself is recorded for the
        // next launch. (In v1.0.6 the handler was installed in onCreate and
        // the recorded crash could never be shown: the failure happened
        // before that code ran.) CrashNet.install is idempotent and fully
        // wrapped; it can never break startup.
        CrashNet.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey(FbConfig.API_KEY)
                    .setApplicationId(FbConfig.APP_ID)
                    .setProjectId(FbConfig.PROJECT_ID)
                    .setGcmSenderId(FbConfig.SENDER_ID)
                    .setStorageBucket(FbConfig.STORAGE_BUCKET)
                    .build();
            FirebaseApp.initializeApp(this, options);
        }
        db = FirebaseFirestore.getInstance();
        // Offline persistence: attendance works without internet and syncs later.
        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build();
        // Hardened (v1.0.3): setFirestoreSettings throws IllegalStateException
        // if Firestore was already started elsewhere; that race must never
        // be able to kill the launch.
        try {
            db.setFirestoreSettings(settings);
        } catch (IllegalStateException ignored) {
        }
    }

    public static MadrasaApp get() { return instance; }
    public FirebaseFirestore db() { return db; }
    public FirebaseAuth auth() { return FirebaseAuth.getInstance(); }
    public FirebaseStorage storage() { return FirebaseStorage.getInstance(); }

    public String role() { return currentRole; }
    public boolean isTeacher() { return "teacher".equals(currentRole); }
    public void setSession(String role, String name) { this.currentRole = role; this.currentName = name; }
    public String userName() { return currentName; }
    public void clearSession() { currentRole = null; currentName = null; }
}
