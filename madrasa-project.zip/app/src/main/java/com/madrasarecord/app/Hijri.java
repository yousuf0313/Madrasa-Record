package com.madrasarecord.app;

import android.icu.util.Calendar;
import android.icu.util.IslamicCalendar;

import java.time.LocalDate;
import java.util.Locale;

// Dual-date support (v1.1.0): every screen shows the Gregorian date
// together with its Hijri (Islamic) date. The Hijri side uses the
// platform Umm al-Qura calendar (android.icu, API 24+; minSdk is 26):
//     2026-11-05 -> 25 Jumada al-Ula 1448 (offset 0)
// Urdu month names are the fixed Pakistani-Urdu list chosen by the owner
// (NOT the Arabic spellings the ICU data would give):
//   محرم، صفر، ربیع الاول، ربیع الثانی، جمادی الاولی، جمادی الثانی، رجب،
//   شعبان، رمضان، شوال، ذوالقعدہ، ذوالحجہ
// A signed day offset (madrasa_config/setup.hijriOffsetDays, adjustable
// from the attendance headers' «درست کریں» sheet) is applied by shifting
// the Gregorian date before conversion, so EVERY Hijri display in the
// app follows it. The offset is cached here and loaded from Firestore by
// Db.loadHijriOffset(...) at app start / sign-in.
public final class Hijri {
    private Hijri() {}

    public static final int MIN_OFFSET = -10;
    public static final int MAX_OFFSET = 10;
    private static volatile int offsetDays = 0;

    public static int getOffset() { return offsetDays; }

    public static void setOffset(int days) {
        offsetDays = Math.max(MIN_OFFSET, Math.min(MAX_OFFSET, days));
    }

    private static final String[] MONTHS_UR = {
            "محرم", "صفر", "ربیع الاول", "ربیع الثانی", "جمادی الاولی", "جمادی الثانی",
            "رجب", "شعبان", "رمضان", "شوال", "ذوالقعدہ", "ذوالحجہ"};
    private static final String[] MONTHS_EN = {
            "Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Ula",
            "Jumada al-Akhirah", "Rajab", "Shaban", "Ramadan", "Shawwal",
            "Dhul-Qadah", "Dhul-Hijjah"};
    private static final String[] MONTHS_AR = {
            "محرم", "صفر", "ربيع الأول", "ربيع الثاني", "جمادى الأولى", "جمادى الآخرة",
            "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"};

    // {day, month(1-12), year} for a Gregorian ISO date plus an
    // ADDITIONAL explicit shift (used by the adjustment sheet's live
    // preview; the stored offset is always included). Null on bad input.
    // Conversion goes through epoch millis in UTC — Calendar.set(y,m,d)
    // on an IslamicCalendar would interpret the fields AS an Islamic
    // date instead of converting. UTC noon keeps the day stable in
    // every timezone and matches the preview's Intl conversion.
    public static int[] parts(String isoDate, int extraShiftDays) {
        try {
            LocalDate d = LocalDate.parse(isoDate).plusDays(offsetDays + extraShiftDays);
            IslamicCalendar cal = new IslamicCalendar();
            cal.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            cal.setTimeZone(android.icu.util.TimeZone.getTimeZone("UTC"));
            cal.setTimeInMillis(d.toEpochDay() * 86400000L + 43200000L);
            return new int[]{
                    cal.get(Calendar.DAY_OF_MONTH),
                    cal.get(Calendar.MONTH) + 1,
                    cal.get(Calendar.YEAR)};
        } catch (Exception e) {
            return null;
        }
    }

    public static int[] parts(String isoDate) { return parts(isoDate, 0); }

    // Localized one-line Hijri date: "25 جمادی الاولی 1448 ھ" (ur),
    // "25 Jumada al-Ula 1448 AH" (en), "25 جمادى الأولى 1448 هـ" (ar).
    // Latin digits always (Ui.latinDigits guarantee applied by callers'
    // font pass as well).
    public static String format(String isoDate, String lang) {
        int[] p = parts(isoDate);
        if (p == null) return "";
        String month;
        String suffix;
        if ("en".equals(lang)) { month = MONTHS_EN[p[1] - 1]; suffix = "AH"; }
        else if ("ar".equals(lang)) { month = MONTHS_AR[p[1] - 1]; suffix = "هـ"; }
        else { month = MONTHS_UR[p[1] - 1]; suffix = "ھ"; }
        return Ui.latinDigits(p[0] + " " + month + " " + p[2] + " " + suffix);
    }

    // Gregorian "05 Nov 2026"-style short date in the app locale.
    public static String gregorianShort(String isoDate, String lang) {
        try {
            LocalDate d = LocalDate.parse(isoDate);
            Locale loc = "ar".equals(lang) ? new Locale("ar") : new Locale("en");
            java.time.format.DateTimeFormatter f =
                    java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", loc);
            return Ui.latinDigits(d.format(f));
        } catch (Exception e) {
            return isoDate == null ? "" : isoDate;
        }
    }

    // "05 Nov 2026 • 25 جمادی الاولی 1448 ھ" — the standard dual line.
    public static String bothLine(String isoDate, String lang) {
        return gregorianShort(isoDate, lang) + "  •  " + format(isoDate, lang);
    }
}
