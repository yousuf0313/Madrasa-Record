package com.madrasarecord.app;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

// Auth-account replacement (v1.0.11) — the ONLY password-reset mechanism
// in this app: Firebase's email reset is useless (accounts sign in with
// internal pseudo-emails the user never sees) and there is no SMS/OTP.
// A brand-new Firebase Auth account is created with a NEW unique
// pseudo-email and the new password, on a SECONDARY FirebaseApp instance
// (the exact technique UsersActivity uses to create accounts, so any
// signed-in session on the main auth is undisturbed). The user doc then
// MOVES to the new uid: user docs are keyed by auth uid (Splash and
// Login both resolve document(currentUid)), so the doc must live under
// the new uid for the sign-in chain to keep working. In the moved doc
// the ONLY values changed are the identity fields: "email" and the new
// "authEmail" (the email this account currently signs in with) — name,
// role, mobile, loginType, recoveryHash and everything else are carried
// over unchanged. If the replaced account is the madrasa owner, the
// config/setup owner pointer moves in the same batch.
public final class AccountReset {

    public interface Done {
        void onDone(boolean ok, String newUid, String newEmail);
    }

    private AccountReset() {}

    private static String uniquePseudoEmail(String canonicalMobile) {
        String alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
        SecureRandom rnd = new SecureRandom();
        StringBuilder suffix = new StringBuilder();
        for (int i = 0; i < 6; i++) suffix.append(alphabet.charAt(rnd.nextInt(alphabet.length())));
        return canonicalMobile + "." + suffix + AuthHelp.PSEUDO_DOMAIN;
    }

    public static void replacePassword(Context ctx, String oldUid, Map<String, Object> oldData,
                                       String canonicalMobile, String newPassword, Done cb) {
        // Read the owner pointer first so it can move in the same batch.
        Db.fs().collection(Db.CONFIG).document(Db.CONFIG_DOC).get()
                .addOnSuccessListener(setup -> createAccount(ctx, oldUid, oldData, canonicalMobile,
                        newPassword, setup, cb))
                .addOnFailureListener(e -> createAccount(ctx, oldUid, oldData, canonicalMobile,
                        newPassword, null, cb));
    }

    private static void createAccount(Context ctx, String oldUid, Map<String, Object> oldData,
                                      String canonicalMobile, String newPassword,
                                      DocumentSnapshot setup, Done cb) {
        final String newEmail = uniquePseudoEmail(canonicalMobile);
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(FbConfig.API_KEY)
                .setApplicationId(FbConfig.APP_ID)
                .setProjectId(FbConfig.PROJECT_ID)
                .setGcmSenderId(FbConfig.SENDER_ID)
                .setStorageBucket(FbConfig.STORAGE_BUCKET)
                .build();
        FirebaseApp secondary;
        try {
            secondary = FirebaseApp.initializeApp(ctx, options, "secondary");
        } catch (IllegalStateException dup) {
            secondary = FirebaseApp.getInstance("secondary");
        }
        FirebaseAuth secAuth = FirebaseAuth.getInstance(secondary);
        FirebaseApp secApp = secondary;
        secAuth.createUserWithEmailAndPassword(newEmail, newPassword)
                .addOnSuccessListener(res -> {
                    String newUid = res.getUser().getUid();
                    Map<String, Object> data = new HashMap<>();
                    if (oldData != null) data.putAll(oldData);
                    data.put("email", newEmail);
                    data.put("authEmail", newEmail);
                    WriteBatch batch = Db.fs().batch();
                    batch.set(Db.fs().collection(Db.USERS).document(newUid), data);
                    batch.delete(Db.fs().collection(Db.USERS).document(oldUid));
                    if (setup != null && setup.exists() && oldUid.equals(strField(setup, "ownerUid"))) {
                        Map<String, Object> owner = new HashMap<>();
                        owner.put("ownerUid", newUid);
                        owner.put("ownerEmail", newEmail);
                        batch.update(Db.fs().collection(Db.CONFIG).document(Db.CONFIG_DOC), owner);
                    }
                    batch.commit()
                            .addOnSuccessListener(x -> {
                                secAuth.signOut();
                                secApp.delete();
                                cb.onDone(true, newUid, newEmail);
                            })
                            .addOnFailureListener(e -> {
                                secAuth.signOut();
                                secApp.delete();
                                cb.onDone(false, null, null);
                            });
                })
                .addOnFailureListener(e -> {
                    secApp.delete();
                    cb.onDone(false, null, null);
                });
    }

    // Instanceof-safe field read (same hardening pattern as SplashActivity).
    private static String strField(DocumentSnapshot doc, String field) {
        try {
            Object v = doc.get(field);
            return v instanceof String ? (String) v : null;
        } catch (Exception e) {
            return null;
        }
    }
}
