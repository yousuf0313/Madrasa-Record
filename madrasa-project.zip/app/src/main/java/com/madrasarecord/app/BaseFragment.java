package com.madrasarecord.app;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.post(() -> { if (getContext() != null) Ui.applyFont(view, getContext()); });
    }

    protected void applyFonts(View v) {
        if (getContext() != null && v != null) Ui.applyFont(v, getContext());
    }
}
