package com.madrasarecord.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Language + font preferences and application helpers.
public final class Ui {
    private static final String PREFS = "ui_prefs";
    private static final String KEY_LANG = "lang";
    private static final String KEY_FONT = "font";

    public static final class FontDef {
        public final String id, label, asset;
        FontDef(String id, String label, String asset) { this.id = id; this.label = label; this.asset = asset; }
    }

    // 12 Urdu/Arabic-script fonts (assets/fonts), all real Google Fonts TTFs.
    public static final List<FontDef> SCRIPT_FONTS = new ArrayList<>();
    // 4 English fonts.
    public static final List<FontDef> LATIN_FONTS = new ArrayList<>();
    static {
        SCRIPT_FONTS.add(new FontDef("nastaliq", "Noto Nastaliq Urdu — نستعلیق", "fonts/NotoNastaliqUrdu.ttf"));
        SCRIPT_FONTS.add(new FontDef("naskh", "Noto Naskh Arabic — نسخ", "fonts/NotoNaskhArabic.ttf"));
        SCRIPT_FONTS.add(new FontDef("amiri", "Amiri — امیری", "fonts/Amiri.ttf"));
        SCRIPT_FONTS.add(new FontDef("scheherazade", "Scheherazade New — شہرازاد", "fonts/ScheherazadeNew.ttf"));
        SCRIPT_FONTS.add(new FontDef("lateef", "Lateef — لطیف", "fonts/Lateef.ttf"));
        SCRIPT_FONTS.add(new FontDef("gulzar", "Gulzar — گلزار", "fonts/Gulzar.ttf"));
        SCRIPT_FONTS.add(new FontDef("katibeh", "Katibeh — کتیبہ", "fonts/Katibeh.ttf"));
        SCRIPT_FONTS.add(new FontDef("mirza", "Mirza — میرزا", "fonts/Mirza.ttf"));
        SCRIPT_FONTS.add(new FontDef("ruqaa", "Aref Ruqaa — رقعہ", "fonts/ArefRuqaa.ttf"));
        SCRIPT_FONTS.add(new FontDef("kufi", "Reem Kufi — کوفی", "fonts/ReemKufi.ttf"));
        SCRIPT_FONTS.add(new FontDef("baloo", "Baloo Bhaijaan 2 — بھائی جان", "fonts/BalooBhaijaan2.ttf"));
        SCRIPT_FONTS.add(new FontDef("harmattan", "Harmattan — ہرمتن", "fonts/Harmattan.ttf"));
        LATIN_FONTS.add(new FontDef("roboto", "Roboto", "fonts/Roboto.ttf"));
        LATIN_FONTS.add(new FontDef("poppins", "Poppins", "fonts/Poppins.ttf"));
        LATIN_FONTS.add(new FontDef("lato", "Lato", "fonts/Lato.ttf"));
        LATIN_FONTS.add(new FontDef("montserrat", "Montserrat", "fonts/Montserrat.ttf"));
    }

    private static Typeface cachedTypeface;
    private static String cachedFontId;
    private static Typeface cachedHeaderTypeface;
    private static Typeface cachedDigitTypeface;

    private Ui() {}

    // ---- Latin digits ONLY (user's standing rule, v1.0.3): all numbers in
    // the app — serials, dates, ages, totals, percentages, phone numbers —
    // use English digits 0-9. Urdu/Arabic-Indic digits (۰۱۲۳ U+06F0-06F9 and
    // ٠١٢٣ U+0660-0669) must never appear, even in the Urdu UI. ----
    public static String latinDigits(String s) {
        if (s == null) return null;
        StringBuilder b = null;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            int d = -1;
            if (ch >= '\u0660' && ch <= '\u0669') d = ch - '\u0660';        // U+0660-0669 Arabic-Indic
            else if (ch >= '\u06F0' && ch <= '\u06F9') d = ch - '\u06F0';   // U+06F0-06F9 Extended Arabic-Indic (Urdu)
            if (d >= 0) {
                if (b == null) { b = new StringBuilder(s.length()); b.append(s, 0, i); }
                b.append((char) ('0' + d));
            } else if (b != null) {
                b.append(ch);
            }
        }
        return b == null ? s : b.toString();
    }

    // Span that forces one run of text into the Latin-digit typeface (bundled
    // Roboto), so the Nastaliq/Naskh UI fonts cannot render Urdu-style
    // digit glyphs for ASCII digits either.
    public static final class LatinDigitSpan extends MetricAffectingSpan {
        private final Typeface digitTf;
        LatinDigitSpan(Typeface digitTf) { this.digitTf = digitTf; }
        @Override public void updateDrawState(TextPaint p) { apply(p); }
        @Override public void updateMeasureState(TextPaint p) { apply(p); }
        private void apply(TextPaint p) {
            int style = p.getTypeface() != null ? p.getTypeface().getStyle() : Typeface.NORMAL;
            p.setTypeface(Typeface.create(digitTf, style));
        }
    }

    public static Typeface digitTypeface(Context c) {
        if (cachedDigitTypeface == null) {
            try {
                cachedDigitTypeface = Typeface.createFromAsset(c.getAssets(), "fonts/Roboto.ttf");
            } catch (Exception e) {
                cachedDigitTypeface = Typeface.SANS_SERIF;
            }
        }
        return cachedDigitTypeface;
    }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String lang(Context c) {
        return prefs(c).getString(KEY_LANG, "ur");
    }

    public static void setLang(Context c, String lang) {
        prefs(c).edit().putString(KEY_LANG, lang).apply();
    }

    public static String fontId(Context c) {
        return prefs(c).getString(KEY_FONT, "nastaliq");
    }

    public static void setFontId(Context c, String id) {
        prefs(c).edit().putString(KEY_FONT, id).apply();
        cachedTypeface = null;
        cachedFontId = null;
    }

    public static FontDef findFont(String id) {
        for (FontDef f : SCRIPT_FONTS) if (f.id.equals(id)) return f;
        for (FontDef f : LATIN_FONTS) if (f.id.equals(id)) return f;
        return SCRIPT_FONTS.get(0);
    }

    public static Typeface typeface(Context c) {
        String id = fontId(c);
        if (cachedTypeface == null || !id.equals(cachedFontId)) {
            try {
                cachedTypeface = Typeface.createFromAsset(c.getAssets(), findFont(id).asset);
            } catch (Exception e) {
                cachedTypeface = Typeface.DEFAULT;
            }
            cachedFontId = id;
        }
        return cachedTypeface;
    }

    // Wrap a context with the chosen language (ur default, RTL handled by resources).
    // The numbering system is forced to Latin (nu=latn) for EVERY language so
    // all system/resource-formatted numbers come out as 0-9, never Urdu digits.
    public static Context wrap(Context base) {
        String lang = lang(base);
        Locale locale;
        try {
            locale = Locale.forLanguageTag(lang + "-u-nu-latn");
            if (locale == null || "und".equals(locale.toLanguageTag())) throw new IllegalArgumentException();
        } catch (Exception e) {
            locale = new Locale(lang);
        }
        Locale.setDefault(locale);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(locale);
        cfg.setLayoutDirection(locale);
        return base.createConfigurationContext(cfg);
    }

    // Decorative display typeface for the madrasa-name header (Katibeh,
    // bundled in assets/fonts). Independent of the user's UI font choice.
    public static Typeface headerTypeface(Context c) {
        if (cachedHeaderTypeface == null) {
            try {
                cachedHeaderTypeface = Typeface.createFromAsset(c.getAssets(), "fonts/Katibeh.ttf");
            } catch (Exception e) {
                cachedHeaderTypeface = Typeface.DEFAULT_BOLD;
            }
        }
        return cachedHeaderTypeface;
    }

    // Apply the chosen font to every text-bearing view in the tree.
    public static void applyFont(View root, Context ctx) {
        if (root == null) return;
        Typeface tf = typeface(ctx);
        applyFontRec(root, tf, ctx);
    }

    private static void applyFontRec(View v, Typeface tf, Context ctx) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            // Latin digits everywhere: normalize any Urdu/Arabic-Indic digit
            // characters to 0-9 and force digit runs into the Roboto digit
            // typeface so the script UI font cannot draw Urdu-style glyphs.
            normalizeDigits(tv, ctx);
            // Views tagged "keepFont" (the madrasa-name header) keep their own typeface.
            if (!"keepFont".equals(v.getTag())) {
                int style = tv.getTypeface() != null ? tv.getTypeface().getStyle() : Typeface.NORMAL;
                tv.setTypeface(tf, style);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) applyFontRec(vg.getChildAt(i), tf, ctx);
        }
    }

    // Idempotent: applyFont runs repeatedly (onResume, after every load), so
    // a TextView whose text is already normalized and already carries the
    // digit span is left untouched.
    private static void normalizeDigits(TextView tv, Context ctx) {
        CharSequence raw = tv.getText();
        if (raw == null || raw.length() == 0) return;
        String norm = latinDigits(raw.toString());
        if (tv instanceof android.widget.EditText) {
            // Never setText()/span an editable field in the font pass: on a
            // field with a TextWatcher (the Students search box) setText
            // re-fires the watcher synchronously -> re-entrant applyFont ->
            // possible StackOverflow / RecyclerView layout crash (audit
            // F-1). Only repair actually-present Urdu/Arabic digits; the
            // follow-up pass then sees pure ASCII and returns, so it
            // terminates. ASCII digits in fields are already correct.
            if (!norm.contentEquals(raw)) {
                int sel = ((android.widget.EditText) tv).getSelectionStart();
                tv.setText(norm);
                try {
                    ((android.widget.EditText) tv).setSelection(
                            Math.max(0, Math.min(sel, norm.length())));
                } catch (Exception ignored) { }
            }
            return;
        }
        boolean hasDigit = false;
        for (int i = 0; i < norm.length(); i++) {
            char ch = norm.charAt(i);
            if (ch >= '0' && ch <= '9') { hasDigit = true; break; }
        }
        if (!hasDigit) {
            if (!norm.contentEquals(raw)) tv.setText(norm);
            return;
        }
        if (norm.contentEquals(raw) && raw instanceof Spanned
                && ((Spanned) raw).getSpans(0, raw.length(), LatinDigitSpan.class).length > 0) {
            return; // already normalized + spanned
        }
        Typeface dtf = digitTypeface(ctx);
        SpannableString ss = new SpannableString(norm);
        int runStart = -1;
        for (int i = 0; i <= norm.length(); i++) {
            boolean digit = i < norm.length() && norm.charAt(i) >= '0' && norm.charAt(i) <= '9';
            if (digit && runStart < 0) runStart = i;
            if (!digit && runStart >= 0) {
                ss.setSpan(new LatinDigitSpan(dtf), runStart, i, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                runStart = -1;
            }
        }
        tv.setText(ss);
    }
}
