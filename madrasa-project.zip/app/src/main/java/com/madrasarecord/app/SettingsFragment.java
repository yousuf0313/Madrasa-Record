package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsFragment extends BaseFragment {

    private ActivityResultLauncher<String> backupCreate;
    private ActivityResultLauncher<String[]> backupOpen;
    private String pendingBackupJson;

    private static final int[] GUIDE_TITLES = {
            R.string.guide1, R.string.guide2, R.string.guide3, R.string.guide4, R.string.guide5,
            R.string.guide6, R.string.guide7, R.string.guide8, R.string.guide9, R.string.guide10,
            R.string.guide11, R.string.guide12};
    private static final int[] GUIDE_BODIES = {
            R.string.guide1b, R.string.guide2b, R.string.guide3b, R.string.guide4b, R.string.guide5b,
            R.string.guide6b, R.string.guide7b, R.string.guide8b, R.string.guide9b, R.string.guide10b,
            R.string.guide11b, R.string.guide12b};

    // کلاس کے اوقات editor state (Db.CLASS_TIME_KEYS order).
    private final Map<String, String> classTimes = new HashMap<>();
    private final Button[] timeBtns = new Button[6];

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backupCreate = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("application/json"), uri -> {
                    if (uri != null && pendingBackupJson != null) writeBackupTo(uri);
                    pendingBackupJson = null;
                });
        backupOpen = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), uri -> {
                    if (uri != null) confirmRestore(uri);
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1) آج کی آیت و حدیث — prominent entry at the TOP (opens its own
        // page; the verses live only there).
        view.findViewById(R.id.dailyEntry).setOnClickListener(v ->
                startActivity(new Intent(getContext(), DailyActivity.class)));

        // 2) استعمال کا طریقہ — 12-topic accordion guide (v1.2.0 added
        // کلاس کے اوقات + قرآنی پیش رفت; bodies 1/2/3/5/7 now state the
        // equal-powers rule).
        buildGuide(view.findViewById(R.id.guideBox));

        // 3) Backup / restore (both roles).
        view.findViewById(R.id.backupDownloadBtn).setOnClickListener(v -> startBackupDownload());
        view.findViewById(R.id.backupRestoreBtn).setOnClickListener(v ->
                backupOpen.launch(new String[]{"application/json", "text/plain", "*/*"}));

        // 4) Account line + language + font + recovery.
        TextView userLine = view.findViewById(R.id.settingsUserLine);
        String name = MadrasaApp.get().userName();
        String role = MadrasaApp.get().isTeacher() ? getString(R.string.role_teacher) : getString(R.string.role_muhtamim);
        userLine.setText((name == null ? "" : name) + " — " + getString(R.string.your_role) + ": " + role);

        RadioGroup langGroup = view.findViewById(R.id.langGroup);
        String lang = Ui.lang(requireContext());
        ((RadioButton) view.findViewById(R.id.langUr)).setChecked("ur".equals(lang));
        ((RadioButton) view.findViewById(R.id.langEn)).setChecked("en".equals(lang));
        ((RadioButton) view.findViewById(R.id.langAr)).setChecked("ar".equals(lang));
        langGroup.setOnCheckedChangeListener((g, id) -> {
            String chosen = id == R.id.langEn ? "en" : id == R.id.langAr ? "ar" : "ur";
            if (!chosen.equals(Ui.lang(requireContext()))) {
                Ui.setLang(requireContext(), chosen);
                requireActivity().recreate();
            }
        });

        TextView fontCurrent = view.findViewById(R.id.fontCurrent);
        fontCurrent.setText(Ui.findFont(Ui.fontId(requireContext())).label + "\n" + getString(R.string.font_preview));
        fontCurrent.setTypeface(Ui.typeface(requireContext()));
        view.findViewById(R.id.fontPickBtn).setOnClickListener(v -> pickFont());
        view.findViewById(R.id.recoveryBtn).setOnClickListener(v -> showRecoveryDialog());

        // 5) Madrasa name + class times + account management — BOTH
        // roles, EQUAL powers (v1.2.0 standing rule).
        View nameBox = view.findViewById(R.id.madrasaNameBox);
        nameBox.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        EditText nameInput = view.findViewById(R.id.madrasaNameInput);
        Db.loadMadrasaName(n -> { if (nameInput.getText().toString().trim().isEmpty()) nameInput.setText(n); });
        view.findViewById(R.id.madrasaNameSaveBtn).setOnClickListener(v -> {
            String n = nameInput.getText() == null ? "" : nameInput.getText().toString().trim();
            if (n.isEmpty()) return;
            Db.saveMadrasaName(n).addOnSuccessListener(x -> {
                if (getContext() != null)
                    Toast.makeText(getContext(), R.string.madrasa_name_saved, Toast.LENGTH_SHORT).show();
            });
        });
        // کلاس کے اوقات (both roles): per-session start/end pickers.
        View timesBox = view.findViewById(R.id.classTimesBox);
        timesBox.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        buildClassTimes(view);
        // Account management: two mirrored cards — محتمم صاحب کا
        // اکاؤنٹ (the existing flow) and استاد کا اکاؤنٹ (v1.2.0). Each
        // opens the account list filtered to that role, where accounts
        // are created, given a TPIN and deleted (with the own-account
        // and last-teacher guards in UsersActivity).
        View muhtamimBox = view.findViewById(R.id.muhtamimBox);
        muhtamimBox.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        view.findViewById(R.id.muhtamimUsersBtn).setOnClickListener(v -> {
            Intent i = new Intent(getContext(), UsersActivity.class);
            i.putExtra("role", "muhtamim");
            startActivity(i);
        });
        View teacherBox = view.findViewById(R.id.teacherBox);
        teacherBox.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        view.findViewById(R.id.teacherUsersBtn).setOnClickListener(v -> {
            Intent i = new Intent(getContext(), UsersActivity.class);
            i.putExtra("role", "teacher");
            startActivity(i);
        });

        // 6) About / version / update / sign out.
        view.findViewById(R.id.checkUpdateBtn).setOnClickListener(v -> {
            try { UpdateCheck.check(requireActivity(), true); } catch (Throwable ignored) { }
        });
        TextView versionTv = view.findViewById(R.id.versionTv);
        versionTv.setText(getString(R.string.version_lbl) + " " + BuildConfig.VERSION_NAME);
        view.findViewById(R.id.settingsSignOut).setOnClickListener(v -> {
            MadrasaApp.get().auth().signOut();
            MadrasaApp.get().clearSession();
            Intent i = new Intent(getContext(), SplashActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }

    // ---------------- class times (v1.2.0) ----------------
    // Per-session start/end, picked with TimePicker dialogs and stored
    // as "HH:MM" in the config doc (Db). Buttons show the 12-hour Urdu
    // form. Nothing is written until «اوقات محفوظ کریں» is tapped.

    private void buildClassTimes(View view) {
        classTimes.clear();
        classTimes.putAll(Db.defaultClassTimes());
        int[] ids = {R.id.timeMorningStart, R.id.timeMorningEnd, R.id.timeMiddayStart,
                R.id.timeMiddayEnd, R.id.timeEveningStart, R.id.timeEveningEnd};
        for (int i = 0; i < ids.length; i++) {
            timeBtns[i] = view.findViewById(ids[i]);
            final String key = Db.CLASS_TIME_KEYS[i];
            timeBtns[i].setOnClickListener(v -> pickTime(key));
        }
        renderTimeButtons();
        Db.loadClassTimes(times -> {
            classTimes.clear();
            classTimes.putAll(times);
            if (getView() != null) renderTimeButtons();
        });
        view.findViewById(R.id.saveTimesBtn).setOnClickListener(v ->
                Db.saveClassTimes(classTimes)
                        .addOnSuccessListener(x -> toast(R.string.times_saved))
                        .addOnFailureListener(e -> toast(R.string.err_generic)));
    }

    private void renderTimeButtons() {
        if (getContext() == null) return;
        for (int i = 0; i < Db.CLASS_TIME_KEYS.length; i++) {
            if (timeBtns[i] != null) {
                timeBtns[i].setText(Db.fmtClock(requireContext(), classTimes.get(Db.CLASS_TIME_KEYS[i])));
            }
        }
    }

    private void pickTime(String key) {
        String cur = classTimes.get(key);
        int h = 7, m = 0;
        if (cur != null && cur.length() == 5) {
            try {
                h = Integer.parseInt(cur.substring(0, 2));
                m = Integer.parseInt(cur.substring(3, 5));
            } catch (Exception ignored) { }
        }
        new android.app.TimePickerDialog(requireContext(), (v, hour, minute) -> {
            classTimes.put(key, String.format(java.util.Locale.US, "%02d:%02d", hour, minute));
            renderTimeButtons();
        }, h, m, false).show();
    }

    // ---------------- guide accordion ----------------

    private void buildGuide(LinearLayout box) {
        for (int i = 0; i < GUIDE_TITLES.length; i++) {
            TextView title = new TextView(requireContext());
            title.setText(getString(GUIDE_TITLES[i]) + "  ▾");
            title.setTextSize(14.5f);
            title.setTextColor(getResources().getColor(R.color.ink, null));
            title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
            title.setPadding(0, 10, 0, 6);
            TextView body = new TextView(requireContext());
            body.setText(GUIDE_BODIES[i]);
            body.setTextSize(13.5f);
            body.setTextColor(getResources().getColor(R.color.muted, null));
            body.setLineSpacing(0, 1.5f);
            body.setVisibility(View.GONE);
            title.setOnClickListener(v -> body.setVisibility(
                    body.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
            box.addView(title);
            box.addView(body);
            View rule = new View(requireContext());
            rule.setBackgroundColor(getResources().getColor(R.color.line, null));
            rule.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            box.addView(rule);
        }
        Ui.applyFont(box, requireContext());
    }

    // ---------------- backup / restore ----------------
    // One JSON file: all students (every field, incl. graduated,
    // completionLabel, pledgeClause2Struck, section + the قرآنی پیش
    // رفت standing fields), ALL madrasa_attendance docs (class +
    // punc_* + lesson), ALL madrasa_manzil docs (v1.2.0), and the
    // config values the app owns (madrasaName + hijriOffsetDays +
    // classTimes, v1.2.0). Accounts are never touched.

    private void startBackupDownload() {
        final JSONObject root = new JSONObject();
        try {
            root.put("app", "madrasa-backup");
            root.put("version", 1);
            root.put("exportedAt", Db.today());
        } catch (Exception ignored) { }
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(sq -> {
            try {
                JSONArray arr = new JSONArray();
                for (DocumentSnapshot d : sq.getDocuments()) {
                    JSONObject o = new JSONObject();
                    o.put("id", d.getId());
                    Map<String, Object> data = d.getData();
                    if (data != null) {
                        for (Map.Entry<String, Object> e : data.entrySet()) {
                            Object v = e.getValue();
                            if (v instanceof com.google.firebase.Timestamp) {
                                o.put(e.getKey(), ((com.google.firebase.Timestamp) v).toDate().getTime());
                                o.put(e.getKey() + "__ts", true);
                            } else if (v instanceof List) {
                                o.put(e.getKey(), new JSONArray((List<?>) v));
                            } else if (v != null) {
                                o.put(e.getKey(), v);
                            }
                        }
                    }
                    arr.put(o);
                }
                root.put("students", arr);
            } catch (Exception ignored) { }
            Db.fs().collection(Db.ATTENDANCE).get().addOnSuccessListener(aq -> {
                try {
                    JSONArray arr = new JSONArray();
                    for (DocumentSnapshot d : aq.getDocuments()) {
                        JSONObject o = new JSONObject();
                        o.put("id", d.getId());
                        Map<String, Object> data = d.getData();
                        if (data != null) {
                            for (Map.Entry<String, Object> e : data.entrySet()) {
                                Object v = e.getValue();
                                if (v instanceof Map) o.put(e.getKey(), new JSONObject((Map<?, ?>) v));
                                else if (v instanceof List) o.put(e.getKey(), new JSONArray((List<?>) v));
                                else if (v != null) o.put(e.getKey(), v);
                            }
                        }
                        arr.put(o);
                    }
                    root.put("attendance", arr);
                } catch (Exception ignored) { }
                Db.fs().collection(Db.MANZIL).get().addOnSuccessListener(mq -> {
                    try {
                        JSONArray arr = new JSONArray();
                        for (DocumentSnapshot d : mq.getDocuments()) {
                            JSONObject o = new JSONObject();
                            o.put("id", d.getId());
                            Map<String, Object> data = d.getData();
                            if (data != null) {
                                for (Map.Entry<String, Object> e : data.entrySet()) {
                                    Object v = e.getValue();
                                    if (v instanceof Map) o.put(e.getKey(), new JSONObject((Map<?, ?>) v));
                                    else if (v instanceof List) o.put(e.getKey(), new JSONArray((List<?>) v));
                                    else if (v != null) o.put(e.getKey(), v);
                                }
                            }
                            arr.put(o);
                        }
                        root.put("manzil", arr);
                    } catch (Exception ignored) { }
                Db.fs().collection(Db.CONFIG).document(Db.CONFIG_DOC).get().addOnSuccessListener(cfg -> {
                    try {
                        JSONObject c = new JSONObject();
                        if (cfg != null && cfg.exists()) {
                            Object mn = cfg.get("madrasaName");
                            if (mn instanceof String) c.put("madrasaName", mn);
                            Object ho = cfg.get("hijriOffsetDays");
                            if (ho instanceof Number) c.put("hijriOffsetDays", ((Number) ho).longValue());
                            Object ct = cfg.get("classTimes");
                            if (ct instanceof Map) c.put("classTimes", new JSONObject((Map<?, ?>) ct));
                        }
                        root.put("config", c);
                    } catch (Exception ignored) { }
                    pendingBackupJson = root.toString();
                    backupCreate.launch("madrasa-backup.json");
                }).addOnFailureListener(e -> toast(R.string.backup_failed));
                }).addOnFailureListener(e -> toast(R.string.backup_failed));
            }).addOnFailureListener(e -> toast(R.string.backup_failed));
        }).addOnFailureListener(e -> toast(R.string.backup_failed));
    }

    private void writeBackupTo(Uri uri) {
        try {
            OutputStream os = requireContext().getContentResolver().openOutputStream(uri);
            if (os == null) throw new Exception("no stream");
            os.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
            os.close();
            toast(R.string.backup_done);
        } catch (Exception e) {
            toast(R.string.backup_failed);
        }
    }

    private void confirmRestore(final Uri uri) {
        new AlertDialog.Builder(requireContext())
                .setMessage(R.string.backup_restore_q)
                .setPositiveButton(R.string.yes, (d, w) -> doRestore(uri))
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void doRestore(final Uri uri) {
        try {
            InputStream is = requireContext().getContentResolver().openInputStream(uri);
            if (is == null) throw new Exception("no stream");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            final JSONObject root = new JSONObject(new String(bos.toByteArray(), StandardCharsets.UTF_8));
            if (!"madrasa-backup".equals(root.optString("app"))) throw new Exception("not a backup");
            // Replace students + attendance + manzil wholesale;
            // accounts untouched.
            Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(sq -> {
                Db.fs().collection(Db.ATTENDANCE).get().addOnSuccessListener(aq -> {
                Db.fs().collection(Db.MANZIL).get().addOnSuccessListener(mq -> {
                    WriteBatch batch = Db.fs().batch();
                    final int[] count = {0};
                    final List<WriteBatch> batches = new ArrayList<>();
                    batches.add(batch);
                    // Deletes first.
                    for (DocumentSnapshot d : sq.getDocuments()) {
                        batches.get(batches.size() - 1).delete(d.getReference());
                        if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                    }
                    for (DocumentSnapshot d : aq.getDocuments()) {
                        batches.get(batches.size() - 1).delete(d.getReference());
                        if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                    }
                    for (DocumentSnapshot d : mq.getDocuments()) {
                        batches.get(batches.size() - 1).delete(d.getReference());
                        if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                    }
                    try {
                        JSONArray students = root.optJSONArray("students");
                        if (students != null) {
                            for (int i = 0; i < students.length(); i++) {
                                JSONObject o = students.getJSONObject(i);
                                String id = o.getString("id");
                                Map<String, Object> data = jsonToMap(o, true);
                                data.remove("id");
                                batches.get(batches.size() - 1)
                                        .set(Db.fs().collection(Db.STUDENTS).document(id), data);
                                if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                            }
                        }
                        JSONArray att = root.optJSONArray("attendance");
                        if (att != null) {
                            for (int i = 0; i < att.length(); i++) {
                                JSONObject o = att.getJSONObject(i);
                                String id = o.getString("id");
                                Map<String, Object> data = jsonToMap(o, false);
                                data.remove("id");
                                batches.get(batches.size() - 1)
                                        .set(Db.fs().collection(Db.ATTENDANCE).document(id), data);
                                if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                            }
                        }
                        JSONArray mz = root.optJSONArray("manzil");
                        if (mz != null) {
                            for (int i = 0; i < mz.length(); i++) {
                                JSONObject o = mz.getJSONObject(i);
                                String id = o.getString("id");
                                Map<String, Object> data = jsonToMap(o, false);
                                data.remove("id");
                                batches.get(batches.size() - 1)
                                        .set(Db.fs().collection(Db.MANZIL).document(id), data);
                                if (++count[0] % 400 == 0) batches.add(Db.fs().batch());
                            }
                        }
                    } catch (Exception e) {
                        toast(R.string.backup_failed);
                        return;
                    }
                    // Config: merge only the app-owned keys
                    // (madrasaName, hijriOffsetDays, classTimes).
                    JSONObject cfg = root.optJSONObject("config");
                    if (cfg != null) {
                        Map<String, Object> cm = new HashMap<>();
                        if (cfg.has("madrasaName")) cm.put("madrasaName", cfg.optString("madrasaName"));
                        if (cfg.has("hijriOffsetDays")) {
                            long ho = cfg.optLong("hijriOffsetDays", 0);
                            cm.put("hijriOffsetDays", ho);
                            Hijri.setOffset((int) ho);
                        }
                        JSONObject ct = cfg.optJSONObject("classTimes");
                        if (ct != null) {
                            Map<String, Object> ctm = new HashMap<>();
                            java.util.Iterator<String> ctk = ct.keys();
                            while (ctk.hasNext()) {
                                String k = ctk.next();
                                Object v = ct.opt(k);
                                if (v instanceof String) ctm.put(k, v);
                            }
                            if (!ctm.isEmpty()) cm.put("classTimes", ctm);
                        }
                        if (!cm.isEmpty()) {
                            Db.fs().collection(Db.CONFIG).document(Db.CONFIG_DOC)
                                    .set(cm, SetOptions.merge());
                        }
                    }
                    commitAll(batches, 0);
                }).addOnFailureListener(e -> toast(R.string.backup_failed));
                }).addOnFailureListener(e -> toast(R.string.backup_failed));
            }).addOnFailureListener(e -> toast(R.string.backup_failed));
        } catch (Exception e) {
            toast(R.string.backup_failed);
        }
    }

    private void commitAll(final List<WriteBatch> batches, final int idx) {
        if (idx >= batches.size()) {
            toast(R.string.backup_restored);
            return;
        }
        batches.get(idx).commit()
                .addOnSuccessListener(x -> commitAll(batches, idx + 1))
                .addOnFailureListener(e -> toast(R.string.backup_failed));
    }

    // JSONObject -> Firestore map. Keys flagged "<key>__ts": true in the
    // backup hold epoch millis and come back as Timestamps.
    private Map<String, Object> jsonToMap(JSONObject o, boolean timestamps) throws Exception {
        Map<String, Object> map = new HashMap<>();
        java.util.Iterator<String> keys = o.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            if (k.endsWith("__ts")) continue;
            Object v = o.get(k);
            if (v instanceof JSONObject) {
                map.put(k, jsonToMap((JSONObject) v, false));
            } else if (v instanceof JSONArray) {
                List<Object> list = new ArrayList<>();
                JSONArray a = (JSONArray) v;
                for (int i = 0; i < a.length(); i++) list.add(a.get(i));
                map.put(k, list);
            } else if (v instanceof Number && timestamps && o.optBoolean(k + "__ts")) {
                map.put(k, new com.google.firebase.Timestamp(
                        new java.util.Date(((Number) v).longValue())));
            } else {
                map.put(k, v);
            }
        }
        return map;
    }

    private void toast(int res) {
        if (getContext() != null) Toast.makeText(getContext(), res, Toast.LENGTH_LONG).show();
    }

    // ---------------- recovery code ----------------

    private void showRecoveryDialog() {
        EditText code = new EditText(requireContext());
        code.setHint(R.string.recovery_hint);
        code.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setFilters(new android.text.InputFilter[]{
                new android.text.InputFilter.LengthFilter(64)});
        TextView lenHint = new TextView(requireContext());
        lenHint.setText(R.string.recovery_len_hint);
        lenHint.setTextSize(12);
        lenHint.setPadding(0, 0, 0, 16);
        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        box.addView(lenHint);
        box.addView(code);
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.recovery_code_lbl)
                .setView(box)
                .setPositiveButton(R.string.save, (d, w) -> {
                    String c = code.getText().toString().trim();
                    if (c.length() < 4) {
                        toast(R.string.recovery_short);
                        return;
                    }
                    com.google.firebase.auth.FirebaseUser u = MadrasaApp.get().auth().getCurrentUser();
                    if (u == null) return;
                    Db.fs().collection(Db.USERS).document(u.getUid()).get()
                            .addOnSuccessListener(doc -> {
                                Object mv = doc.exists() ? doc.get("mobile") : null;
                                String mobile = mv instanceof String ? (String) mv : null;
                                if (mobile == null) {
                                    toast(R.string.err_generic);
                                    return;
                                }
                                Db.fs().collection(Db.USERS).document(u.getUid())
                                        .update("recoveryHash", AuthHelp.recoveryHash(mobile, c))
                                        .addOnSuccessListener(x -> toast(R.string.recovery_saved))
                                        .addOnFailureListener(e -> toast(R.string.err_generic));
                            })
                            .addOnFailureListener(e -> toast(R.string.err_generic));
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void pickFont() {
        List<Ui.FontDef> all = new ArrayList<>();
        all.addAll(Ui.SCRIPT_FONTS);
        all.addAll(Ui.LATIN_FONTS);
        String[] labels = new String[all.size()];
        for (int i = 0; i < all.size(); i++) labels[i] = all.get(i).label;
        String current = Ui.fontId(requireContext());
        int checked = 0;
        for (int i = 0; i < all.size(); i++) if (all.get(i).id.equals(current)) checked = i;
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.font_lbl)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    Ui.setFontId(requireContext(), all.get(which).id);
                    dialog.dismiss();
                    requireActivity().recreate();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
