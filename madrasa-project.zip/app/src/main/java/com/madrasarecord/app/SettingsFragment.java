package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends BaseFragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView userLine = view.findViewById(R.id.settingsUserLine);
        String name = MadrasaApp.get().userName();
        String role = MadrasaApp.get().isTeacher() ? getString(R.string.role_teacher) : getString(R.string.role_muhtamim);
        userLine.setText((name == null ? "" : name) + " — " + getString(R.string.your_role) + ": " + role);

        RadioGroup langGroup = view.findViewById(R.id.langGroup);
        String lang = Ui.lang(requireContext());
        ((RadioButton) view.findViewById(R.id.langUr)).setChecked("ur".equals(lang));
        ((RadioButton) view.findViewById(R.id.langEn)).setChecked("en".equals(lang));
        ((RadioButton) view.findViewById(R.id.langAr)).setChecked("ar".equals(lang));
        langGroup.setOnCheckedChangeListener((g, id) -> {
            String chosen = id == R.id.langEn ? "en" : id == R.id.langAr ? "ar" : "ur";
            if (!chosen.equals(Ui.lang(requireContext()))) {
                Ui.setLang(requireContext(), chosen);
                requireActivity().recreate();
            }
        });

        TextView fontCurrent = view.findViewById(R.id.fontCurrent);
        fontCurrent.setText(Ui.findFont(Ui.fontId(requireContext())).label + "\n" + getString(R.string.font_preview));
        fontCurrent.setTypeface(Ui.typeface(requireContext()));
        view.findViewById(R.id.fontPickBtn).setOnClickListener(v -> pickFont());

        // Madrasa name editing is Teacher-only; the Muhtamim never sees this box.
        View nameBox = view.findViewById(R.id.madrasaNameBox);
        boolean isTeacher = MadrasaApp.get().isTeacher();
        nameBox.setVisibility(isTeacher ? View.VISIBLE : View.GONE);
        if (isTeacher) {
            EditText nameInput = view.findViewById(R.id.madrasaNameInput);
            Db.loadMadrasaName(n -> { if (nameInput.getText().toString().trim().isEmpty()) nameInput.setText(n); });
            view.findViewById(R.id.madrasaNameSaveBtn).setOnClickListener(v -> {
                String n = nameInput.getText() == null ? "" : nameInput.getText().toString().trim();
                if (n.isEmpty()) return;
                Db.saveMadrasaName(n).addOnSuccessListener(x -> {
                    if (getContext() != null)
                        Toast.makeText(getContext(), R.string.madrasa_name_saved, Toast.LENGTH_SHORT).show();
                });
            });
        }

        // Recovery code (v1.0.11): every signed-in user sets their OWN
        // code; it is stored only as a hash in their user doc and is what
        // the login screen's "forgot password" flow asks for. Being
        // signed in is enough — no password re-entry (the write touches
        // only the user's own doc).
        view.findViewById(R.id.recoveryBtn).setOnClickListener(v -> showRecoveryDialog());

        View usersBox = view.findViewById(R.id.usersBox);
        usersBox.setVisibility(MadrasaApp.get().isTeacher() ? View.VISIBLE : View.GONE);
        view.findViewById(R.id.usersBtn).setOnClickListener(v ->
                startActivity(new Intent(getContext(), UsersActivity.class)));

        // Manual in-app update check (v1.0.5): same check as the automatic
        // one, but also tells the user when they are already up to date.
        view.findViewById(R.id.checkUpdateBtn).setOnClickListener(v -> {
            try { UpdateCheck.check(requireActivity(), true); } catch (Throwable ignored) { }
        });

        // Real build version (v1.0.8): the label comes from the string
        // resource, the number from BuildConfig — never hardcoded.
        TextView versionTv = view.findViewById(R.id.versionTv);
        versionTv.setText(getString(R.string.version_lbl) + " " + BuildConfig.VERSION_NAME);

        view.findViewById(R.id.settingsSignOut).setOnClickListener(v -> {
            MadrasaApp.get().auth().signOut();
            MadrasaApp.get().clearSession();
            Intent i = new Intent(getContext(), SplashActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }

    private void showRecoveryDialog() {
        EditText code = new EditText(requireContext());
        code.setHint(R.string.recovery_hint);
        code.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        // The code's length is the user's own choice — NOT a fixed-length
        // PIN: minimum 4 characters (checked on save), no fixed length,
        // only a sane 64-character cap.
        code.setFilters(new android.text.InputFilter[]{
                new android.text.InputFilter.LengthFilter(64)});
        TextView lenHint = new TextView(requireContext());
        lenHint.setText(R.string.recovery_len_hint);
        lenHint.setTextSize(12);
        lenHint.setPadding(0, 0, 0, 16);
        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 24, 48, 8);
        box.addView(lenHint);
        box.addView(code);
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.recovery_code_lbl)
                .setView(box)
                .setPositiveButton(R.string.save, (d, w) -> {
                    String c = code.getText().toString().trim();
                    if (c.length() < 4) {
                        if (getContext() != null)
                            Toast.makeText(getContext(), R.string.recovery_short, Toast.LENGTH_LONG).show();
                        return;
                    }
                    com.google.firebase.auth.FirebaseUser u = MadrasaApp.get().auth().getCurrentUser();
                    if (u == null) return;
                    Db.fs().collection(Db.USERS).document(u.getUid()).get()
                            .addOnSuccessListener(doc -> {
                                Object mv = doc.exists() ? doc.get("mobile") : null;
                                String mobile = mv instanceof String ? (String) mv : null;
                                if (mobile == null) {
                                    if (getContext() != null)
                                        Toast.makeText(getContext(), R.string.err_generic, Toast.LENGTH_LONG).show();
                                    return;
                                }
                                Db.fs().collection(Db.USERS).document(u.getUid())
                                        .update("recoveryHash", AuthHelp.recoveryHash(mobile, c))
                                        .addOnSuccessListener(x -> {
                                            if (getContext() != null)
                                                Toast.makeText(getContext(), R.string.recovery_saved, Toast.LENGTH_SHORT).show();
                                        })
                                        .addOnFailureListener(e -> {
                                            if (getContext() != null)
                                                Toast.makeText(getContext(), R.string.err_generic, Toast.LENGTH_LONG).show();
                                        });
                            })
                            .addOnFailureListener(e -> {
                                if (getContext() != null)
                                    Toast.makeText(getContext(), R.string.err_generic, Toast.LENGTH_LONG).show();
                            });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void pickFont() {
        List<Ui.FontDef> all = new ArrayList<>();
        all.addAll(Ui.SCRIPT_FONTS);
        all.addAll(Ui.LATIN_FONTS);
        String[] labels = new String[all.size()];
        for (int i = 0; i < all.size(); i++) labels[i] = all.get(i).label;
        String current = Ui.fontId(requireContext());
        int checked = 0;
        for (int i = 0; i < all.size(); i++) if (all.get(i).id.equals(current)) checked = i;
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.font_lbl)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    Ui.setFontId(requireContext(), all.get(which).id);
                    dialog.dismiss();
                    requireActivity().recreate();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
