package com.madrasarecord.app;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FieldValue;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

// Add / edit a student. Fields: photo, name, father's name, B-Form number,
// registration number, father's mobile numbers (dynamic, as many as needed —
// NO id-card field), class group, admission date, date of birth, manual age
// override, completion date, notes.
public class StudentEditActivity extends BaseActivity {
    private String studentId;      // null = new student
    private String admissionDate;
    private String dateOfBirth = "";
    private String completionDate = "";
    private Uri pendingPhotoUri;   // chosen/captured, not yet saved
    private File cameraFile;
    private ImageView photoIv;
    private LinearLayout mobileBox;
    private TextInputEditText inName, inFather, inBform, inReg, inAge, inNotes;
    private RadioGroup groupRadio;
    private Button admissionBtn, dobBtn, completionBtn;

    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) { pendingPhotoUri = uri; showPendingPhoto(); }
            });
    private final ActivityResultLauncher<Uri> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), ok -> {
                if (ok && cameraFile != null) { pendingPhotoUri = Uri.fromFile(cameraFile); showPendingPhoto(); }
            });
    private final ActivityResultLauncher<String> cameraPermLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) launchCamera();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_edit);
        studentId = getIntent().getStringExtra("studentId");
        admissionDate = Db.today();

        photoIv = findViewById(R.id.editPhoto);
        mobileBox = findViewById(R.id.mobileBox);
        inName = findViewById(R.id.inName);
        inFather = findViewById(R.id.inFather);
        inBform = findViewById(R.id.inBform);
        inReg = findViewById(R.id.inReg);
        inAge = findViewById(R.id.inAge);
        inNotes = findViewById(R.id.inNotes);
        groupRadio = findViewById(R.id.groupRadio);
        admissionBtn = findViewById(R.id.admissionBtn);
        dobBtn = findViewById(R.id.dobBtn);
        completionBtn = findViewById(R.id.completionBtn);
        ((TextView) findViewById(R.id.editTitle)).setText(studentId == null ? R.string.add_student_title : R.string.edit_student);

        findViewById(R.id.galleryBtn).setOnClickListener(v -> galleryLauncher.launch("image/*"));
        findViewById(R.id.cameraBtn).setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                launchCamera();
            } else {
                cameraPermLauncher.launch(Manifest.permission.CAMERA);
            }
        });
        findViewById(R.id.addMobileBtn).setOnClickListener(v -> addMobileRow(""));
        admissionBtn.setOnClickListener(v -> pickDate(admissionDate, false, val -> admissionDate = val));
        dobBtn.setOnClickListener(v -> pickDate(dateOfBirth, true, val -> dateOfBirth = val));
        completionBtn.setOnClickListener(v -> pickDate(completionDate, true, val -> completionDate = val));
        findViewById(R.id.saveStudentBtn).setOnClickListener(v -> save());

        addMobileRow("");
        updateDateBtns();
        if (studentId != null) loadExisting();
    }

    private void launchCamera() {
        File dir = new File(getCacheDir(), "camera");
        if (!dir.exists()) dir.mkdirs();
        cameraFile = new File(dir, "capture_" + System.currentTimeMillis() + ".jpg");
        Uri uri = FileProvider.getUriForFile(this, "com.madrasarecord.app.fileprovider", cameraFile);
        cameraLauncher.launch(uri);
    }

    private void showPendingPhoto() {
        photoIv.setImageURI(pendingPhotoUri);
    }

    private interface DateSetter { void set(String v); }

    private void pickDate(String current, boolean clearable, DateSetter setter) {
        Calendar cal = Calendar.getInstance();
        if (current != null && !current.isEmpty()) {
            try { cal.setTime(new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(current)); }
            catch (Exception ignored) {}
        }
        DatePickerDialog dlg = new DatePickerDialog(this, (dp, y, m, d) -> {
            setter.set(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d));
            updateDateBtns();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        if (clearable) {
            dlg.setButton(DatePickerDialog.BUTTON_NEUTRAL, getString(R.string.clear_lbl), (d, w) -> {
                setter.set("");
                updateDateBtns();
            });
        }
        dlg.show();
    }

    private void updateDateBtns() {
        admissionBtn.setText(getString(R.string.admission_date) + ": " + admissionDate);
        dobBtn.setText(getString(R.string.date_of_birth) + ": " + (dateOfBirth.isEmpty() ? "—" : dateOfBirth));
        completionBtn.setText(getString(R.string.completion_date) + ": " + (completionDate.isEmpty() ? "—" : completionDate));
    }

    private void addMobileRow(String value) {
        LinearLayout row = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.item_mobile_row, mobileBox, false);
        EditText input = row.findViewById(R.id.mobileInput);
        input.setText(value);
        row.findViewById(R.id.mobileRemove).setOnClickListener(v -> {
            if (mobileBox.getChildCount() > 1) mobileBox.removeView(row);
            else input.setText("");
        });
        mobileBox.addView(row);
        Ui.applyFont(row, this);
    }

    private List<String> collectMobiles() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < mobileBox.getChildCount(); i++) {
            EditText input = mobileBox.getChildAt(i).findViewById(R.id.mobileInput);
            String v = input.getText() == null ? "" : input.getText().toString().trim();
            // Numbers are stored with Latin digits only (0-9), whatever the
            // keyboard produced (Urdu digits are converted).
            v = Ui.latinDigits(v);
            if (!v.isEmpty()) out.add(v);
        }
        return out;
    }

    private void loadExisting() {
        Db.fs().collection(Db.STUDENTS).document(studentId).get().addOnSuccessListener(doc -> {
            if (!doc.exists()) return;
            Db.Student s = new Db.Student(doc);
            inName.setText(s.name);
            inFather.setText(s.fatherName);
            inBform.setText(s.bform);
            inReg.setText(s.registrationNumber);
            inAge.setText(s.ageManual);
            inNotes.setText(s.notes);
            admissionDate = s.admissionDate.isEmpty() ? Db.today() : s.admissionDate;
            dateOfBirth = s.dateOfBirth;
            completionDate = s.completionDate;
            updateDateBtns();
            groupRadio.check("nazra".equals(s.classGroup) ? R.id.grpNazra
                    : "qaida".equals(s.classGroup) ? R.id.grpQaida : R.id.grpHifz);
            mobileBox.removeAllViews();
            if (s.mobiles.isEmpty()) addMobileRow("");
            else for (String m : s.mobiles) addMobileRow(m);
            Db.loadPhoto(this, s, photoIv);
            applyFonts();
        });
    }

    private void save() {
        String name = text(inName), father = text(inFather);
        List<String> mobiles = collectMobiles();
        if (name.isEmpty()) { toast(R.string.fill_name); return; }
        if (father.isEmpty()) { toast(R.string.fill_father); return; }
        if (mobiles.isEmpty()) { toast(R.string.fill_mobile_one); return; }

        String group = groupRadio.getCheckedRadioButtonId() == R.id.grpNazra ? "nazra"
                : groupRadio.getCheckedRadioButtonId() == R.id.grpQaida ? "qaida" : "hifz";
        Map<String, Object> data = new HashMap<>();
        data.put("name", name);
        data.put("fatherName", father);
        // Numeric fields: Latin digits only before saving (user's rule).
        data.put("bform", Ui.latinDigits(text(inBform)));
        data.put("registrationNumber", Ui.latinDigits(text(inReg)));
        data.put("mobiles", mobiles);
        data.put("classGroup", group);
        data.put("admissionDate", admissionDate);
        data.put("dateOfBirth", dateOfBirth);
        data.put("ageManual", Ui.latinDigits(text(inAge)));
        data.put("completionDate", completionDate);
        data.put("notes", text(inNotes));
        data.put("updatedAt", FieldValue.serverTimestamp());

        if (studentId == null) {
            data.put("createdAt", FieldValue.serverTimestamp());
            Db.fs().collection(Db.STUDENTS).add(data).addOnSuccessListener(ref -> {
                finishSave(ref.getId());
            }).addOnFailureListener(e -> toast(R.string.err_generic));
        } else {
            Db.fs().collection(Db.STUDENTS).document(studentId).update(data)
                    .addOnSuccessListener(x -> finishSave(studentId))
                    .addOnFailureListener(e -> toast(R.string.err_generic));
        }
    }

    private void finishSave(String id) {
        if (pendingPhotoUri != null) {
            try {
                Db.saveCompressed(this, id, pendingPhotoUri);
                Db.uploadPhoto(id);
            } catch (Exception ignored) {}
        } else if (Db.photoFile(this, id).exists()) {
            Db.uploadPhoto(id);
        }
        Toast.makeText(this, studentId == null ? R.string.student_saved : R.string.student_updated, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void toast(int res) { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); }
    private static String text(TextInputEditText e) { return e.getText() == null ? "" : e.getText().toString().trim(); }
}
