package com.madrasarecord.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Report (v1.1.0): today's three class sessions with totals (incl.
// unmarked) and today's absent names, plus the last-7-days table.
// Graduated students are excluded everywhere. IMPORTANT: the weekly
// query reads the shared madrasa_attendance collection, which now also
// holds punc_* and lesson docs — only CLASS sessions are counted here.
// v1.2.0: a section filter (تمام شعبے / بنین / بنات) drives EVERY
// count and list on this page; two new boxes — «آج کا سبق» (today's
// lesson status per student) and «آج کی منزل» (today's manzil from
// madrasa_manzil). Both roles see the same report (equal powers).
public class ReportFragment extends BaseFragment {
    private TextView headingTv, madrasaTv;
    private final TextView[] sessionTvs = new TextView[3];
    private LinearLayout absentList, weeklyTable;
    private TextView weekTv, weekAbsentTv;
    private TextView sabaqCountsTv, manzilCountsTv;
    private LinearLayout sabaqNamesBox, manzilNamesBox;
    private SectionFilter sectionFilter;
    private final Map<String, String> studentNames = new HashMap<>();
    private final List<Db.Student> activeList = new ArrayList<>(); // serial order
    private final java.util.Set<String> allActiveIds = new java.util.HashSet<>();
    // The section-filtered active set every count/list below reads.
    private final java.util.Set<String> activeIds = new java.util.HashSet<>();
    private String lang = "ur";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        lang = Ui.lang(requireContext());
        headingTv = view.findViewById(R.id.reportHeading);
        madrasaTv = view.findViewById(R.id.reportMadrasa);
        sessionTvs[0] = view.findViewById(R.id.reportMorning);
        sessionTvs[1] = view.findViewById(R.id.reportMidday);
        sessionTvs[2] = view.findViewById(R.id.reportEvening);
        absentList = view.findViewById(R.id.absentList);
        weeklyTable = view.findViewById(R.id.weeklyTable);
        weekTv = view.findViewById(R.id.reportWeek);
        weekAbsentTv = view.findViewById(R.id.reportWeekAbsent);
        sabaqCountsTv = view.findViewById(R.id.reportSabaqCounts);
        manzilCountsTv = view.findViewById(R.id.reportManzilCounts);
        sabaqNamesBox = view.findViewById(R.id.reportSabaqNames);
        manzilNamesBox = view.findViewById(R.id.reportManzilNames);
        sectionFilter = new SectionFilter(requireContext(),
                view.findViewById(R.id.reportSectionRow), f -> {
                    recomputeFilter();
                    loadToday();
                    loadWeek();
                    loadSabaqManzil();
                });
        view.findViewById(R.id.weeklyGridBtn).setOnClickListener(v ->
                startActivity(new Intent(getContext(), WeeklyGridActivity.class)));
        headingTv.setText(getString(R.string.report_today) + " — " + Hijri.bothLine(Db.today(), lang));
        Db.loadMadrasaName(name -> { if (madrasaTv != null) madrasaTv.setText(name); });
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (headingTv != null) load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            studentNames.clear();
            activeList.clear();
            allActiveIds.clear();
            List<Db.Student> actives = new ArrayList<>();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                studentNames.put(s.id, s.name);
                if (!s.graduated) actives.add(s);
            }
            Db.assignSerials(actives);
            Db.sortBySerial(actives);
            activeList.addAll(actives);
            for (Db.Student s : actives) allActiveIds.add(s.id);
            recomputeFilter();
            loadToday();
            loadWeek();
            loadSabaqManzil();
        });
    }

    private void recomputeFilter() {
        String f = sectionFilter == null ? SectionFilter.ALL : sectionFilter.current();
        activeIds.clear();
        for (Db.Student s : activeList) {
            if (SectionFilter.matches(s, f)) activeIds.add(s.id);
        }
    }

    // «آج کا سبق» + «آج کی منزل» for TODAY (the report is today-based),
    // over the section-filtered active students.
    private void loadSabaqManzil() {
        String today = Db.today();
        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(today, Db.SESSION_LESSON)).get()
                .addOnSuccessListener(doc -> {
                    Map<String, String> marks = new HashMap<>();
                    if (doc != null && doc.exists()) {
                        Object raw = doc.get("marks");
                        if (raw instanceof Map) {
                            for (Map.Entry<?, ?> e : ((Map<?, ?>) raw).entrySet()) {
                                if (e.getKey() != null && e.getValue() instanceof String) {
                                    marks.put(String.valueOf(e.getKey()), (String) e.getValue());
                                }
                            }
                        }
                    }
                    int on = 0, late = 0, none = 0;
                    List<Db.Student> noSabaq = new ArrayList<>();
                    for (Db.Student s : activeList) {
                        if (!activeIds.contains(s.id)) continue;
                        String m = marks.get(s.id);
                        if (Db.MARK_ONTIME.equals(m)) on++;
                        else if (Db.MARK_LATE.equals(m)) late++;
                        else if (Db.MARK_NONE.equals(m)) { none++; noSabaq.add(s); }
                    }
                    int total = activeIds.size();
                    sabaqCountsTv.setText(getString(R.string.total_students) + ": " + total
                            + " • " + getString(R.string.sabaq_ontime) + ": " + on
                            + " • " + getString(R.string.sabaq_late) + ": " + late
                            + " • " + getString(R.string.sabaq_none) + ": " + none
                            + " • " + getString(R.string.unmarked_lbl) + " " + Math.max(0, total - (on + late + none)));
                    sabaqNamesBox.removeAllViews();
                    if (noSabaq.isEmpty()) {
                        sabaqNamesBox.addView(line(getString(R.string.none_no_sabaq), false));
                    } else {
                        for (Db.Student s : noSabaq) sabaqNamesBox.addView(nameRow(s));
                    }
                    applyFonts(getView());
                });
        Db.fs().collection(Db.MANZIL).whereEqualTo("date", today).get()
                .addOnSuccessListener(qs -> {
                    Map<String, Integer> paras = new HashMap<>();
                    Map<String, String> statuses = new HashMap<>();
                    if (qs != null) {
                        for (DocumentSnapshot d : qs.getDocuments()) {
                            Object sid = d.get("studentId");
                            if (sid == null) continue;
                            String id = String.valueOf(sid);
                            Object p = d.get("para");
                            if (p instanceof Number) paras.put(id, ((Number) p).intValue());
                            Object st = d.get("status");
                            if (st instanceof String) statuses.put(id, (String) st);
                        }
                    }
                    int sunai = 0, nahi = 0, recorded = 0;
                    List<Db.Student> noManzil = new ArrayList<>();
                    Map<String, Integer> noManzilPara = new HashMap<>();
                    for (Db.Student s : activeList) {
                        if (!activeIds.contains(s.id)) continue;
                        if (statuses.containsKey(s.id) || paras.containsKey(s.id)) recorded++;
                        String st = statuses.get(s.id);
                        if (Db.MANZIL_SUNAI.equals(st)) sunai++;
                        else if (Db.MANZIL_NAHI.equals(st)) {
                            nahi++;
                            noManzil.add(s);
                            Integer p = paras.get(s.id);
                            noManzilPara.put(s.id, p != null ? p : s.manzilPara);
                        }
                    }
                    int total = activeIds.size();
                    manzilCountsTv.setText(getString(R.string.total_students) + ": " + total
                            + " • " + getString(R.string.manzil_sunai) + ": " + sunai
                            + " • " + getString(R.string.manzil_nahi) + ": " + nahi
                            + " • " + getString(R.string.unmarked_lbl) + " " + Math.max(0, total - recorded));
                    manzilNamesBox.removeAllViews();
                    if (noManzil.isEmpty()) {
                        manzilNamesBox.addView(line(getString(R.string.none_no_manzil), false));
                    } else {
                        for (Db.Student s : noManzil) {
                            Integer p = noManzilPara.get(s.id);
                            manzilNamesBox.addView(nameRow(s, p == null ? null
                                    : Ui.latinDigits(getString(R.string.prog_para_word) + " " + p)));
                        }
                    }
                    applyFonts(getView());
                });
    }

    private TextView nameRow(Db.Student s) { return nameRow(s, null); }

    // A report name row: name + (ولد father) [+ an optional suffix like
    // «سپارہ 5»], tapping opens the student record — like the absent list.
    private TextView nameRow(Db.Student s, String suffix) {
        String text = s.name;
        if (!s.fatherName.isEmpty()) text += " (" + getString(R.string.son_of) + " " + s.fatherName + ")";
        if (suffix != null) text += " — " + suffix;
        TextView row = line(text, true);
        row.setTextColor(getResources().getColor(R.color.navy, null));
        final String sid = s.id;
        row.setOnClickListener(v -> {
            Context ctx = getContext();
            if (ctx == null) return;
            Intent i = new Intent(ctx, StudentDetailActivity.class);
            i.putExtra("studentId", sid);
            startActivity(i);
        });
        return row;
    }

    private String sessionLabel(String session) {
        if (Db.SESSION_MIDDAY.equals(session)) return getString(R.string.midday);
        if (Db.SESSION_EVENING.equals(session)) return getString(R.string.evening);
        return getString(R.string.morning);
    }

    private void loadToday() {
        String today = Db.today();
        final Map<String, String> absentToday = new HashMap<>();
        final int[] done = {0};
        for (int i = 0; i < Db.CLASS_SESSIONS.length; i++) {
            final String session = Db.CLASS_SESSIONS[i];
            final TextView tv = sessionTvs[i];
            final String label = sessionLabel(session);
            Db.fs().collection(Db.ATTENDANCE).document(Db.docId(today, session)).get()
                    .addOnSuccessListener(doc -> {
                        int p = 0, a = 0, l = 0;
                        if (doc != null && doc.exists()) {
                            Object marksObj = doc.get("marks");
                            if (marksObj instanceof Map) {
                                for (Map.Entry<?, ?> e : ((Map<?, ?>) marksObj).entrySet()) {
                                    String sid = String.valueOf(e.getKey());
                                    if (!activeIds.contains(sid)) continue;
                                    if (Db.MARK_PRESENT.equals(e.getValue())) p++;
                                    else if (Db.MARK_LEAVE.equals(e.getValue())) l++;
                                    else if (Db.MARK_ABSENT.equals(e.getValue())) {
                                        a++;
                                        absentToday.put(sid, label);
                                    }
                                }
                            }
                        }
                        int unmarked = Math.max(0, activeIds.size() - (p + a + l));
                        tv.setText(label + " — " + getString(R.string.totals_line, activeIds.size(), p, a, l)
                                + " • " + getString(R.string.unmarked_lbl) + " " + unmarked);
                        if (++done[0] == Db.CLASS_SESSIONS.length) renderAbsent(absentToday);
                        applyFonts(getView());
                    })
                    .addOnFailureListener(e -> {
                        tv.setText(label + " — " + getString(R.string.not_marked));
                        if (++done[0] == Db.CLASS_SESSIONS.length) renderAbsent(absentToday);
                    });
        }
    }

    private void renderAbsent(Map<String, String> absentToday) {
        absentList.removeAllViews();
        if (absentToday.isEmpty()) {
            absentList.addView(line(getString(R.string.no_absent_today), false));
            return;
        }
        for (Map.Entry<String, String> e : absentToday.entrySet()) {
            final String sid = e.getKey();
            String name = studentNames.getOrDefault(sid, sid);
            TextView row = line(name + " — " + e.getValue(), true);
            row.setTextColor(getResources().getColor(R.color.navy, null));
            row.setOnClickListener(v -> {
                Context ctx = getContext();
                if (ctx == null) return;
                Intent i = new Intent(ctx, StudentDetailActivity.class);
                i.putExtra("studentId", sid);
                startActivity(i);
            });
            absentList.addView(row);
        }
        applyFonts(absentList);
    }

    private void loadWeek() {
        List<String> days = Db.last7Days(); // ascending, oldest first
        Db.fs().collection(Db.ATTENDANCE)
                .whereGreaterThanOrEqualTo("date", days.get(0))
                .whereLessThanOrEqualTo("date", days.get(days.size() - 1))
                .get().addOnSuccessListener(q -> {
                    // Per-day per-session counts, CLASS sessions only.
                    Map<String, Map<String, int[]>> byDay = new HashMap<>();
                    int p = 0, a = 0, l = 0;
                    Map<String, Integer> absByStudent = new HashMap<>();
                    for (DocumentSnapshot doc : q.getDocuments()) {
                        Object sessObj = doc.get("session");
                        String session = sessObj instanceof String ? (String) sessObj : null;
                        if (!Db.isClassSession(session)) continue; // skip punc_*/lesson
                        Object dateObj = doc.get("date");
                        String day = dateObj instanceof String ? (String) dateObj : "";
                        Map<String, int[]> perSession = byDay.computeIfAbsent(day, k -> new HashMap<>());
                        int[] counts = perSession.computeIfAbsent(session, k -> new int[3]);
                        Object marksObj = doc.get("marks");
                        if (!(marksObj instanceof Map)) continue;
                        for (Map.Entry<?, ?> e : ((Map<?, ?>) marksObj).entrySet()) {
                            String sid = String.valueOf(e.getKey());
                            if (!activeIds.contains(sid)) continue;
                            if (Db.MARK_PRESENT.equals(e.getValue())) { counts[0]++; p++; }
                            else if (Db.MARK_LEAVE.equals(e.getValue())) { counts[2]++; l++; }
                            else if (Db.MARK_ABSENT.equals(e.getValue())) {
                                counts[1]++; a++;
                                absByStudent.merge(sid, 1, Integer::sum);
                            }
                        }
                    }
                    renderWeekTable(days, byDay);
                    weekTv.setText(getString(R.string.week_total_line, p + a + l, p, a, l));
                    if (absByStudent.isEmpty()) {
                        weekAbsentTv.setVisibility(View.GONE);
                    } else {
                        weekAbsentTv.setVisibility(View.VISIBLE);
                        StringBuilder sb = new StringBuilder();
                        absByStudent.entrySet().stream()
                                .sorted((x, y) -> y.getValue() - x.getValue())
                                .forEach(e -> sb.append(studentNames.getOrDefault(e.getKey(), e.getKey()))
                                        .append(" — ").append(getString(R.string.absences_count, e.getValue())).append("\n"));
                        weekAbsentTv.setText(sb.toString().trim());
                    }
                    applyFonts(getView());
                });
    }

    // Most recent day first (preview reverses the ascending list).
    private void renderWeekTable(List<String> daysAsc, Map<String, Map<String, int[]>> byDay) {
        weeklyTable.removeAllViews();
        List<String> days = new ArrayList<>(daysAsc);
        java.util.Collections.reverse(days);
        for (String day : days) {
            LinearLayout rowBox = new LinearLayout(requireContext());
            rowBox.setOrientation(LinearLayout.VERTICAL);
            rowBox.setPadding(0, 5, 0, 5);
            TextView dayTv = new TextView(requireContext());
            dayTv.setText(Hijri.bothLine(day, lang));
            dayTv.setTextSize(13.5f);
            dayTv.setTypeface(dayTv.getTypeface(), Typeface.BOLD);
            dayTv.setTextColor(getResources().getColor(R.color.navy, null));
            rowBox.addView(dayTv);
            Map<String, int[]> perSession = byDay.get(day);
            StringBuilder sb = new StringBuilder();
            for (String session : Db.CLASS_SESSIONS) {
                int[] c = perSession == null ? null : perSession.get(session);
                int pp = c == null ? 0 : c[0], aa = c == null ? 0 : c[1], ll = c == null ? 0 : c[2];
                if (sb.length() > 0) sb.append("   ");
                sb.append(sessionLabel(session)).append(": ")
                        .append(getString(R.string.present)).append(" ").append(pp).append("، ")
                        .append(getString(R.string.absent)).append(" ").append(aa).append("، ")
                        .append(getString(R.string.leave_lbl)).append(" ").append(ll);
            }
            TextView counts = new TextView(requireContext());
            counts.setText(sb.toString());
            counts.setTextSize(12.5f);
            counts.setTextColor(getResources().getColor(R.color.ink, null));
            rowBox.addView(counts);
            weeklyTable.addView(rowBox);
            View rule = new View(requireContext());
            rule.setBackgroundColor(getResources().getColor(R.color.line, null));
            rule.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
            weeklyTable.addView(rule);
        }
    }

    private TextView line(String text, boolean bold) {
        TextView tv = new TextView(requireContext());
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(getResources().getColor(R.color.ink, null));
        tv.setPadding(0, 6, 0, 6);
        if (bold) tv.setTypeface(tv.getTypeface(), Typeface.BOLD);
        return tv;
    }
}
