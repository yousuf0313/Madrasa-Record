package com.madrasarecord.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Muhtamim report: today's totals per session, today's absent students,
// and a weekly summary. Read-only data for both roles.
public class ReportFragment extends BaseFragment {
    private TextView madrasaNameTv;
    private TextView reportDate, morningTv, eveningTv, weekTv, weekAbsentTv;
    private LinearLayout absentList;
    private final Map<String, String> studentNames = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        madrasaNameTv = view.findViewById(R.id.madrasaNameTv);
        reportDate = view.findViewById(R.id.reportDate);
        morningTv = view.findViewById(R.id.reportMorning);
        eveningTv = view.findViewById(R.id.reportEvening);
        weekTv = view.findViewById(R.id.reportWeek);
        weekAbsentTv = view.findViewById(R.id.reportWeekAbsent);
        absentList = view.findViewById(R.id.absentList);
        reportDate.setText(Db.pretty(requireContext(), Db.today()));
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (morningTv != null) load();
    }

    private void loadName() {
        if (madrasaNameTv == null || getContext() == null) return;
        Db.loadMadrasaName(name -> {
            if (madrasaNameTv == null || getContext() == null) return;
            madrasaNameTv.setText(name);
            madrasaNameTv.setTypeface(Ui.headerTypeface(getContext()));
        });
    }

    private void load() {
        loadName();
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            studentNames.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                studentNames.put(s.id, s.name);
            }
            loadToday();
            loadWeek();
        });
    }

    private void loadToday() {
        String today = Db.today();
        final Map<String, String> absentToday = new HashMap<>(); // studentId -> session label
        final int[] done = {0};
        for (String session : new String[]{Db.SESSION_MORNING, Db.SESSION_EVENING}) {
            Db.fs().collection(Db.ATTENDANCE).document(Db.docId(today, session)).get()
                    .addOnSuccessListener(doc -> {
                        TextView tv = Db.SESSION_MORNING.equals(session) ? morningTv : eveningTv;
                        String label = getString(Db.SESSION_MORNING.equals(session) ? R.string.morning : R.string.evening);
                        if (!doc.exists()) {
                            tv.setText(label + " — " + getString(R.string.not_marked));
                        } else {
                            Map<String, Object> marks = (Map<String, Object>) doc.get("marks");
                            int p = 0, a = 0, l = 0;
                            if (marks != null) for (Map.Entry<String, Object> e : marks.entrySet()) {
                                if (Db.MARK_PRESENT.equals(e.getValue())) p++;
                                else if (Db.MARK_LEAVE.equals(e.getValue())) l++;
                                else if (Db.MARK_ABSENT.equals(e.getValue())) {
                                    a++;
                                    absentToday.put(e.getKey(), label);
                                }
                            }
                            tv.setText(label + " — " + getString(R.string.totals_line, p + a + l, p, a, l));
                        }
                        if (++done[0] == 2) renderAbsent(absentToday);
                        applyFonts(getView());
                    });
        }
    }

    private void renderAbsent(Map<String, String> absentToday) {
        absentList.removeAllViews();
        if (absentToday.isEmpty()) {
            absentList.addView(line(getString(R.string.no_absent_today), false));
            return;
        }
        for (Map.Entry<String, String> e : absentToday.entrySet()) {
            final String sid = e.getKey();
            String name = studentNames.getOrDefault(sid, sid);
            TextView row = line(name + " — " + e.getValue(), true);
            // Tapping an absent student opens his full record (read-only for
            // the Muhtamim) so his father's numbers are one tap away.
            row.setTextColor(getResources().getColor(R.color.green_dark, null));
            row.setOnClickListener(v -> {
                Context ctx = getContext();
                if (ctx == null) return;
                Intent i = new Intent(ctx, StudentDetailActivity.class);
                i.putExtra("studentId", sid);
                startActivity(i);
            });
            absentList.addView(row);
        }
        applyFonts(absentList);
    }

    private void loadWeek() {
        List<String> days = Db.last7Days();
        Db.fs().collection(Db.ATTENDANCE)
                .whereGreaterThanOrEqualTo("date", days.get(0))
                .whereLessThanOrEqualTo("date", days.get(6))
                .get().addOnSuccessListener(q -> {
                    int p = 0, a = 0, l = 0;
                    Map<String, Integer> absByStudent = new HashMap<>();
                    for (DocumentSnapshot doc : q.getDocuments()) {
                        Map<String, Object> marks = (Map<String, Object>) doc.get("marks");
                        if (marks == null) continue;
                        for (Map.Entry<String, Object> e : marks.entrySet()) {
                            if (Db.MARK_PRESENT.equals(e.getValue())) p++;
                            else if (Db.MARK_LEAVE.equals(e.getValue())) l++;
                            else if (Db.MARK_ABSENT.equals(e.getValue())) {
                                a++;
                                absByStudent.merge(e.getKey(), 1, Integer::sum);
                            }
                        }
                    }
                    weekTv.setText(getString(R.string.week_total_line, p + a + l, p, a, l));
                    if (absByStudent.isEmpty()) {
                        weekAbsentTv.setVisibility(View.GONE);
                    } else {
                        weekAbsentTv.setVisibility(View.VISIBLE);
                        StringBuilder sb = new StringBuilder();
                        absByStudent.entrySet().stream()
                                .sorted((x, y) -> y.getValue() - x.getValue())
                                .forEach(e -> sb.append(studentNames.getOrDefault(e.getKey(), e.getKey()))
                                        .append(" — ").append(getString(R.string.absences_count, e.getValue())).append("\n"));
                        weekAbsentTv.setText(sb.toString().trim());
                    }
                    applyFonts(getView());
                });
    }

    private TextView line(String text, boolean bold) {
        TextView tv = new TextView(requireContext());
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(getResources().getColor(R.color.ink, null));
        tv.setPadding(0, 6, 0, 6);
        if (bold) tv.setTypeface(tv.getTypeface(), Typeface.BOLD);
        return tv;
    }
}
