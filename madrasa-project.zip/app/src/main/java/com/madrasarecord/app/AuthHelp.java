package com.madrasarecord.app;

import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import java.io.IOException;

// Mobile-number-only accounts + real auth error messages (v1.0.4).
//
// There is NO email option anywhere in the account screens and NO SMS/OTP:
// the canonical mobile number is the login ID and a normal password is
// used. Under the hood Firebase email/password auth is reused with an
// internal pseudo-email that is never shown to the user:
//     923241234567@madrasa.local
// so no Firebase Phone Auth / SMS billing is involved.
public final class AuthHelp {
    public static final String PSEUDO_DOMAIN = "@madrasa.local";

    private AuthHelp() {}

    // Canonicalize a Pakistani mobile number to international digits:
    // Latin digits only, spaces/dashes/parentheses stripped, leading "+"
    // dropped, a leading "0" replaced by "92", "92…" kept as-is.
    // Returns null when the result is not at least 10 digits.
    public static String canonicalMobile(String raw) {
        if (raw == null) return null;
        String s = Ui.latinDigits(raw).replaceAll("[\\s\\-()]", "");
        if (s.startsWith("+")) s = s.substring(1);
        if (s.startsWith("0")) s = "92" + s.substring(1);
        if (s.isEmpty()) return null;
        for (int i = 0; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return null;
        if (s.length() < 10) return null;
        return s;
    }

    public static String pseudoEmail(String canonicalMobile) {
        return canonicalMobile + PSEUDO_DOMAIN;
    }

    public static boolean isPseudoEmail(String email) {
        return email != null && email.endsWith(PSEUDO_DOMAIN);
    }

    // Recovery-code hash (v1.0.11): a user's recovery code is stored ONLY
    // as this SHA-256 hex of (canonicalMobile + ":" + code) in their user
    // doc's recoveryHash field — the code itself is never stored.
    public static String recoveryHash(String canonicalMobile, String code) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest((canonicalMobile + ":" + code)
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static Throwable findCause(Throwable e, Class<?> cls) {
        for (Throwable t = e; t != null; t = t.getCause()) if (cls.isInstance(t)) return t;
        return null;
    }

    private static String errorCode(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof FirebaseAuthException) return ((FirebaseAuthException) t).getErrorCode();
        }
        return "";
    }

    // Account-creation mapping.
    public static int errorRes(Throwable e) { return errorRes(e, false); }

    // Map an auth failure to a real, human string resource.
    // login — sign-in flow: a bad password / unknown number keeps the
    // wrong-credentials message instead of a generic one.
    public static int errorRes(Throwable e, boolean login) {
        if (e == null) return R.string.err_generic;
        String code = errorCode(e);
        if (findCause(e, FirebaseAuthUserCollisionException.class) != null
                || "ERROR_EMAIL_ALREADY_IN_USE".equals(code)) {
            return R.string.err_already_mobile;
        }
        if (findCause(e, FirebaseAuthWeakPasswordException.class) != null
                || "ERROR_WEAK_PASSWORD".equals(code)) {
            return R.string.password_short;
        }
        if (findCause(e, FirebaseTooManyRequestsException.class) != null
                || "ERROR_TOO_MANY_REQUESTS".equals(code)) {
            return R.string.err_too_many;
        }
        if (findCause(e, FirebaseNetworkException.class) != null
                || "ERROR_NETWORK_REQUEST_FAILED".equals(code)
                || findCause(e, IOException.class) != null) {
            return R.string.err_network;
        }
        if (findCause(e, FirebaseAuthInvalidUserException.class) != null
                || findCause(e, FirebaseAuthInvalidCredentialsException.class) != null) {
            return login ? R.string.wrong_credentials : R.string.err_generic;
        }
        return R.string.err_generic;
    }
}
