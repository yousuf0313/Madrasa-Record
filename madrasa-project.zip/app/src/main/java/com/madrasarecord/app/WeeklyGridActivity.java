package com.madrasarecord.app;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Weekly grid: students × last 7 days for the chosen session; P/A/L letters.
public class WeeklyGridActivity extends BaseActivity {
    private String session = Db.SESSION_MORNING;
    private LinearLayout gridBox;
    private final List<Db.Student> students = new ArrayList<>();
    private final Map<String, Map<String, String>> marksByDoc = new HashMap<>(); // docId -> studentId -> mark
    private List<String> days;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly);
        gridBox = findViewById(R.id.gridBox);
        days = Db.last7Days();
        ((TextView) findViewById(R.id.weekSub)).setText(getString(R.string.week_of, Db.pretty(this, days.get(0))));
        findViewById(R.id.weekMorningBtn).setOnClickListener(v -> { session = Db.SESSION_MORNING; render(); });
        findViewById(R.id.weekEveningBtn).setOnClickListener(v -> { session = Db.SESSION_EVENING; render(); });
        load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).orderBy("name").get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) students.add(new Db.Student(d));
            Db.fs().collection(Db.ATTENDANCE)
                    .whereGreaterThanOrEqualTo("date", days.get(0))
                    .whereLessThanOrEqualTo("date", days.get(6))
                    .get().addOnSuccessListener(qq -> {
                        marksByDoc.clear();
                        for (DocumentSnapshot doc : qq.getDocuments()) {
                            Object marksObj = doc.get("marks");
                            Map<String, Object> m = marksObj instanceof Map ? (Map<String, Object>) marksObj : null;
                            Map<String, String> conv = new HashMap<>();
                            if (m != null) for (Map.Entry<String, Object> e : m.entrySet()) conv.put(e.getKey(), String.valueOf(e.getValue()));
                            marksByDoc.put(doc.getId(), conv);
                        }
                        render();
                    });
        });
    }

    private TextView cell(String text, boolean header, int colorRes) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(header ? 13 : 14);
        tv.setPadding(10, 10, 10, 10);
        tv.setTextColor(getResources().getColor(colorRes, null));
        if (header) tv.setTypeface(tv.getTypeface(), Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tv.setLayoutParams(lp);
        tv.setMinWidth(52);
        return tv;
    }

    private void render() {
        gridBox.removeAllViews();
        // header row
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView nameHead = cell(getString(R.string.student_name_lbl), true, R.color.green_dark);
        nameHead.setMinWidth(170);
        nameHead.setGravity(Gravity.START);
        header.addView(nameHead);
        for (String day : days) {
            String short_ = day.substring(5); // MM-DD
            header.addView(cell(short_, true, R.color.green_dark));
        }
        gridBox.addView(header);
        for (Db.Student s : students) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            TextView nm = cell(s.name, false, R.color.ink);
            nm.setMinWidth(170);
            nm.setGravity(Gravity.START);
            row.addView(nm);
            for (String day : days) {
                Map<String, String> m = marksByDoc.get(Db.docId(day, session));
                String mark = m == null ? null : m.get(s.id);
                String letter;
                int color;
                if (Db.MARK_PRESENT.equals(mark)) { letter = getString(R.string.day_p); color = R.color.present; }
                else if (Db.MARK_ABSENT.equals(mark)) { letter = getString(R.string.day_a); color = R.color.absent; }
                else if (Db.MARK_LEAVE.equals(mark)) { letter = getString(R.string.day_l); color = R.color.leave_c; }
                else { letter = getString(R.string.day_none); color = R.color.muted; }
                row.addView(cell(letter, false, color));
            }
            gridBox.addView(row);
        }
        Ui.applyFont(gridBox, this);
    }
}
