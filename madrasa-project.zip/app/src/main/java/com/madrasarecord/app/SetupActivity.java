package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.WriteBatch;

import java.util.HashMap;
import java.util.Map;

// First-run screen: creates the very first Teacher account plus the
// madrasa_config/setup marker in one batch (this is the rules bootstrap).
// Accounts are MOBILE-NUMBER-ONLY (v1.0.4): the number is the login ID,
// internally mapped to a pseudo-email for Firebase email/password auth.
public class SetupActivity extends BaseActivity {
    private TextInputEditText nameIn, emailIn, passIn;
    private TextView errorTv;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        ((TextView) findViewById(R.id.authTitle)).setText(R.string.setup_title);
        ((TextView) findViewById(R.id.authSubtitle)).setText(R.string.setup_desc);
        ((TextInputLayout) findViewById(R.id.nameBox)).setVisibility(View.VISIBLE);
        nameIn = findViewById(R.id.nameInput);
        emailIn = findViewById(R.id.emailInput);
        passIn = findViewById(R.id.passwordInput);
        errorTv = findViewById(R.id.authError);
        btn = findViewById(R.id.authButton);
        btn.setText(R.string.create_first_teacher);

        // If setup already exists (e.g. a second device), go to login instead.
        Db.fs().collection(Db.CONFIG).document("setup").get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    }
                });

        btn.setOnClickListener(v -> create());
    }

    private void showError(String s) {
        errorTv.setText(s);
        errorTv.setVisibility(View.VISIBLE);
    }

    private void showError(int res) { showError(getString(res)); }

    private void create() {
        String name = text(nameIn), number = text(emailIn), pass = text(passIn);
        if (name.isEmpty() || number.isEmpty() || pass.isEmpty()) { showError(R.string.fill_all_fields); return; }
        if (pass.length() < 6) { showError(R.string.password_short); return; }
        String mobileCanon = AuthHelp.canonicalMobile(number);
        if (mobileCanon == null) { showError(R.string.err_mobile_invalid); return; }
        String authEmail = AuthHelp.pseudoEmail(mobileCanon);
        btn.setEnabled(false);
        btn.setText(R.string.creating);
        MadrasaApp.get().auth().createUserWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(res -> {
                    FirebaseUser user = res.getUser();
                    WriteBatch batch = Db.fs().batch();
                    Map<String, Object> setup = new HashMap<>();
                    setup.put("initialized", true);
                    setup.put("madrasaName", Db.DEFAULT_MADRASA_NAME);
                    setup.put("ownerUid", user.getUid());
                    setup.put("ownerEmail", authEmail);
                    setup.put("ownerMobile", mobileCanon);
                    batch.set(Db.fs().collection(Db.CONFIG).document("setup"), setup);
                    Map<String, Object> me = new HashMap<>();
                    me.put("name", name);
                    me.put("email", authEmail);
                    me.put("mobile", mobileCanon);
                    me.put("role", "teacher");
                    me.put("loginType", "mobile");
                    batch.set(Db.fs().collection(Db.USERS).document(user.getUid()), me);
                    batch.commit()
                            .addOnSuccessListener(x -> {
                                MadrasaApp.get().setSession("teacher", name);
                                startActivity(new Intent(this, MainActivity.class));
                                finish();
                            })
                            .addOnFailureListener(e -> fail(e));
                })
                .addOnFailureListener(e -> fail(e));
    }

    private void fail(Exception e) {
        btn.setEnabled(true);
        btn.setText(R.string.create_first_teacher);
        int res = AuthHelp.errorRes(e);
        showError(res);
        Toast.makeText(this, res, Toast.LENGTH_LONG).show();
    }

    private static String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}
