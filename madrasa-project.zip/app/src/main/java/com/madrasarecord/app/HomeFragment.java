package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.Map;

public class HomeFragment extends BaseFragment {
    private TextView madrasaNameTv;
    private TextView totalTv, morningLine, morningStatus, eveningLine, eveningStatus;
    private Button morningBtn, eveningBtn;
    private int totalStudents = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        madrasaNameTv = view.findViewById(R.id.madrasaNameTv);
        loadName();
        ((TextView) view.findViewById(R.id.homeDate)).setText(Db.pretty(requireContext(), Db.today()));

        Content.Item ayah = Content.dailyAyah();
        ((TextView) view.findViewById(R.id.homeAyahArabic)).setText(ayah.arabic);
        ((TextView) view.findViewById(R.id.homeAyahUrdu)).setText(ayah.urdu);
        ((TextView) view.findViewById(R.id.homeAyahRef)).setText(ayah.ref);
        Content.Item hadith = Content.dailyHadith();
        ((TextView) view.findViewById(R.id.homeHadithArabic)).setText(hadith.arabic);
        ((TextView) view.findViewById(R.id.homeHadithUrdu)).setText(hadith.urdu);
        ((TextView) view.findViewById(R.id.homeHadithRef)).setText(hadith.ref);

        totalTv = view.findViewById(R.id.homeTotalStudents);
        morningLine = view.findViewById(R.id.homeMorningLine);
        morningStatus = view.findViewById(R.id.homeMorningStatus);
        eveningLine = view.findViewById(R.id.homeEveningLine);
        eveningStatus = view.findViewById(R.id.homeEveningStatus);
        morningBtn = view.findViewById(R.id.homeMorningBtn);
        eveningBtn = view.findViewById(R.id.homeEveningBtn);
        boolean teacher = MadrasaApp.get().isTeacher();
        morningBtn.setText(teacher ? R.string.mark_attendance : R.string.view_register);
        eveningBtn.setText(teacher ? R.string.mark_attendance : R.string.view_register);
        morningBtn.setOnClickListener(v -> openRegister(Db.SESSION_MORNING));
        eveningBtn.setOnClickListener(v -> openRegister(Db.SESSION_EVENING));
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (totalTv != null) load();
        loadName();
    }

    private void loadName() {
        if (madrasaNameTv == null || getContext() == null) return;
        Db.loadMadrasaName(name -> {
            if (madrasaNameTv == null || getContext() == null) return;
            madrasaNameTv.setText(name);
            madrasaNameTv.setTypeface(Ui.headerTypeface(getContext()));
        });
    }

    private void openRegister(String session) {
        Intent i = new Intent(getContext(), AttendanceRegisterActivity.class);
        i.putExtra("date", Db.today());
        i.putExtra("session", session);
        startActivity(i);
    }

    private void load() {
        String today = Db.today();
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            totalStudents = q.size();
            totalTv.setText(getString(R.string.total_students) + ": " + totalStudents);
            applyFonts(getView());
        });
        loadSession(today, Db.SESSION_MORNING, morningLine, morningStatus, getString(R.string.morning));
        loadSession(today, Db.SESSION_EVENING, eveningLine, eveningStatus, getString(R.string.evening));
    }

    private void loadSession(String date, String session, TextView line, TextView status, String label) {
        line.setText(label);
        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).get()
                .addOnSuccessListener(doc -> fillSession(doc, line, status, label))
                .addOnFailureListener(e -> status.setText(getString(R.string.not_marked)));
    }

    private void fillSession(DocumentSnapshot doc, TextView line, TextView status, String label) {
        if (doc == null || !doc.exists()) {
            line.setText(label + " — " + getString(R.string.not_marked));
            status.setText("");
            return;
        }
        Object marksObj = doc.get("marks");
        Map<String, Object> marks = marksObj instanceof Map ? (Map<String, Object>) marksObj : null;
        int p = 0, a = 0, l = 0;
        if (marks != null) for (Object v : marks.values()) {
            if (Db.MARK_PRESENT.equals(v)) p++;
            else if (Db.MARK_ABSENT.equals(v)) a++;
            else if (Db.MARK_LEAVE.equals(v)) l++;
        }
        line.setText(label + " — " + getString(R.string.marked_done));
        status.setText(getString(R.string.totals_line, p + a + l, p, a, l));
        applyFonts(getView());
    }
}
