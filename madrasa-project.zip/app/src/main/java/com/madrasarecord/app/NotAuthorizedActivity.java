package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;

public class NotAuthorizedActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_not_authorized);
        findViewById(R.id.signOutBtn).setOnClickListener(v -> {
            MadrasaApp.get().auth().signOut();
            MadrasaApp.get().clearSession();
            startActivity(new Intent(this, SplashActivity.class));
            finish();
        });
    }
}
