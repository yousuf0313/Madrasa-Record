package com.madrasarecord.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// One register: a date + one session (morning/evening), roster rows with
// Present / Absent / Leave toggles, live totals, Mark-all-present, Save.
// Firestore persistence makes marking work offline; it syncs when online.
public class AttendanceRegisterActivity extends BaseActivity {
    private String date, session;
    private boolean readOnly;
    private final List<Db.Student> students = new ArrayList<>();
    private final Map<String, String> marks = new HashMap<>();
    // Students removed from THIS register (date+session) only — their ids
    // live in the document's "excluded" list so the removal survives a
    // reopen/re-save without touching the student record.
    private final java.util.Set<String> excluded = new java.util.HashSet<>();
    private Adapter adapter;
    private TextView totalsTv;
    private Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        date = getIntent().getStringExtra("date");
        session = getIntent().getStringExtra("session");
        if (date == null) date = Db.today();
        if (session == null) session = Db.SESSION_MORNING;
        readOnly = !MadrasaApp.get().isTeacher();

        String sessionLabel = getString(Db.SESSION_MORNING.equals(session) ? R.string.morning : R.string.evening);
        ((TextView) findViewById(R.id.regTitle)).setText(getString(R.string.attendance_for, Db.pretty(this, date), sessionLabel));
        ((TextView) findViewById(R.id.regSub)).setText(sessionLabel);
        totalsTv = findViewById(R.id.regTotals);
        saveBtn = findViewById(R.id.regSaveBtn);

        RecyclerView list = findViewById(R.id.regList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter();
        list.setAdapter(adapter);

        Button markAll = findViewById(R.id.markAllBtn);
        markAll.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        saveBtn.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        if (readOnly) {
            TextView note = findViewById(R.id.regSub);
            note.setText(sessionLabel + " — " + getString(R.string.view_only_note));
        }
        markAll.setOnClickListener(v -> {
            for (Db.Student s : students) marks.put(s.id, Db.MARK_PRESENT);
            adapter.notifyDataSetChanged();
            updateTotals();
        });
        saveBtn.setOnClickListener(v -> save());
        load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            students.clear();
            for (DocumentSnapshot d : q.getDocuments()) students.add(new Db.Student(d));
            Db.assignSerials(students);
            Db.sortBySerial(students);
            Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).get()
                    .addOnSuccessListener(doc -> {
                        Object marksObj = doc.exists() ? doc.get("marks") : null;
                        Map<String, Object> m = marksObj instanceof Map ? (Map<String, Object>) marksObj : null;
                        Object ex = doc.exists() ? doc.get("excluded") : null;
                        if (ex instanceof java.util.List) {
                            for (Object o : (java.util.List<?>) ex) if (o != null) excluded.add(String.valueOf(o));
                        }
                        students.removeIf(s -> excluded.contains(s.id));
                        // v1.0.11 (owner's order): attendance is NEVER
                        // automatic — only a mark actually saved for this
                        // register enters the map. An unmarked student has
                        // NO entry: chips render unselected, totals ignore
                        // them, and save() writes nothing for them.
                        for (Db.Student s : students) {
                            Object v = m == null ? null : m.get(s.id);
                            if (v != null) marks.put(s.id, String.valueOf(v));
                        }
                        adapter.notifyDataSetChanged();
                        updateTotals();
                        applyFonts();
                    });
        });
    }

    // Teacher-only long-press menu on a register row (v1.0.4):
    //  (a) remove the name from TODAY's register only — the mark is deleted
    //      from the current date+session document and the row leaves the
    //      on-screen list; the student record is untouched.
    //  (b) delete the student COMPLETELY (record + photo + all marks),
    //      via the shared Db.deleteStudentCompletely helper.
    // The Muhtamim (readOnly) never gets this menu.
    private void showStudentMenu(Db.Student s) {
        if (readOnly) return;
        String[] items = {getString(R.string.reg_remove_from_register), getString(R.string.reg_delete_student_full)};
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) confirmRemoveFromRegister(s);
                    else confirmDeleteStudent(s);
                })
                .show();
    }

    private void confirmRemoveFromRegister(Db.Student s) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.reg_remove_confirm_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    marks.remove(s.id);
                    excluded.add(s.id);
                    int idx = students.indexOf(s);
                    if (idx >= 0) {
                        students.remove(idx);
                        adapter.notifyItemRemoved(idx);
                    }
                    // Persist in the saved document too (if it exists yet):
                    // delete the mark and record the id in "excluded" so a
                    // reopen keeps the row out. A missing document just
                    // fails silently — the local removal above is what the
                    // teacher sees, and a later Save writes the marks map
                    // (and the excluded list) without this student.
                    Map<String, Object> upd = new HashMap<>();
                    upd.put("marks." + s.id, FieldValue.delete());
                    upd.put("excluded", FieldValue.arrayUnion(s.id));
                    Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).update(upd)
                            .addOnFailureListener(e -> { /* document may not exist yet */ });
                    updateTotals();
                    Toast.makeText(this, R.string.reg_name_removed, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void confirmDeleteStudent(Db.Student s) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_student_q)
                .setPositiveButton(R.string.yes, (d, w) ->
                        Db.deleteStudentCompletely(this, s.id, s.photoUrl, ok -> {
                            if (ok) {
                                marks.remove(s.id);
                                int idx = students.indexOf(s);
                                if (idx >= 0) {
                                    students.remove(idx);
                                    adapter.notifyItemRemoved(idx);
                                }
                                updateTotals();
                                Toast.makeText(this, R.string.student_deleted, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                            }
                        }))
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void updateTotals() {
        int p = 0, a = 0, l = 0;
        for (String v : marks.values()) {
            if (Db.MARK_PRESENT.equals(v)) p++;
            else if (Db.MARK_ABSENT.equals(v)) a++;
            else if (Db.MARK_LEAVE.equals(v)) l++;
        }
        totalsTv.setText(getString(R.string.totals_line, students.size(), p, a, l));
    }

    private void save() {
        Map<String, Object> doc = new HashMap<>();
        doc.put("date", date);
        doc.put("session", session);
        doc.put("marks", new HashMap<>(marks));
        doc.put("excluded", new ArrayList<>(excluded));
        doc.put("updatedAt", FieldValue.serverTimestamp());
        doc.put("updatedBy", MadrasaApp.get().auth().getCurrentUser() != null
                ? MadrasaApp.get().auth().getCurrentUser().getUid() : "");
        saveBtn.setEnabled(false);
        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).set(doc)
                .addOnSuccessListener(x -> {
                    Toast.makeText(this, R.string.register_saved, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    saveBtn.setEnabled(true);
                    Toast.makeText(this, R.string.err_generic, Toast.LENGTH_LONG).show();
                });
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_register_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = students.get(position);
            h.serial.setText(String.valueOf(s.serial));
            h.name.setText(s.name);
            h.father.setText(s.fatherName);
            StringBuilder dl = new StringBuilder();
            dl.append(getString(R.string.admission_date)).append(": ").append(s.admissionDate.isEmpty() ? "—" : s.admissionDate);
            dl.append(" • ").append(getString(R.string.date_of_birth)).append(": ").append(s.dateOfBirth.isEmpty() ? "—" : s.dateOfBirth);
            if (!s.completionDate.isEmpty()) dl.append(" • ").append(getString(R.string.completion_date)).append(": ").append(s.completionDate);
            h.dates.setText(dl.toString());
            Db.loadPhoto(AttendanceRegisterActivity.this, s, h.photo);
            String cur = marks.get(s.id); // null = unmarked: all three chips unselected
            styleToggle(h.btnP, Db.MARK_PRESENT.equals(cur), R.color.present, R.color.green_soft, getString(R.string.present));
            styleToggle(h.btnA, Db.MARK_ABSENT.equals(cur), R.color.absent, R.color.red_soft, getString(R.string.absent));
            styleToggle(h.btnL, Db.MARK_LEAVE.equals(cur), R.color.leave_c, R.color.amber_soft, getString(R.string.leave_lbl));
            View.OnClickListener pick = v -> {
                if (readOnly) return;
                String val = v == h.btnP ? Db.MARK_PRESENT : v == h.btnA ? Db.MARK_ABSENT : Db.MARK_LEAVE;
                marks.put(s.id, val);
                notifyItemChanged(position);
                updateTotals();
            };
            h.btnP.setOnClickListener(pick);
            h.btnA.setOnClickListener(pick);
            h.btnL.setOnClickListener(pick);
            // Long-press menu (remove from today's register / delete fully)
            // is installed for the Teacher only; readOnly rows get none.
            if (!readOnly) {
                h.itemView.setOnLongClickListener(v -> {
                    showStudentMenu(s);
                    return true;
                });
            } else {
                h.itemView.setOnLongClickListener(null);
            }
            Ui.applyFont(h.itemView, AttendanceRegisterActivity.this);
        }

        // Preview status chips (v1.0.8): unselected = soft tint of the
        // status colour with coloured text; selected = solid status
        // colour, white text, "✓ " prefix.
        private void styleToggle(Button b, boolean active, int colorRes, int softRes, String label) {
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    getResources().getColor(active ? colorRes : softRes, null)));
            b.setTextColor(getResources().getColor(active ? R.color.white : colorRes, null));
            b.setText(active ? "✓ " + label : label);
        }

        @Override
        public int getItemCount() { return students.size(); }

        class Holder extends RecyclerView.ViewHolder {
            ImageView photo; TextView serial, name, father, dates; Button btnP, btnA, btnL;
            Holder(View v) {
                super(v);
                serial = v.findViewById(R.id.regSerial);
                photo = v.findViewById(R.id.regPhoto);
                name = v.findViewById(R.id.regName);
                father = v.findViewById(R.id.regFather);
                dates = v.findViewById(R.id.regDates);
                btnP = v.findViewById(R.id.btnP);
                btnA = v.findViewById(R.id.btnA);
                btnL = v.findViewById(R.id.btnL);
            }
        }
    }
}
