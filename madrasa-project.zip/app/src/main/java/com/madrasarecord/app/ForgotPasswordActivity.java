package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.Map;

// Forgot password (v1.0.11). There is no real email and no SMS in this
// app, so recovery works with the RECOVERY CODE the user set for
// themselves in Settings: enter the mobile number; if that account has
// a recovery code, enter it plus a new password and the account's
// password is replaced on the spot (AccountReset) and the user is
// signed in. If the account has no recovery code (or the number is not
// found — the wording is deliberately identical), the screen shows one
// uniform message: the teacher can make a new password from
// Settings → Users. System Back returns to the login screen (this
// activity is simply pushed on top of it).
public class ForgotPasswordActivity extends BaseActivity {
    private TextInputEditText mobileIn, codeIn, passIn;
    private TextView error1, error2, helpTv;
    private View stage1, stage2;
    private Button continueBtn, resetBtn;

    private String foundUid, foundMobile, foundHash;
    private Map<String, Object> foundData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
        mobileIn = findViewById(R.id.forgotMobileInput);
        codeIn = findViewById(R.id.forgotCodeInput);
        passIn = findViewById(R.id.forgotPassInput);
        error1 = findViewById(R.id.forgotError);
        error2 = findViewById(R.id.forgotError2);
        helpTv = findViewById(R.id.forgotHelp);
        stage1 = findViewById(R.id.forgotStage1);
        stage2 = findViewById(R.id.forgotStage2);
        continueBtn = findViewById(R.id.forgotContinueBtn);
        resetBtn = findViewById(R.id.forgotResetBtn);
        continueBtn.setOnClickListener(v -> lookup());
        resetBtn.setOnClickListener(v -> doReset());
    }

    private void showError(TextView tv, int res) {
        tv.setText(res);
        tv.setVisibility(View.VISIBLE);
    }

    private void lookup() {
        String number = mobileIn.getText() == null ? "" : mobileIn.getText().toString().trim();
        if (number.isEmpty()) { showError(error1, R.string.fill_all_fields); return; }
        String canon = AuthHelp.canonicalMobile(number);
        if (canon == null) { showError(error1, R.string.err_mobile_invalid); return; }
        error1.setVisibility(View.GONE);
        helpTv.setVisibility(View.GONE);
        continueBtn.setEnabled(false);
        // Same lookup pattern the codebase already uses for users: a full
        // madrasa_users read matched in memory (UsersActivity.load) — no
        // query/index assumptions. Field reads are instanceof-safe.
        Db.fs().collection(Db.USERS).get()
                .addOnSuccessListener(q -> {
                    continueBtn.setEnabled(true);
                    DocumentSnapshot found = null;
                    for (DocumentSnapshot d : q.getDocuments()) {
                        if (canon.equals(strField(d, "mobile"))) { found = d; break; }
                    }
                    String hash = found == null ? null : strField(found, "recoveryHash");
                    if (found == null || hash == null || hash.isEmpty()) {
                        // Uniform wording whether the number is unknown or
                        // simply has no recovery code set.
                        helpTv.setText(R.string.forgot_teacher_help);
                        helpTv.setVisibility(View.VISIBLE);
                        return;
                    }
                    foundUid = found.getId();
                    foundData = found.getData();
                    foundMobile = canon;
                    foundHash = hash;
                    stage1.setVisibility(View.GONE);
                    stage2.setVisibility(View.VISIBLE);
                    applyFonts();
                })
                .addOnFailureListener(e -> {
                    continueBtn.setEnabled(true);
                    showError(error1, R.string.err_network);
                });
    }

    private void doReset() {
        String code = codeIn.getText() == null ? "" : codeIn.getText().toString().trim();
        String pass = passIn.getText() == null ? "" : passIn.getText().toString();
        if (code.isEmpty() || pass.isEmpty()) { showError(error2, R.string.fill_all_fields); return; }
        if (pass.length() < 6) { showError(error2, R.string.password_short); return; }
        if (!AuthHelp.recoveryHash(foundMobile, code).equals(foundHash)) {
            // Wrong code: plain error, nothing changes.
            showError(error2, R.string.err_recovery_wrong);
            return;
        }
        error2.setVisibility(View.GONE);
        resetBtn.setEnabled(false);
        AccountReset.replacePassword(this, foundUid, foundData, foundMobile, pass,
                (ok, newUid, newEmail) -> {
                    if (!ok) {
                        resetBtn.setEnabled(true);
                        showError(error2, R.string.err_generic);
                        return;
                    }
                    signInWithNewPassword(newEmail, pass);
                });
    }

    // Reset succeeded: sign in on the MAIN auth with the new identity
    // and route exactly like a normal login (LoginActivity).
    private void signInWithNewPassword(String newEmail, String pass) {
        MadrasaApp.get().auth().signInWithEmailAndPassword(newEmail, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Db.fs().collection(Db.USERS).document(uid).get()
                            .addOnSuccessListener(doc -> {
                                if (doc.exists()) {
                                    MadrasaApp.get().setSession(strField(doc, "role"), strField(doc, "name"));
                                    startActivity(new Intent(this, MainActivity.class));
                                } else {
                                    startActivity(new Intent(this, NotAuthorizedActivity.class));
                                }
                                finish();
                            })
                            .addOnFailureListener(e -> goLogin());
                })
                .addOnFailureListener(e -> goLogin());
    }

    // The password WAS changed; if the immediate sign-in hiccups, the
    // login screen accepts the new password as usual.
    private void goLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    // Instanceof-safe field read (same hardening pattern as SplashActivity).
    private static String strField(DocumentSnapshot doc, String field) {
        try {
            Object v = doc.get(field);
            return v instanceof String ? (String) v : null;
        } catch (Exception e) {
            return null;
        }
    }
}
