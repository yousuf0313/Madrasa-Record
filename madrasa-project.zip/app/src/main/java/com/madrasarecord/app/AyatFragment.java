package com.madrasarecord.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AyatFragment extends BaseFragment {
    private static final class Row {
        final boolean ayah; final Content.Item item;
        Row(boolean ayah, Content.Item item) { this.ayah = ayah; this.item = item; }
    }

    private final List<Row> rows = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ayat, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rows.clear();
        for (Content.Item i : Content.AYAT) rows.add(new Row(true, i));
        for (Content.Item i : Content.AHADITH) rows.add(new Row(false, i));
        RecyclerView list = view.findViewById(R.id.ayatList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        list.setAdapter(new RecyclerView.Adapter<Holder>() {
            @NonNull
            @Override
            public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ayah, parent, false));
            }

            @Override
            public void onBindViewHolder(@NonNull Holder h, int position) {
                Row r = rows.get(position);
                h.kind.setText(r.ayah ? R.string.quran_ayah : R.string.hadith_lbl);
                h.arabic.setText(r.item.arabic);
                h.urdu.setText(r.item.urdu);
                h.ref.setText(r.item.ref);
                Ui.applyFont(h.itemView, requireContext());
            }

            @Override
            public int getItemCount() { return rows.size(); }
        });
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView kind, arabic, urdu, ref;
        Holder(View v) {
            super(v);
            kind = v.findViewById(R.id.itemKind);
            arabic = v.findViewById(R.id.itemArabic);
            urdu = v.findViewById(R.id.itemUrdu);
            ref = v.findViewById(R.id.itemRef);
        }
    }
}
