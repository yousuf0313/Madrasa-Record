package com.madrasarecord.app;

import android.content.Context;
import android.util.AttributeSet;

import com.google.android.material.bottomnavigation.BottomNavigationView;

// BottomNavigationView whose menu may hold SIX destinations.
//
// ROOT CAUSE of the v1.0.0–v1.0.4 "app closes ~3 s after splash" crash on
// the signed-in route: Material 1.12.0's NavigationBarMenu.addInternal()
// throws IllegalArgumentException ("Maximum number of items supported by
// BottomNavigationView is 5…") when a 6th item is inflated, and that
// inflation happens inside MainActivity.setContentView — i.e. the instant
// Splash navigates to Main, before Main draws a single frame.
// NavigationBarView.getMaxItemCount() is public and non-final in the
// bundled material-1.12.0 (verified in its bytecode), and the menu reads
// its limit from this method, so returning 6 here is the supported way
// to lift the limit for this one view. The override returns a constant
// and touches no fields, so it is safe even though the superclass
// constructor calls it (virtual dispatch during construction).
public class SixBottomNavigationView extends BottomNavigationView {
    public SixBottomNavigationView(Context context) { super(context); }
    public SixBottomNavigationView(Context context, AttributeSet attrs) { super(context, attrs); }
    public SixBottomNavigationView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }

    @Override
    public int getMaxItemCount() { return 6; }
}
