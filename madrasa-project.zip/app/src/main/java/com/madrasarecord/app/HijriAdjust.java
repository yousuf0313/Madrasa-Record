package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

// «درست کریں» — the Hijri date adjustment sheet (v1.1.0). Opened by
// tapping the Hijri date in the attendance headers. Moves the stored
// day offset within -10..+10 with a live preview of today's Hijri date;
// «خودکار پر واپس» returns to offset 0. Saving persists to
// madrasa_config/setup (hijriOffsetDays) and updates the Hijri cache,
// so every Hijri display in the app follows it.
public final class HijriAdjust {
    private HijriAdjust() {}

    public static void show(final Context ctx, final Runnable onSaved) {
        final String lang = Ui.lang(ctx);
        final int[] temp = {Hijri.getOffset()};
        final String today = Db.today();

        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 32, 48, 8);

        TextView note = new TextView(ctx);
        note.setText(R.string.hijri_adjust_note);
        note.setTextSize(13.5f);
        box.addView(note);

        final TextView preview = new TextView(ctx);
        preview.setTextSize(19f);
        preview.setTextColor(ctx.getResources().getColor(R.color.navy, null));
        preview.setPadding(0, 24, 0, 4);
        box.addView(preview);

        final TextView offsetTv = new TextView(ctx);
        offsetTv.setTextSize(13f);
        offsetTv.setTextColor(ctx.getResources().getColor(R.color.muted, null));
        box.addView(offsetTv);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 16, 0, 0);
        Button prev = new Button(ctx);
        prev.setText(R.string.hijri_prev_day);
        Button next = new Button(ctx);
        next.setText(R.string.hijri_next_day);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        prev.setLayoutParams(lp);
        next.setLayoutParams(lp);
        row.addView(prev);
        row.addView(next);
        box.addView(row);

        Button auto = new Button(ctx);
        auto.setText(R.string.hijri_auto);
        box.addView(auto);

        final Runnable refresh = () -> {
            // Preview with the TEMP offset: shift the Gregorian date by
            // (temp - stored) extra days inside Hijri.parts.
            int extra = temp[0] - Hijri.getOffset();
            int[] p = Hijri.parts(today, extra);
            String hijri = p == null ? "" : previewText(ctx, lang, p);
            preview.setText(hijri);
            if (temp[0] == 0) {
                offsetTv.setText(R.string.hijri_auto_note);
            } else {
                String sign = temp[0] > 0 ? "+" : "−";
                offsetTv.setText(sign + Math.abs(temp[0]) + " " + ctx.getString(R.string.hijri_day_suffix));
            }
        };
        prev.setOnClickListener(v -> {
            if (temp[0] > Hijri.MIN_OFFSET) { temp[0]--; refresh.run(); }
        });
        next.setOnClickListener(v -> {
            if (temp[0] < Hijri.MAX_OFFSET) { temp[0]++; refresh.run(); }
        });
        auto.setOnClickListener(v -> { temp[0] = 0; refresh.run(); });
        refresh.run();

        new AlertDialog.Builder(ctx)
                .setTitle(R.string.hijri_sheet_title)
                .setView(box)
                .setPositiveButton(R.string.save, (d, w) -> {
                    Db.saveHijriOffset(temp[0]).addOnCompleteListener(t -> {
                        Toast.makeText(ctx, R.string.saved_ok, Toast.LENGTH_SHORT).show();
                        if (onSaved != null) onSaved.run();
                    });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        Ui.applyFont(box, ctx);
    }

    private static String previewText(Context ctx, String lang, int[] p) {
        // Same formatting as Hijri.format but from explicit parts (the
        // temp offset is not in the Hijri cache yet).
        String[] monthsUr = {"محرم", "صفر", "ربیع الاول", "ربیع الثانی", "جمادی الاولی", "جمادی الثانی",
                "رجب", "شعبان", "رمضان", "شوال", "ذوالقعدہ", "ذوالحجہ"};
        String[] monthsEn = {"Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Ula",
                "Jumada al-Akhirah", "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul-Qadah", "Dhul-Hijjah"};
        String[] monthsAr = {"محرم", "صفر", "ربيع الأول", "ربيع الثاني", "جمادى الأولى", "جمادى الآخرة",
                "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"};
        String month, suffix;
        if ("en".equals(lang)) { month = monthsEn[p[1] - 1]; suffix = "AH"; }
        else if ("ar".equals(lang)) { month = monthsAr[p[1] - 1]; suffix = "هـ"; }
        else { month = monthsUr[p[1] - 1]; suffix = "ھ"; }
        return Ui.latinDigits(p[0] + " " + month + " " + p[2] + " " + suffix);
    }
}
