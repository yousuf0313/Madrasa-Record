package com.madrasarecord.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

// In-app update check (v1.0.5, user's request): reads the YS Store
// catalog (apps.json) on a background thread and, when the catalog's
// entry for THIS app carries a higher versionCode than the installed
// build, offers the update in a dialog. The automatic check (from
// MainActivity) is completely silent on failure / offline / no update;
// the manual check (Settings) additionally reports "up to date".
public final class UpdateCheck {
    private static final String CATALOG_URL =
            "https://raw.githubusercontent.com/yousuf0313/YS-Store/main/apps.json";
    private static final String ENTRY_ID = "madrasarecord";

    private UpdateCheck() {}

    public static void check(Activity act, boolean manual) {
        if (act == null) return;
        new Thread(() -> {
            Result r = fetch(act);
            act.runOnUiThread(() -> {
                try {
                    if (act.isFinishing() || act.isDestroyed()) return;
                    if (r != null && r.newer) {
                        showDialog(act, r);
                    } else if (manual) {
                        Toast.makeText(act, r == null ? R.string.err_network : R.string.up_to_date,
                                Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable ignored) {
                }
            });
        }, "update-check").start();
    }

    private static final class Result {
        boolean newer;
        String versionName;
        String apkUrl;
    }

    /** @return null on any failure (offline, timeout, parse error). */
    private static Result fetch(Context ctx) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(CATALOG_URL).openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) return null;
            StringBuilder body = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) body.append(line);
            }
            JSONObject root = new JSONObject(body.toString());
            JSONArray apps = root.optJSONArray("apps");
            if (apps == null) return null;
            String myPkg = ctx.getPackageName();
            for (int i = 0; i < apps.length(); i++) {
                JSONObject e = apps.optJSONObject(i);
                if (e == null) continue;
                if (!ENTRY_ID.equals(e.optString("id")) && !myPkg.equals(e.optString("package"))) continue;
                int catalogVc = e.optInt("versionCode", -1);
                PackageInfo pi = ctx.getPackageManager().getPackageInfo(myPkg, 0);
                Result r = new Result();
                r.newer = catalogVc > pi.versionCode;
                r.versionName = e.optString("versionName", "");
                r.apkUrl = e.optString("apkUrl", "");
                return r;
            }
            return null;
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void showDialog(Activity act, Result r) {
        String msg = r.versionName == null || r.versionName.isEmpty()
                ? act.getString(R.string.update_available_msg_plain)
                : act.getString(R.string.update_available_msg, r.versionName);
        new AlertDialog.Builder(act)
                .setTitle(R.string.update_available_title)
                .setMessage(msg)
                .setPositiveButton(R.string.update_now, (d, w) -> {
                    try {
                        if (r.apkUrl != null && !r.apkUrl.isEmpty()) {
                            act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(r.apkUrl)));
                        }
                    } catch (Exception ignored) {
                    }
                })
                .setNegativeButton(R.string.later, null)
                .show();
    }
}
