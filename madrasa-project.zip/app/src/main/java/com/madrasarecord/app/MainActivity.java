package com.madrasarecord.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {
    // v1.0.8: fragment switching is replace()-based and recreation-proof.
    //
    // The old mechanism (v1.0.0–1.0.7) kept a map of FRESH fragment
    // instances and used add()+hide()/show() with an `active` field. When
    // the activity was recreated (rotation, process death, language/font
    // change via recreate()), the FragmentManager restored the OLD
    // fragments into the container, but the map held brand-new instances
    // and `active` was null — nothing ever hid the restored screens, so
    // fragments from several tabs stayed visible on top of each other
    // permanently (the ghosting seen in the v1.0.7 phone recording:
    // Settings' buttons/text showing through Home, Attendance, Report).
    //
    // Now: onCreate first removes EVERY fragment the manager already
    // holds in the container (restored orphans), then installs Home.
    // switchTo() uses replace(), which atomically removes whatever is in
    // the container and installs the target — there is only ever exactly
    // one fragment in the container, so overlap is structurally
    // impossible.
    private final Map<Integer, Class<? extends Fragment>> fragmentClasses = new HashMap<>();
    private int currentId = 0;
    private Fragment active;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String uname = MadrasaApp.get().userName();
        TextView hu = findViewById(R.id.headerUser);
        if (uname != null) hu.setText(uname);

        fragmentClasses.put(R.id.navHome, HomeFragment.class);
        fragmentClasses.put(R.id.navStudents, StudentsFragment.class);
        fragmentClasses.put(R.id.navAttendance, AttendanceFragment.class);
        fragmentClasses.put(R.id.navReport, ReportFragment.class);
        fragmentClasses.put(R.id.navAyat, AyatFragment.class);
        fragmentClasses.put(R.id.navSettings, SettingsFragment.class);

        FragmentManager fm = getSupportFragmentManager();
        // Drop any fragments restored into our container by a previous
        // incarnation of this activity before installing our own.
        FragmentTransaction cleanup = fm.beginTransaction();
        boolean hasOrphans = false;
        for (Fragment f : fm.getFragments()) {
            if (f.getId() == R.id.fragmentContainer) {
                cleanup.remove(f);
                hasOrphans = true;
            }
        }
        if (hasOrphans) cleanup.commitNow();

        currentId = R.id.navHome;
        active = new HomeFragment();
        fm.beginTransaction()
                .replace(R.id.fragmentContainer, active, "f" + R.id.navHome)
                .commit();

        BottomNavigationView nav = findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item -> {
            switchTo(item.getItemId());
            return true;
        });
        nav.setSelectedItemId(R.id.navHome);
        // In-app update check (v1.0.5): once per MainActivity creation,
        // background, silent unless a newer catalog version exists.
        if (savedInstanceState == null) {
            try { UpdateCheck.check(this, false); } catch (Throwable ignored) { }
        }
    }

    private void switchTo(int id) {
        if (id == currentId) return;
        Class<? extends Fragment> cls = fragmentClasses.get(id);
        if (cls == null) return;
        Fragment target;
        try {
            target = cls.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            return;
        }
        currentId = id;
        active = target;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, target, "f" + id)
                .commit();
        applyFontsSoon();
    }

    private void applyFontsSoon() {
        android.view.View root = findViewById(android.R.id.content);
        if (root != null) root.postDelayed(() -> Ui.applyFont(root, this), 60);
    }
}
