package com.madrasarecord.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {
    // Fragment switching is replace()-based and recreation-proof
    // (v1.0.8 pattern, kept): onCreate first removes EVERY fragment the
    // manager already holds in the container (restored orphans), then
    // installs the home tab. switchTo() uses replace(), so exactly one
    // fragment is ever in the container.
    //
    // v1.1.0: FIVE tabs — حاضری (ClassFragment, home) / وقت حاضری /
    // سبق حاضری / رپورٹ / ترتیبات. The old Home/Students/Attendance/Ayat
    // tabs are gone: the register lives inside the class tab, and
    // آج کی آیت و حدیث is a page from Settings (DailyActivity).
    // v1.2.0: a SIXTH tab — پیش رفت (ProgressFragment) — sits between
    // سبق حاضری and رپورٹ.
    private final Map<Integer, Class<? extends Fragment>> fragmentClasses = new HashMap<>();
    private int currentId = 0;
    private Fragment active;
    // v1.2.0 collapsing chrome: the three attendance screens hide this
    // madrasa-name banner while their single page scrolls down, and
    // bring it back at the top (see setBannerCollapsed).
    private android.view.View bannerCard;
    private boolean bannerCollapsed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bannerCard = findViewById(R.id.mainBanner);
        String uname = MadrasaApp.get().userName();
        TextView hu = findViewById(R.id.headerUser);
        if (uname != null) hu.setText(uname);
        // Refresh the madrasa name in the banner from config.
        Db.loadMadrasaName(name -> {
            TextView t = findViewById(R.id.headerTitle);
            if (t != null && name != null && !name.trim().isEmpty()) t.setText(name);
        });
        // Keep the Hijri offset cache fresh for every screen.
        Db.loadHijriOffset();

        fragmentClasses.put(R.id.navClass, ClassFragment.class);
        fragmentClasses.put(R.id.navWaqt, WaqtFragment.class);
        fragmentClasses.put(R.id.navSabaq, SabaqFragment.class);
        fragmentClasses.put(R.id.navProgress, ProgressFragment.class);
        fragmentClasses.put(R.id.navReport, ReportFragment.class);
        fragmentClasses.put(R.id.navSettings, SettingsFragment.class);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction cleanup = fm.beginTransaction();
        boolean hasOrphans = false;
        for (Fragment f : fm.getFragments()) {
            if (f.getId() == R.id.fragmentContainer) {
                cleanup.remove(f);
                hasOrphans = true;
            }
        }
        if (hasOrphans) cleanup.commitNow();

        currentId = R.id.navClass;
        active = new ClassFragment();
        fm.beginTransaction()
                .replace(R.id.fragmentContainer, active, "f" + R.id.navClass)
                .commit();

        BottomNavigationView nav = findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item -> {
            switchTo(item.getItemId());
            return true;
        });
        nav.setSelectedItemId(R.id.navClass);
        // Back rule (owner's, kept): Back from ANY tab lands on the
        // حاضری home tab; Back on home exits as usual.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (currentId != R.id.navClass) {
                    nav.setSelectedItemId(R.id.navClass);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
        // In-app update check: once per MainActivity creation,
        // background, silent unless a newer catalog version exists.
        if (savedInstanceState == null) {
            try { UpdateCheck.check(this, false); } catch (Throwable ignored) { }
        }
    }

    // v1.2.0: hide/show the madrasa-name banner. The attendance
    // screens call this from their page scroll; only the banner moves —
    // each screen's own navy header strip stays pinned.
    public void setBannerCollapsed(boolean collapsed) {
        if (bannerCard == null || collapsed == bannerCollapsed) return;
        bannerCollapsed = collapsed;
        bannerCard.setVisibility(collapsed ? android.view.View.GONE : android.view.View.VISIBLE);
    }

    private void switchTo(int id) {
        if (id == currentId) return;
        setBannerCollapsed(false); // every tab starts with the banner shown
        Class<? extends Fragment> cls = fragmentClasses.get(id);
        if (cls == null) return;
        Fragment target;
        try {
            target = cls.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            return;
        }
        currentId = id;
        active = target;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, target, "f" + id)
                .commit();
        applyFontsSoon();
    }

    private void applyFontsSoon() {
        android.view.View root = findViewById(android.R.id.content);
        if (root != null) root.postDelayed(() -> Ui.applyFont(root, this), 60);
    }
}
