package com.madrasarecord.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {
    private final Map<Integer, Fragment> fragments = new HashMap<>();
    private Fragment active;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String uname = MadrasaApp.get().userName();
        TextView hu = findViewById(R.id.headerUser);
        if (uname != null) hu.setText(uname);

        fragments.put(R.id.navHome, new HomeFragment());
        fragments.put(R.id.navStudents, new StudentsFragment());
        fragments.put(R.id.navAttendance, new AttendanceFragment());
        fragments.put(R.id.navReport, new ReportFragment());
        fragments.put(R.id.navAyat, new AyatFragment());
        fragments.put(R.id.navSettings, new SettingsFragment());

        BottomNavigationView nav = findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item -> {
            switchTo(item.getItemId());
            return true;
        });
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragmentContainer, fragments.get(R.id.navHome), "home").commit();
            active = fragments.get(R.id.navHome);
        }
        // In-app update check (v1.0.5): once per MainActivity creation,
        // background, silent unless a newer catalog version exists.
        if (savedInstanceState == null) {
            try { UpdateCheck.check(this, false); } catch (Throwable ignored) { }
        }
    }

    private void switchTo(int id) {
        Fragment target = fragments.get(id);
        if (target == null || target == active) return;
        androidx.fragment.app.FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        if (!target.isAdded()) tx.add(R.id.fragmentContainer, target, "f" + id);
        if (active != null) tx.hide(active);
        tx.show(target).commit();
        active = target;
        applyFontsSoon();
    }

    private void applyFontsSoon() {
        android.view.View root = findViewById(android.R.id.content);
        if (root != null) root.postDelayed(() -> Ui.applyFont(root, this), 60);
    }
}
