package com.madrasarecord.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.DocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;

public class AttendanceFragment extends BaseFragment {
    private String date = Db.today();
    private Button dateBtn, morningBtn, eveningBtn;
    private TextView morningStatus, eveningStatus;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_attendance, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dateBtn = view.findViewById(R.id.dateBtn);
        morningBtn = view.findViewById(R.id.morningBtn);
        eveningBtn = view.findViewById(R.id.eveningBtn);
        morningStatus = view.findViewById(R.id.morningStatus);
        eveningStatus = view.findViewById(R.id.eveningStatus);
        boolean teacher = MadrasaApp.get().isTeacher();
        morningBtn.setText(teacher ? R.string.mark_attendance : R.string.view_register);
        eveningBtn.setText(teacher ? R.string.mark_attendance : R.string.view_register);
        dateBtn.setOnClickListener(v -> pickDate());
        morningBtn.setOnClickListener(v -> open(Db.SESSION_MORNING));
        eveningBtn.setOnClickListener(v -> open(Db.SESSION_EVENING));
        view.findViewById(R.id.weeklyBtn).setOnClickListener(v ->
                startActivity(new Intent(getContext(), WeeklyGridActivity.class)));
        refresh();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (dateBtn != null) refresh();
    }

    private void pickDate() {
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date));
        } catch (Exception ignored) {}
        new DatePickerDialog(requireContext(), (dp, y, m, d) -> {
            date = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            refresh();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void open(String session) {
        Intent i = new Intent(getContext(), AttendanceRegisterActivity.class);
        i.putExtra("date", date);
        i.putExtra("session", session);
        startActivity(i);
    }

    private void refresh() {
        dateBtn.setText(Db.pretty(requireContext(), date));
        loadStatus(Db.SESSION_MORNING, morningStatus);
        loadStatus(Db.SESSION_EVENING, eveningStatus);
        applyFonts(getView());
    }

    private void loadStatus(String session, TextView tv) {
        Db.fs().collection(Db.ATTENDANCE).document(Db.docId(date, session)).get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists()) { tv.setText(getString(R.string.not_marked)); return; }
                    Map<String, Object> marks = (Map<String, Object>) doc.get("marks");
                    int p = 0, a = 0, l = 0;
                    if (marks != null) for (Object v : marks.values()) {
                        if (Db.MARK_PRESENT.equals(v)) p++;
                        else if (Db.MARK_ABSENT.equals(v)) a++;
                        else if (Db.MARK_LEAVE.equals(v)) l++;
                    }
                    tv.setText(getString(R.string.marked_done) + " — " + getString(R.string.totals_line, p + a + l, p, a, l));
                    applyFonts(getView());
                })
                .addOnFailureListener(e -> tv.setText(getString(R.string.not_marked)));
    }
}
