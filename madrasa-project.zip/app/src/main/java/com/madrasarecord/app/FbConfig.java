package com.madrasarecord.app;

// Values of the Firebase Android app registered for this package
// (projects/rabta-24267/androidApps/1:635724835065:android:e20c87fe357f7becfb1a28).
public final class FbConfig {
    public static final String API_KEY = "AIzaSyBYg_yuYQDogVewRdxBMxFJidLC1p5XqSA";
    public static final String APP_ID = "1:635724835065:android:e20c87fe357f7becfb1a28";
    public static final String PROJECT_ID = "rabta-24267";
    public static final String SENDER_ID = "635724835065";
    public static final String STORAGE_BUCKET = "rabta-24267.firebasestorage.app";
    private FbConfig() {}
}
