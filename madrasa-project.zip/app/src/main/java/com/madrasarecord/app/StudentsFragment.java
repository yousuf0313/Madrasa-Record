package com.madrasarecord.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class StudentsFragment extends BaseFragment {
    private final List<Db.Student> all = new ArrayList<>();
    private final List<Db.Student> shown = new ArrayList<>();
    private Adapter adapter;
    private TextView emptyTv, countTv;
    private EditText search;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_students, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView list = view.findViewById(R.id.studentsList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        emptyTv = view.findViewById(R.id.studentsEmpty);
        countTv = view.findViewById(R.id.studentsCount);
        search = view.findViewById(R.id.searchInput);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { filter(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        View fab = view.findViewById(R.id.addStudentFab);
        fab.setVisibility(MadrasaApp.get().isTeacher() ? View.VISIBLE : View.GONE);
        fab.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            all.clear();
            for (DocumentSnapshot d : q.getDocuments()) all.add(new Db.Student(d));
            Db.assignSerials(all);
            Db.sortBySerial(all);
            filter();
        });
    }

    private void filter() {
        String needle = search.getText() == null ? "" : search.getText().toString().trim().toLowerCase();
        shown.clear();
        for (Db.Student s : all) {
            if (needle.isEmpty() || s.name.toLowerCase().contains(needle) || s.fatherName.toLowerCase().contains(needle)) shown.add(s);
        }
        countTv.setText(getString(R.string.total_students) + ": " + shown.size());
        emptyTv.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        applyFonts(getView());
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_row, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = shown.get(position);
            h.serial.setText(String.valueOf(s.serial));
            h.admission.setText(getString(R.string.admission_date) + ": " + (s.admissionDate.isEmpty() ? "—" : s.admissionDate));
            h.dob.setText(getString(R.string.date_of_birth) + ": " + (s.dateOfBirth.isEmpty() ? "—" : s.dateOfBirth));
            h.age.setText(getString(R.string.age_lbl) + ": " + Db.ageText(requireContext(), s));
            h.reg.setText(s.registrationNumber.isEmpty() ? "—" : s.registrationNumber);
            h.name.setText(s.name);
            h.father.setText(getString(R.string.father_name) + ": " + s.fatherName);
            h.completion.setText(s.completionDate.isEmpty() ? "—" : s.completionDate);
            h.duration.setText(Db.durationText(requireContext(), s));
            Db.loadPhoto(requireContext(), s, h.photo);
            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(getContext(), StudentDetailActivity.class);
                i.putExtra("studentId", s.id);
                i.putExtra("serial", s.serial);
                startActivity(i);
            });
            // Teacher only: long-press a register row for the delete option.
            // The Muhtamim gets no long-press menu at all (read-only role).
            if (MadrasaApp.get().isTeacher()) {
                h.itemView.setOnLongClickListener(v -> { showRowMenu(s); return true; });
            } else {
                h.itemView.setOnLongClickListener(null);
            }
            Ui.applyFont(h.itemView, requireContext());
        }

        @Override
        public int getItemCount() { return shown.size(); }

        class Holder extends RecyclerView.ViewHolder {
            ImageView photo; TextView serial, admission, dob, age, reg, name, father, completion, duration;
            Holder(View v) {
                super(v);
                serial = v.findViewById(R.id.rowSerial);
                admission = v.findViewById(R.id.rowAdmission);
                dob = v.findViewById(R.id.rowDob);
                age = v.findViewById(R.id.rowAge);
                reg = v.findViewById(R.id.rowReg);
                photo = v.findViewById(R.id.rowPhoto);
                name = v.findViewById(R.id.rowName);
                father = v.findViewById(R.id.rowFather);
                completion = v.findViewById(R.id.rowCompletion);
                duration = v.findViewById(R.id.rowDuration);
            }
        }
    }

    // Long-press row menu (Teacher only) — currently just the delete option,
    // leading to the same confirmation + complete delete as the detail page.
    private void showRowMenu(Db.Student s) {
        new AlertDialog.Builder(requireContext())
                .setTitle(s.name)
                .setItems(new CharSequence[]{getString(R.string.delete_student)}, (d, w) -> confirmDeleteStudent(s))
                .show();
    }

    private void confirmDeleteStudent(Db.Student s) {
        new AlertDialog.Builder(requireContext())
                .setMessage(R.string.delete_student_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    Db.deleteStudentCompletely(requireContext(), s.id, s.photoUrl, ok -> {
                        if (ok) {
                            Toast.makeText(requireContext(), R.string.student_deleted, Toast.LENGTH_SHORT).show();
                            load();
                        } else {
                            Toast.makeText(requireContext(), R.string.err_generic, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}
