package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

// Paper register — a sub-view of the class tab in v1.1.0. Shows ACTIVE
// students only (graduated students live in the فارغ التحصیل list; their
// records open from there). There is NO delete in the register anymore
// (owner's order 2026-11-05): deleting happens only from the student
// record page. Dates are dual (Gregorian + Hijri) everywhere here.
public class StudentsFragment extends BaseFragment {
    private final List<Db.Student> all = new ArrayList<>();
    private final List<Db.Student> shown = new ArrayList<>();
    private Adapter adapter;
    private TextView emptyTv, countTv;
    private EditText search;
    private String lang = "ur";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_students, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        lang = Ui.lang(requireContext());
        RecyclerView list = view.findViewById(R.id.studentsList);
        list.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new Adapter();
        list.setAdapter(adapter);
        emptyTv = view.findViewById(R.id.studentsEmpty);
        countTv = view.findViewById(R.id.studentsCount);
        search = view.findViewById(R.id.searchInput);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { filter(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        // Header words must never split mid-word (owner's rule): each
        // header label shrinks to fit its column on ONE line.
        Ui.fitOneLine(view.findViewById(R.id.hdrSerial), 11f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrAdmission), 11f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrDob), 11f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrReg), 10f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrName), 12f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrCompletion), 10.5f, 7f);
        Ui.fitOneLine(view.findViewById(R.id.hdrDuration), 10.5f, 7f);
        // Add-student: teacher AND Muhtamim (v1.1.0 role split).
        View fab = view.findViewById(R.id.addStudentFab);
        fab.setVisibility(MadrasaApp.get().canManage() ? View.VISIBLE : View.GONE);
        fab.setOnClickListener(v -> startActivity(new Intent(getContext(), StudentEditActivity.class)));
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) load();
    }

    private void load() {
        Db.fs().collection(Db.STUDENTS).get().addOnSuccessListener(q -> {
            all.clear();
            for (DocumentSnapshot d : q.getDocuments()) {
                Db.Student s = new Db.Student(d);
                if (!s.graduated) all.add(s); // active register only
            }
            Db.assignSerials(all);
            Db.sortBySerial(all);
            filter();
        });
    }

    private void filter() {
        String needle = search.getText() == null ? "" : search.getText().toString().trim().toLowerCase();
        shown.clear();
        for (Db.Student s : all) {
            if (needle.isEmpty() || s.name.toLowerCase().contains(needle) || s.fatherName.toLowerCase().contains(needle)) shown.add(s);
        }
        countTv.setText(getString(R.string.total_students) + ": " + shown.size());
        emptyTv.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        applyFonts(getView());
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_row, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            Db.Student s = shown.get(position);
            h.serial.setText(String.valueOf(s.serial));
            // Dual dates: Gregorian on one line (short form), the Hijri
            // date on its own single line under it — shrink-to-fit with
            // font padding kept ON, so Nastaliq glyphs never clip.
            h.admission.setText(s.admissionDate.isEmpty() ? "—" : Hijri.gregorianShort(s.admissionDate, lang));
            h.admissionHijri.setText(s.admissionDate.isEmpty() ? "" : Hijri.format(s.admissionDate, lang));
            Ui.fitOneLine(h.admissionHijri, 10.5f, 7f);
            h.dob.setText(s.dateOfBirth.isEmpty() ? "—" : Hijri.gregorianShort(s.dateOfBirth, lang));
            h.dobHijri.setText(s.dateOfBirth.isEmpty() ? "" : Hijri.format(s.dateOfBirth, lang));
            Ui.fitOneLine(h.dobHijri, 10.5f, 7f);
            h.age.setText(getString(R.string.age_lbl) + ": " + Db.ageText(requireContext(), s));
            h.reg.setText(s.registrationNumber.isEmpty() ? "—" : s.registrationNumber);
            // Name + father wrap in FULL here (register exception to the
            // one-line rule) — never truncated.
            h.name.setText(s.name);
            h.father.setText(s.fatherName.isEmpty() ? "—" : getString(R.string.son_of) + " " + s.fatherName);
            h.itemView.setBackgroundColor(position % 2 == 0
                    ? android.graphics.Color.TRANSPARENT
                    : getResources().getColor(R.color.surface, null));
            h.divider.setVisibility(position == shown.size() - 1 ? View.GONE : View.VISIBLE);
            if (s.completionDate.isEmpty()) {
                h.completion.setText("");
                h.completionHijri.setText("");
                h.completionLabel.setText(getString(R.string.ongoing_lbl));
                h.completionLabel.setTextColor(getResources().getColor(R.color.muted, null));
            } else {
                h.completion.setText(Hijri.gregorianShort(s.completionDate, lang));
                h.completionHijri.setText(Hijri.format(s.completionDate, lang));
                Ui.fitOneLine(h.completionHijri, 10f, 7f);
                h.completionLabel.setText(s.completionLabel);
                h.completionLabel.setTextColor(getResources().getColor(R.color.green_c, null));
            }
            h.duration.setText(Db.durationText(requireContext(), s));
            Db.loadPhoto(requireContext(), s, h.photo);
            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(getContext(), StudentDetailActivity.class);
                i.putExtra("studentId", s.id);
                i.putExtra("serial", s.serial);
                startActivity(i);
            });
            // NO long-press menu / delete in the register (owner's order).
            h.itemView.setOnLongClickListener(null);
            Ui.applyFont(h.itemView, requireContext());
        }

        @Override
        public int getItemCount() { return shown.size(); }

        class Holder extends RecyclerView.ViewHolder {
            ImageView photo; TextView serial, admission, admissionHijri, dob, dobHijri, age, reg,
                    name, father, completion, completionHijri, completionLabel, duration;
            View divider;
            Holder(View v) {
                super(v);
                divider = v.findViewById(R.id.rowDivider);
                serial = v.findViewById(R.id.rowSerial);
                admission = v.findViewById(R.id.rowAdmission);
                admissionHijri = v.findViewById(R.id.rowAdmissionHijri);
                dob = v.findViewById(R.id.rowDob);
                dobHijri = v.findViewById(R.id.rowDobHijri);
                age = v.findViewById(R.id.rowAge);
                reg = v.findViewById(R.id.rowReg);
                photo = v.findViewById(R.id.rowPhoto);
                name = v.findViewById(R.id.rowName);
                father = v.findViewById(R.id.rowFather);
                completion = v.findViewById(R.id.rowCompletion);
                completionHijri = v.findViewById(R.id.rowCompletionHijri);
                completionLabel = v.findViewById(R.id.rowCompletionLabel);
                duration = v.findViewById(R.id.rowDuration);
            }
        }
    }
}
