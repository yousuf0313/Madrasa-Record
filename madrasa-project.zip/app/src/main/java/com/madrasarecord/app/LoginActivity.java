package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.firestore.DocumentSnapshot;

// Sign-in is MOBILE-NUMBER-ONLY (v1.0.4): number + password; the number is
// internally mapped to its pseudo-email for Firebase auth.
public class LoginActivity extends BaseActivity {
    private TextInputEditText emailIn, passIn;
    private TextView errorTv;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        ((TextView) findViewById(R.id.authTitle)).setText(R.string.login_title);
        ((TextView) findViewById(R.id.authSubtitle)).setText(R.string.app_name);
        ((TextInputLayout) findViewById(R.id.nameBox)).setVisibility(View.GONE);
        emailIn = findViewById(R.id.emailInput);
        passIn = findViewById(R.id.passwordInput);
        errorTv = findViewById(R.id.authError);
        btn = findViewById(R.id.authButton);
        btn.setText(R.string.login_btn);
        btn.setOnClickListener(v -> login());
        // Forgot-password link (v1.0.11): this layout is shared with
        // SetupActivity, where the link stays hidden (gone by default).
        TextView forgot = findViewById(R.id.forgotLink);
        forgot.setVisibility(View.VISIBLE);
        forgot.setOnClickListener(v -> startActivity(new Intent(this, ForgotPasswordActivity.class)));
    }

    private void showError(int res) {
        errorTv.setText(res);
        errorTv.setVisibility(View.VISIBLE);
    }

    private void login() {
        String number = emailIn.getText() == null ? "" : emailIn.getText().toString().trim();
        String pass = passIn.getText() == null ? "" : passIn.getText().toString();
        if (number.isEmpty() || pass.isEmpty()) { showError(R.string.fill_all_fields); return; }
        String canon = AuthHelp.canonicalMobile(number);
        if (canon == null) { showError(R.string.err_mobile_invalid); return; }
        btn.setEnabled(false);
        btn.setText(R.string.signing_in);
        resolveAndSignIn(canon, pass);
    }

    // Sign-in email resolution (v1.0.11): an account whose password was
    // reset signs in with a NEW pseudo-email, recorded on its user doc as
    // authEmail. So the email is resolved from the user doc (looked up by
    // mobile, full-collection read matched in memory — the codebase's
    // existing users pattern): authEmail first, then the legacy email
    // field, then the derived <mobile>@madrasa.local. When the lookup
    // itself fails (e.g. offline before any sync), the derived legacy
    // email is used, so the pre-v1.0.11 path is fully preserved.
    private void resolveAndSignIn(String canon, String pass) {
        Db.fs().collection(Db.USERS).get()
                .addOnSuccessListener(q -> {
                    String email = null;
                    for (DocumentSnapshot d : q.getDocuments()) {
                        if (!canon.equals(strField(d, "mobile"))) continue;
                        email = strField(d, "authEmail");
                        if (email == null || email.isEmpty()) email = strField(d, "email");
                        break;
                    }
                    if (email == null || email.isEmpty()) email = AuthHelp.pseudoEmail(canon);
                    signIn(email, pass);
                })
                .addOnFailureListener(e -> signIn(AuthHelp.pseudoEmail(canon), pass));
    }

    private void signIn(String authEmail, String pass) {
        MadrasaApp.get().auth().signInWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Db.fs().collection(Db.USERS).document(uid).get()
                            .addOnSuccessListener(doc -> {
                                if (doc.exists()) {
                                    // Backfill (v1.0.11): record the email
                                    // this account signs in with, so future
                                    // resolution never depends on deriving.
                                    if (strField(doc, "authEmail") == null) {
                                        doc.getReference().update("authEmail", authEmail);
                                    }
                                    MadrasaApp.get().setSession(doc.getString("role"), doc.getString("name"));
                                    startActivity(new Intent(this, MainActivity.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(this, NotAuthorizedActivity.class));
                                    finish();
                                }
                            })
                            .addOnFailureListener(e -> fail());
                })
                .addOnFailureListener(e -> {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_btn);
                    showError(AuthHelp.errorRes(e, true));
                });
    }

    // Instanceof-safe field read (same hardening pattern as SplashActivity).
    private static String strField(DocumentSnapshot doc, String field) {
        try {
            Object v = doc.get(field);
            return v instanceof String ? (String) v : null;
        } catch (Exception e) {
            return null;
        }
    }

    private void fail() {
        btn.setEnabled(true);
        btn.setText(R.string.login_btn);
        showError(R.string.err_generic);
    }
}
