package com.madrasarecord.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

// Sign-in is MOBILE-NUMBER-ONLY (v1.0.4): number + password; the number is
// internally mapped to its pseudo-email for Firebase auth.
public class LoginActivity extends BaseActivity {
    private TextInputEditText emailIn, passIn;
    private TextView errorTv;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        ((TextView) findViewById(R.id.authTitle)).setText(R.string.login_title);
        ((TextView) findViewById(R.id.authSubtitle)).setText(R.string.app_name);
        ((TextInputLayout) findViewById(R.id.nameBox)).setVisibility(View.GONE);
        emailIn = findViewById(R.id.emailInput);
        passIn = findViewById(R.id.passwordInput);
        errorTv = findViewById(R.id.authError);
        btn = findViewById(R.id.authButton);
        btn.setText(R.string.login_btn);
        btn.setOnClickListener(v -> login());
    }

    private void showError(int res) {
        errorTv.setText(res);
        errorTv.setVisibility(View.VISIBLE);
    }

    private void login() {
        String number = emailIn.getText() == null ? "" : emailIn.getText().toString().trim();
        String pass = passIn.getText() == null ? "" : passIn.getText().toString();
        if (number.isEmpty() || pass.isEmpty()) { showError(R.string.fill_all_fields); return; }
        String canon = AuthHelp.canonicalMobile(number);
        if (canon == null) { showError(R.string.err_mobile_invalid); return; }
        String authEmail = AuthHelp.pseudoEmail(canon);
        btn.setEnabled(false);
        btn.setText(R.string.signing_in);
        MadrasaApp.get().auth().signInWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(res -> {
                    String uid = res.getUser().getUid();
                    Db.fs().collection(Db.USERS).document(uid).get()
                            .addOnSuccessListener(doc -> {
                                if (doc.exists()) {
                                    MadrasaApp.get().setSession(doc.getString("role"), doc.getString("name"));
                                    startActivity(new Intent(this, MainActivity.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(this, NotAuthorizedActivity.class));
                                    finish();
                                }
                            })
                            .addOnFailureListener(e -> fail());
                })
                .addOnFailureListener(e -> {
                    btn.setEnabled(true);
                    btn.setText(R.string.login_btn);
                    showError(AuthHelp.errorRes(e, true));
                });
    }

    private void fail() {
        btn.setEnabled(true);
        btn.setText(R.string.login_btn);
        showError(R.string.err_generic);
    }
}
