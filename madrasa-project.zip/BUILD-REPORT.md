# BUILD-REPORT — v1.0.7 (Gradle/AGP migration)

Status at writing (2026-10-27 ~18:55 PKT): **project complete and prepared
locally; CI build BLOCKED on GitHub write access (see "Blocker").** Nothing
below claims a built APK yet — signing + verification run after the workflow
produces the unsigned artifact.

## Why this build exists
The hand-rolled manual pipeline (`~/workspace/madrasa-app/build-manual.sh`)
killed every shipped build: manifest-merge corruption (v1.0.0–1.0.2), the
six-tab Material crash (v1.0.4), and — proven by the 6-slice audit — v1.0.6's
standalone R8 config had **no layout-XML keep rules** (AGP auto-generates
them via aapt): 40 of 47 classes named in the APK's binary XML were shrunk
out of the dex, including AppCompat's sub-decor classes, so
`SplashActivity.setContentView` threw InflateException on the first screen
of every launch. This project rebuilds the same app with the standard
Gradle/AGP system (the one that ships Easy Chat) and makes that whole class
of bug structurally impossible.

## Project layout (`~/workspace/madrasa-app-gradle/`)
Standard Gradle project; the manual project in `~/workspace/madrasa-app/`
is untouched and remains the fallback until this build is phone-verified.

- `settings.gradle`, `build.gradle` — AGP **8.7.3** (plugins DSL), google() +
  mavenCentral()
- `gradle/wrapper/` — Gradle **8.9** wrapper. The wrapper jar was extracted
  from the genuine Gradle 8.9 distribution (the `wrapper` task itself cannot
  run in this VM — Gradle's daemon needs loopback sockets, which are broken
  here); gradlew/gradlew.bat are the standard 8.x scripts.
- `gradle.properties` — useAndroidX; `nonTransitiveRClass=false` to match the
  old merged-resources behaviour.
- `app/build.gradle` — namespace/applicationId `com.madrasarecord.app`,
  compileSdk/targetSdk **34**, minSdk **26**, **versionCode 8 /
  versionName 1.0.7**. Release: `minifyEnabled true`, `shrinkResources
  false`, default `proguard-android-optimize.txt` + `proguard-rules.pro`.
  **No signing config** — CI builds unsigned; signing happens locally with
  the existing keystore, as before.
- Dependencies — identical to the manual build's resolved set
  (`deps/resolution.json`): appcompat 1.7.0, recyclerview 1.3.2, material
  1.12.0, Firebase BoM **33.1.2** → firebase-auth 23.0.0,
  firebase-firestore 25.0.0, firebase-storage 21.0.0.
- **Firebase init unchanged, in code.** `MadrasaApp` builds `FirebaseOptions`
  from `FbConfig` constants in `onCreate`; `UsersActivity` creates its
  secondary app the same way. The `com.google.gms.google-services` plugin
  is deliberately **NOT** applied and no google-services.json is used — the
  FirebaseInitProvider phase behaves exactly as in the shipped app.
- `app/proguard-rules.pro` — on top of AGP's auto-merged AAR consumer rules
  and aapt-generated layout keeps:
  `-keep class com.madrasarecord.app.** { *; }`,
  `-keep class * implements com.google.firebase.components.ComponentRegistrar { public <init>(); }`,
  `-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod`.
- Source/resources/assets copied unchanged from the manual project (27 Java
  files, 3 locales, 16 fonts, DAHR branding, 6-item bottom_nav), except the
  two audit-prescribed changes below.
- Binary files (16 TTF fonts, 5 launcher PNGs, emblem WebP, wrapper jar)
  cannot travel the text-only GitHub push route, so they are committed as
  base64 parts under `bin-b64/` (same pattern as the Easy Chat repo) and the
  workflow restores them before building. Round-trip sha256 verified
  locally: `38edafdc24eac584397a25aa7b2ea4d3363364494da8ee0b6c9ad3a791b4096f`.
- `.github/workflows/build.yml` — on push to main / workflow_dispatch:
  checkout → JDK 17 (temurin) → restore binaries → `./gradlew
  assembleRelease` → upload unsigned-APK artifact + R8 outputs
  (mapping/usage/seeds/configuration) → attach the unsigned APK to a
  clearly-marked CI **prerelease** `v1.0.7-ci` (retrieval route for local
  signing, same pattern as Easy Chat's releases; official releases are
  published separately and existing tags/assets are untouched).

## Audit-prescribed changes applied in this project
1. **CrashNet hardening.** Handler now installed in
   `MadrasaApp.attachBaseContext` (earliest lifecycle point — a crash during
   `onCreate` is now recorded too). `SplashActivity` peeks the stored crash
   **before** `setContentView` and calls `CrashNet.clear()` only inside the
   dialog-dismissed callback, so a failure while showing the dialog can no
   longer discard the record. Rest of CrashNet behaviour unchanged.
   Compile smoke check: sources compile against the manual project's exact
   dependency jars (MadrasaApp verified in isolation; full compile of the
   R-referencing classes happens in CI — the local aapt2 harness cannot
   merge library resource tables the way AGP's merger does).
2. **Rename (user order).** «ڈیجیٹل آسان حاضری رجسٹر» everywhere visible:
   - `app_name` was already the brand in all locales — values (default/Urdu)
     `ڈیجیٹل آسان حاضری رجسٹر`, values-en `Digital Asan Hazri Register`,
     values-ar `ڈیجیٹل آسان حاضری رجسٹر` (same brand string, as on the
     logo). No change needed.
   - Full-project grep for "Madrasa Record"/"MadrasaRecord" display text:
     the only hits were two build-file comments (cleaned) and
     `rootProject.name = "MadrasaRecord"` in settings.gradle — an internal
     build identifier, kept deliberately like the package name
     `com.madrasarecord.app` and the repo name (never user-visible).
   - CI filenames aligned: the unsigned artifact is exported as
     `Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk`; the final signed
     deliverable will be `~/workspace/your_files/Digital-Asan-Hazri-Register.apk`.

## Verification battery (runs on the signed APK once CI unblocks)
All v1.0.6 checks, with ground truth taken from AGP's own outputs
(mapping/seeds/usage from the CI build — never a hand-made list):
cert SHA-256 must equal `3f3a4aed…` + apksigner v2 + zipalign; vc8/1.0.7;
exactly 3 permissions; ComponentDiscoveryService ×1 with all 9 registrars;
InitializationProvider ×1 with 3 initializers; appComponentFactory present;
duplicate components 0; merged-manifest `"${"` placeholder scan = 0;
META-INF/services complete; okhttp defined; referenced-vs-defined (app
classes) 0 missing; findViewById ⊆ layout ids; strings 160/160/160
(default/en/ar); CNIC 0; 16 fonts present + parseable; **every
ContentProvider class in the merged manifest + its initializer classes
defined with key methods; every ComponentRegistrar defined with public
`<init>` AND `getComponents()`; and the mandatory new gate — every class
named in any binary XML of the final APK (expect ~47 named) defined in the
final dex, 0 missing, including the (Context, AttributeSet) constructors of
layout-named views.**

## CI result + local signing + verification battery (2026-10-27, Run #4)

- Run #3 (40528527741) failed ONLY at `:app:minifyReleaseWithR8`:
  `app/proguard-rules.pro` used `//` comments (ProGuard files require `#`).
  Fixed in place (comments → `#`, rules unchanged); everything before the
  R8 step had compiled cleanly.
- **Run #4 (40529602769) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/40529602769
  Prerelease `v1.0.7-ci` carried the unsigned APK (5,444,385 bytes,
  sha256 d94e72433c091e3f44e501c2dc5814fcccbcbc138cfe95072293044a09be6df9).
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk`
  **Size: 5,535,410 bytes — sha256 a36c6908b3733a7438855750aab3b702248b73beaae7cf5bee89866b34cfbafa**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true**; cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 8 / versionName 1.0.7** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. The merged manifest carries 5 `uses-permission` elements —
  the 2 extra are standard AGP/library contributions, itemized:
  `com.google.android.providers.gsf.permission.READ_GSERVICES`
  (play-services-basement) and
  `com.madrasarecord.app.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`
  (auto-added by AGP/androidx). The hand-merged v1.0.6 manifest lacked both.
- **ComponentDiscoveryService ×1 with all 9 registrars** (auth, firestore
  ×2, storage ×2, appcheck ×2, firebase-common ×2) — every registrar
  DEFINED with **public `<init>()`** AND **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with `<init>` plus
  create-shaped `(Context)Object` and dependencies-shaped `()List`
  methods (method names obfuscated consistently by R8) ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; duplicate components = **0** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every interface and every listed implementation class is defined in the
  dex, and each implementation's superclass matches its service interface ✓
- App referenced-vs-defined: 119 referenced, **0 missing** ✓
- findViewById ⊆ layout ids: only non-layout id is `android.R.id.content`
  (framework) ✓
- Strings in the APK itself: **160/160/160** (default/en/ar — every app
  string name has a value in each locale) ✓
- CNIC occurrences in dex + resources: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 42 classes named in binary XML; 41/41 app+library classes
  DEFINED, 0 missing** (the one remaining name, `android.widget.Space`,
  is a framework class resolved from the Android boot classpath).
  Layout-named views lacking a (Context, AttributeSet) constructor: **0**
  — including every v1.0.6 casualty (FitWindowsLinearLayout,
  FitWindowsFrameLayout, ContentFrameLayout, ViewStubCompat,
  TextInputLayout, CheckableImageButton, BaselineLayout,
  FloatingActionButton, AlertDialogLayout) and
  `SixBottomNavigationView` with all 3 constructors ✓

### One check NOT verifiable at name level — "okhttp defined"
By its literal v1.0.6 form (`com.squareup.okhttp` / `okhttp3` classes under
those names): **not present**. AGP's R8 **obfuscated** the Firestore
transport stack (the manual pipeline's R8 did not obfuscate, which is why
v1.0.6 shows real names: io/grpc 331 + com/squareup 178 + firestore 216).
Evidence the stack is present-but-renamed, not removed:
- Total defined classes 5,174 vs v1.0.6's 5,064 — removal of the ~700-class
  grpc+okhttp+firestore stack is arithmetically incompatible with the
  totals; protobuf kept its names exactly (102 = 102).
- The dex string pool carries the full gRPC runtime message set
  ("Failed to find OkHttpChannelProvider", "fire/25.0.0 grpc/",
  io.grpc.* provider literals).
- META-INF/services consistency (above): provider interfaces and
  implementations line up under their renamed names, superclass-verified.
- Name-level certainty would require `mapping.txt`, which this CI run
  uploaded as a workflow **artifact** (`r8-outputs`); artifact download
  needs an authenticated route not available to the verification agent
  (the GitHub MCP toolset exposes no Actions-artifact tool). Runtime
  confirmation therefore rests with the standing final gate: the phone
  test (sign-in + Firestore data load).

## Blocker (verbatim, 2026-10-27)
The prepared push of all 76 project files (2,654,804 bytes) to
`yousuf0313/Madrasa-Record @ main` (head `016c3c627afa…`, contents: only
`initial-commit.txt`; all project paths are new, no divergence) failed on
both connector write routes:

- push_files: `failed to create tree: POST https://api.github.com/repos/yousuf0313/Madrasa-Record/git/trees: 403 Resource not accessible by integration []`
- create_or_update_file (single-file probe): `failed to create/update file: PUT https://api.github.com/repos/yousuf0313/Madrasa-Record/contents/settings.gradle: 403 Resource not accessible by integration []`

Reads via the same connector work (repo contents, commits, Easy Chat
workflow). The Muse GitHub App installation therefore has read-only access
to this repository. **Exact missing piece: the installation must be granted
the Madrasa-Record repository with Contents read-and-write permission**
(GitHub → Settings → Applications → Muse → repository selection /
permissions). Per the connector rules no other auth route may be improvised
(gh CLI is not logged in; PATs/OAuth from chat are forbidden). Once access is
granted: re-run the snapshot push (manifest in /tmp/madrasa-paths.z +
BUILD-REPORT.md), the push triggers the workflow, download
`Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk` from the `v1.0.7-ci`
prerelease, zipalign + sign locally with
`~/workspace/madrasa-app/madrasa.keystore`, run the battery above, and
complete this report with run URL, size and sha256.

---

# v1.0.8 (2026-10-28) — fragment-overlap fix + preview-faithful restyle

Status at writing: **sources + upload zip prepared locally; CI build is
GATED on the owner's explicit approval** (he reviews the preview first).
Nothing below claims a built APK.

## 1. Fragment-overlap bug — fixed (MainActivity rewritten)

Phone evidence (v1.0.7 screen recording): the app ran (login, tabs, data
all fine) but views of MULTIPLE fragments were visible simultaneously —
Settings' "Sign out"/"Check update" buttons and About text ghosted over
the Home, Attendance and Report screens.

Root cause: the old `MainActivity` kept a `Map<Integer, Fragment>` of
FRESH instances and switched with `add()` + `hide()`/`show()`, tracking
an `active` field. On activity recreation (rotation, process death, the
language/font pickers' `recreate()`), the FragmentManager restored the
previous fragments into `R.id.fragmentContainer`, but the map held new
instances and `active == null` — restored screens were never hidden and
stayed visible under everything, permanently.

Fix (`MainActivity.java`, only file with logic changes besides the two
noted below):
- `onCreate`: first removes EVERY fragment the FragmentManager already
  holds in `R.id.fragmentContainer` (restored orphans, single
  `commitNow()`), then installs a fresh `HomeFragment` via `replace()`.
- `switchTo(id)`: `replace()` with a new instance of the target class;
  `currentId`/`active` updated before commit. Exactly one fragment can
  exist in the container, so overlap is structurally impossible.
- The bottom nav gets `android:saveEnabled="false"` so its checked item
  cannot be restored out of sync with the always-Home recreation state.
- Preserved: header username (`headerUser`), the `UpdateCheck.check`
  call (fresh-create only), all 6 tabs through `SixBottomNavigationView`,
  and the post-switch `applyFontsSoon()` pass.

## 2. Version label — fixed

Settings hardcoded the version through `version_lbl` strings ("ورژن
1.0.6" in a 1.0.7 build). Now: the three `version_lbl` strings carry
only the label word (ورژن / Version / الإصدار), `fragment_settings.xml`
gives the TextView `android:id="@+id/versionTv"`, and
`SettingsFragment` sets `version_lbl + " " + BuildConfig.VERSION_NAME`.
`app/build.gradle`: `buildFeatures.buildConfig true`, **versionCode 9 /
versionName 1.0.8**.

## 3. Design spec extracted from the approved preview (space-7)

Source: `client/src/theme.css` + `client/src/App.tsx` (light theme; the
native app has a single light theme, so the preview's dark variant is
not mirrored).

Palette: page bg `#F6F1E3` (cream) · surface `#FFFDF4` · surface-alt
`#EFE8D2` · text `#1D2A1E` · dim `#6D7263` · border `#DDD2B4` · green
`#14532D` · green-deep `#0D3B21` · green-soft `#E3EFDD` · gold `#B8860B`
· gold-bright `#D9A92C` · gold-soft `#F3E5BD` · header sub-text
`#CFE3C8` · red `#B3352B` / red-soft `#F9E3E0` · amber `#9A6A00` /
amber-soft `#F7ECC9`.

Geometry/type: card radius 16dp, padding 16dp, 1dp sand border; inputs
radius 8dp, surface fill, sand border; buttons radius 12dp, min-height
48dp, bold; screen titles 18sp bold ink; card titles 16sp bold ink;
field labels 14sp bold ink; content inset 12dp.

Components:
- **Banner header**: floating card (12dp side inset, 8dp top), green
  gradient `#14532D → #0D3B21`, 2dp gold border, 16dp radius; DAHR mark
  46dp; name 19sp bold `#F3E5BD`; sub-line 12sp `#CFE3C8`; 3dp gold
  gradient rule (transparent → `#D9A92C` → transparent) inside the card.
- **RefCard** (ayah/hadith): gold 14sp bold title above a surface card;
  Arabic 18sp, line-spacing ~1.8; translation 16sp ink; reference 14sp dim.
- **Register table**: 2dp green frame, 12dp radius; header row green-soft
  with green-deep bold 13sp labels (admission over a green rule over DOB
  in one cell); cells ruled 1.5dp green; columns 9/23/14/28/13/13 %;
  rows alternate page-cream / surface; serial 16sp bold centred; dates
  13sp; reg-no 13sp centred; student cell = 30dp round avatar + name
  15sp bold + "sonOf father" 12sp dim; completion/duration 13sp centred.
- **Attendance**: rows on surface cards; status chips — unselected: soft
  tint bg + coloured bold text; selected: solid status colour + white
  text + "✓ " prefix; totals strip green-soft.
- **Selector chips** (level, language): radius 8dp; selected: green
  border + green-soft fill + green text; unselected: sand border +
  surface fill + ink text.
- **Auth**: centred DAHR mark 72dp, title 24sp bold green, brand line
  gold bold, then the form inside a surface card.
- **Bottom nav: all 6 labels always visible, as preview** — see §4.
- Settings/report: stacked surface cards with 16sp bold ink titles;
  logout = red-outline button on surface.

## 4. Bottom navigation (owner requirement, explicit)

`app:labelVisibilityMode="labeled"` on `SixBottomNavigationView` — the
icon **and** text label show under **every one of the 6 items, always**
(Material's default selected-only label behaviour, visible in the
owner's v1.0.7 recording, is gone). Surface background with a 1dp sand
rule above the bar; active item deep green / inactive dim
(`@color/nav_colors`); icon size 22dp; labels 11sp bold
(`NavLabelActive`/`NavLabelInactive`) so six icon+label items fit
cleanly on one bar. The preview's bar is labels-only with a gold top
segment on the active tab; the native bar keeps the app's existing six
icons (owner's wording: label under every icon) and takes its colours
from the preview.

## 5. Screen-by-screen mapping (preview → native)

- **App header** (`activity_main`): flat green bar → the banner card
  (§3); big line = app name, sub-line = signed-in user (native header
  content; the preview's card carries madrasa name + app name, which is
  exactly what `layout_madrasa_header` now shows in fragments).
- **Madrasa banner** (`layout_madrasa_header`, Home + Report): centred
  62dp emblem + centred name + full-width gold bar → banner card with
  46dp mark at the start, name 19sp gold-soft (Katibeh kept via
  `keepFont` + `Ui.headerTypeface`), app name beneath, gold gradient
  rule inside.
- **Home**: white blocks → RefCards for the daily ayah/hadith (gold
  title + surface card); the today-summary block → one surface card
  (native combines the preview's 3 stat cards and the two session
  cards into this single totals/session card — same data, native
  arrangement kept); session buttons → preview outline buttons.
- **Students (register)**: card-per-row list → the preview's paper-
  register **table**: green frame + header row (labels moved into the
  header; the in-cell "label:" prefixes were dropped in
  `StudentsFragment` binding) + ruled alternating rows; search →
  preview input; empty state → surface card; FAB retinted deep green
  (preview's add action is a header button + the home CTA; the native
  FAB is kept as the same action, recoloured).
- **Attendance hub**: section labels → two preview session cards
  (heading + status + primary button); date button → outline (input-
  like); weekly button → outline.
- **Attendance register** (`activity_register` + `item_register_row`):
  flat green header → banner card; "mark all" → primary button
  (preview); rows → surface cards with preview attendance-row layout;
  P/A/L buttons → preview status chips (§3, via `styleToggle` in
  `AttendanceRegisterActivity`); footer → green-soft totals strip.
- **Report**: sections → preview cards (morning, evening, absent-today,
  weekly summary); banner card included as on Home.
- **Ayat/Hadith library**: rows → RefCards with the preview's gold-soft
  kind chip (rounded), 18sp Arabic, ink translation, dim reference.
- **Settings**: loose sections → preview cards: account+language
  (language radios → selector chips), font (preview input + outline
  picker), madrasa name (card, teacher), users (card, teacher), update
  check (primary), about (card; version now real, §2), sign-out →
  preview's red-outline logout button.
- **Login/Setup** (`activity_auth`): → preview AuthShell composition:
  72dp mark, 24sp green title, gold bold brand line, form in a surface
  card; inputs keep Material outlined boxes, restyled to surface fill +
  8dp corners + green stroke (`MadrasaInput`).
- **Student form**: photo 110dp square → 80dp rounded frame (preview);
  photo pickers → outline buttons; class radios → selector chips
  (preview's level chips); field-group labels → preview field labels;
  date buttons → outline (input-like); "add number" → green text button
  (preview); save → primary. Inputs keep their floating-hint
  TextInputLayouts (see deviations).
- **Student detail**: photo → 110dp round avatar; body/mobiles/month/
  history blocks → surface cards with card titles; edit → primary,
  delete → solid red (preview).
- **Users**: rows → surface cards; role → gold-soft chip; delete →
  flat red-text button.
- **Weekly grid**: header → banner card; session buttons → outline
  pair; grid sits on a surface card; legend → green-soft strip (cells
  are built in code and inherit the re-pointed palette).
- **Splash / Not-authorized**: splash already matches (deep-green
  `#0D3B21` + gold-soft name); not-authorized content moved onto a
  surface card.

### Where exact mirroring was not possible (and why)
- **DAHR emblem corners/shadow**: the preview rounds the mark (12px)
  and shadows it; the native emblem is a WebP bitmap and the project
  has no CardView dependency, so the mark stays square in the banner.
  Colours/placement/sizes match.
- **Banner gradient angle**: CSS 150deg ≈ the drawable's 315deg
  two-stop green gradient (XML gradients are 45°-quantised); visually
  the same deep-green blend.
- **Preview's gold top segment on the active nav tab** is a CSS
  border trick with no BottomNavigationView equivalent; the bar takes
  the preview's surface bg, sand top rule and green/dim states instead.
- **Form inputs**: the preview uses label-above plain inputs; the
  native form keeps Material TextInputLayouts with floating hints
  (the existing Java binds `TextInputEditText` ids — swapping widget
  types would be a logic change, out of scope for a restyle). Boxes
  are restyled to the preview's surface/8dp/green-stroke look.
- **Register completion-label line**: the preview shows a completion
  label under the completion date; the native data model
  (`Db.Student`) has no completion-label field, so there is nothing
  to bind — the cell shows the date only, as before.
- **Preview home stat trio + view-only note**: native Home has no
  view-only banner element and combines stats into its summary card
  (see Home above); no elements were added or removed in this round.
- **Weekly grid internals**: cells are generated in code (no layout);
  they inherit the new palette via `R.color` but keep their existing
  padding/structure.
- **Dark theme**: the preview ships a dark variant; the app has a
  single light theme (as in v1.0.0–1.0.7) — out of scope.

## 6. Invariants kept

English digits only (no digit strings touched; the new `son_of` string
has no digits); strings 161/161/161 across values/values-en/values-ar
(one addition, `son_of` — ولد / s/o / بن, taken from the preview's own
i18n — needed to mirror the register's father line; label-only change
to `version_lbl` in all three); no CNIC anywhere; manual Firebase init
unchanged (no google-services plugin); `proguard-rules.pro` untouched
(`#` comments verified, zero `//` lines); wrapper jar untouched;
`minifyEnabled true`; package/keystore untouched.

## 7. Changed files

Java: `MainActivity.java` (rewritten switching), `SettingsFragment.java`
(version from BuildConfig), `StudentsFragment.java` (table-cell binding,
row alternation/divider), `AttendanceRegisterActivity.java`
(`styleToggle` → preview chips). Gradle: `app/build.gradle` (vc9/1.0.8,
buildConfig). Resources: `values/colors.xml` (palette re-pointed +
preview tokens added), `values/themes.xml` (preview button/input/title
styles + NavLabel appearances), strings ×3 (`version_lbl`, `son_of`),
`color/nav_colors.xml` (unchanged — inherits new palette),
`color/chip_text.xml` (new), drawables (new: `bg_card`, `bg_banner`,
`bg_gold_rule`, `bg_table`, `bg_table_header`, `bg_avatar`,
`bg_chip_gold`, `bg_input`, `bg_photo`, `bg_chip`), layouts (rewritten:
`activity_main`, `layout_madrasa_header`, `fragment_home`,
`fragment_students`, `item_student_row`, `fragment_attendance`,
`activity_register`, `item_register_row`, `fragment_report`,
`fragment_ayat`, `item_ayah`, `fragment_settings`, `activity_auth`,
`activity_student_detail`, `activity_student_edit`, `activity_users`,
`item_user_row`, `item_mobile_row`, `activity_weekly`,
`activity_not_authorized`).

## 8. Self-checks (local, pre-CI)

- All 48 res XML files parse (ElementTree); 0 malformed.
- All 137 `R.id.*` references in Java resolve to layout/menu ids.
- All `@color`/`@drawable`/`@style` references in layouts/values
  resolve; string sets identical across the 3 locales (161 each) and
  every `@string`/`R.string` reference resolves in every locale.
- Grep: no `1.0.6` remains in res/, java/ or gradle files (the visible
  version now comes only from BuildConfig); `app/build.gradle` inside
  the zip carries versionCode 9 / versionName 1.0.8.
- `app/proguard-rules.pro`: 0 lines starting with `//`.
