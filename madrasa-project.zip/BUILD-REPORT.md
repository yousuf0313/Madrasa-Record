# BUILD-REPORT — v1.0.7 (Gradle/AGP migration)

Status at writing (2026-10-27 ~18:55 PKT): **project complete and prepared
locally; CI build BLOCKED on GitHub write access (see "Blocker").** Nothing
below claims a built APK yet — signing + verification run after the workflow
produces the unsigned artifact.

## Why this build exists
The hand-rolled manual pipeline (`~/workspace/madrasa-app/build-manual.sh`)
killed every shipped build: manifest-merge corruption (v1.0.0–1.0.2), the
six-tab Material crash (v1.0.4), and — proven by the 6-slice audit — v1.0.6's
standalone R8 config had **no layout-XML keep rules** (AGP auto-generates
them via aapt): 40 of 47 classes named in the APK's binary XML were shrunk
out of the dex, including AppCompat's sub-decor classes, so
`SplashActivity.setContentView` threw InflateException on the first screen
of every launch. This project rebuilds the same app with the standard
Gradle/AGP system (the one that ships Easy Chat) and makes that whole class
of bug structurally impossible.

## Project layout (`~/workspace/madrasa-app-gradle/`)
Standard Gradle project; the manual project in `~/workspace/madrasa-app/`
is untouched and remains the fallback until this build is phone-verified.

- `settings.gradle`, `build.gradle` — AGP **8.7.3** (plugins DSL), google() +
  mavenCentral()
- `gradle/wrapper/` — Gradle **8.9** wrapper. The wrapper jar was extracted
  from the genuine Gradle 8.9 distribution (the `wrapper` task itself cannot
  run in this VM — Gradle's daemon needs loopback sockets, which are broken
  here); gradlew/gradlew.bat are the standard 8.x scripts.
- `gradle.properties` — useAndroidX; `nonTransitiveRClass=false` to match the
  old merged-resources behaviour.
- `app/build.gradle` — namespace/applicationId `com.madrasarecord.app`,
  compileSdk/targetSdk **34**, minSdk **26**, **versionCode 8 /
  versionName 1.0.7**. Release: `minifyEnabled true`, `shrinkResources
  false`, default `proguard-android-optimize.txt` + `proguard-rules.pro`.
  **No signing config** — CI builds unsigned; signing happens locally with
  the existing keystore, as before.
- Dependencies — identical to the manual build's resolved set
  (`deps/resolution.json`): appcompat 1.7.0, recyclerview 1.3.2, material
  1.12.0, Firebase BoM **33.1.2** → firebase-auth 23.0.0,
  firebase-firestore 25.0.0, firebase-storage 21.0.0.
- **Firebase init unchanged, in code.** `MadrasaApp` builds `FirebaseOptions`
  from `FbConfig` constants in `onCreate`; `UsersActivity` creates its
  secondary app the same way. The `com.google.gms.google-services` plugin
  is deliberately **NOT** applied and no google-services.json is used — the
  FirebaseInitProvider phase behaves exactly as in the shipped app.
- `app/proguard-rules.pro` — on top of AGP's auto-merged AAR consumer rules
  and aapt-generated layout keeps:
  `-keep class com.madrasarecord.app.** { *; }`,
  `-keep class * implements com.google.firebase.components.ComponentRegistrar { public <init>(); }`,
  `-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod`.
- Source/resources/assets copied unchanged from the manual project (27 Java
  files, 3 locales, 16 fonts, DAHR branding, 6-item bottom_nav), except the
  two audit-prescribed changes below.
- Binary files (16 TTF fonts, 5 launcher PNGs, emblem WebP, wrapper jar)
  cannot travel the text-only GitHub push route, so they are committed as
  base64 parts under `bin-b64/` (same pattern as the Easy Chat repo) and the
  workflow restores them before building. Round-trip sha256 verified
  locally: `38edafdc24eac584397a25aa7b2ea4d3363364494da8ee0b6c9ad3a791b4096f`.
- `.github/workflows/build.yml` — on push to main / workflow_dispatch:
  checkout → JDK 17 (temurin) → restore binaries → `./gradlew
  assembleRelease` → upload unsigned-APK artifact + R8 outputs
  (mapping/usage/seeds/configuration) → attach the unsigned APK to a
  clearly-marked CI **prerelease** `v1.0.7-ci` (retrieval route for local
  signing, same pattern as Easy Chat's releases; official releases are
  published separately and existing tags/assets are untouched).

## Audit-prescribed changes applied in this project
1. **CrashNet hardening.** Handler now installed in
   `MadrasaApp.attachBaseContext` (earliest lifecycle point — a crash during
   `onCreate` is now recorded too). `SplashActivity` peeks the stored crash
   **before** `setContentView` and calls `CrashNet.clear()` only inside the
   dialog-dismissed callback, so a failure while showing the dialog can no
   longer discard the record. Rest of CrashNet behaviour unchanged.
   Compile smoke check: sources compile against the manual project's exact
   dependency jars (MadrasaApp verified in isolation; full compile of the
   R-referencing classes happens in CI — the local aapt2 harness cannot
   merge library resource tables the way AGP's merger does).
2. **Rename (user order).** «ڈیجیٹل آسان حاضری رجسٹر» everywhere visible:
   - `app_name` was already the brand in all locales — values (default/Urdu)
     `ڈیجیٹل آسان حاضری رجسٹر`, values-en `Digital Asan Hazri Register`,
     values-ar `ڈیجیٹل آسان حاضری رجسٹر` (same brand string, as on the
     logo). No change needed.
   - Full-project grep for "Madrasa Record"/"MadrasaRecord" display text:
     the only hits were two build-file comments (cleaned) and
     `rootProject.name = "MadrasaRecord"` in settings.gradle — an internal
     build identifier, kept deliberately like the package name
     `com.madrasarecord.app` and the repo name (never user-visible).
   - CI filenames aligned: the unsigned artifact is exported as
     `Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk`; the final signed
     deliverable will be `~/workspace/your_files/Digital-Asan-Hazri-Register.apk`.

## Verification battery (runs on the signed APK once CI unblocks)
All v1.0.6 checks, with ground truth taken from AGP's own outputs
(mapping/seeds/usage from the CI build — never a hand-made list):
cert SHA-256 must equal `3f3a4aed…` + apksigner v2 + zipalign; vc8/1.0.7;
exactly 3 permissions; ComponentDiscoveryService ×1 with all 9 registrars;
InitializationProvider ×1 with 3 initializers; appComponentFactory present;
duplicate components 0; merged-manifest `"${"` placeholder scan = 0;
META-INF/services complete; okhttp defined; referenced-vs-defined (app
classes) 0 missing; findViewById ⊆ layout ids; strings 160/160/160
(default/en/ar); CNIC 0; 16 fonts present + parseable; **every
ContentProvider class in the merged manifest + its initializer classes
defined with key methods; every ComponentRegistrar defined with public
`<init>` AND `getComponents()`; and the mandatory new gate — every class
named in any binary XML of the final APK (expect ~47 named) defined in the
final dex, 0 missing, including the (Context, AttributeSet) constructors of
layout-named views.**

## Blocker (verbatim, 2026-10-27)
The prepared push of all 76 project files (2,654,804 bytes) to
`yousuf0313/Madrasa-Record @ main` (head `016c3c627afa…`, contents: only
`initial-commit.txt`; all project paths are new, no divergence) failed on
both connector write routes:

- push_files: `failed to create tree: POST https://api.github.com/repos/yousuf0313/Madrasa-Record/git/trees: 403 Resource not accessible by integration []`
- create_or_update_file (single-file probe): `failed to create/update file: PUT https://api.github.com/repos/yousuf0313/Madrasa-Record/contents/settings.gradle: 403 Resource not accessible by integration []`

Reads via the same connector work (repo contents, commits, Easy Chat
workflow). The Muse GitHub App installation therefore has read-only access
to this repository. **Exact missing piece: the installation must be granted
the Madrasa-Record repository with Contents read-and-write permission**
(GitHub → Settings → Applications → Muse → repository selection /
permissions). Per the connector rules no other auth route may be improvised
(gh CLI is not logged in; PATs/OAuth from chat are forbidden). Once access is
granted: re-run the snapshot push (manifest in /tmp/madrasa-paths.z +
BUILD-REPORT.md), the push triggers the workflow, download
`Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk` from the `v1.0.7-ci`
prerelease, zipalign + sign locally with
`~/workspace/madrasa-app/madrasa.keystore`, run the battery above, and
complete this report with run URL, size and sha256.
