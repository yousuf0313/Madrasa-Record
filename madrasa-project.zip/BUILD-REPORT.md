# BUILD-REPORT — v1.0.7 (Gradle/AGP migration)

Status at writing (2026-10-27 ~18:55 PKT): **project complete and prepared
locally; CI build BLOCKED on GitHub write access (see "Blocker").** Nothing
below claims a built APK yet — signing + verification run after the workflow
produces the unsigned artifact.

## Why this build exists
The hand-rolled manual pipeline (`~/workspace/madrasa-app/build-manual.sh`)
killed every shipped build: manifest-merge corruption (v1.0.0–1.0.2), the
six-tab Material crash (v1.0.4), and — proven by the 6-slice audit — v1.0.6's
standalone R8 config had **no layout-XML keep rules** (AGP auto-generates
them via aapt): 40 of 47 classes named in the APK's binary XML were shrunk
out of the dex, including AppCompat's sub-decor classes, so
`SplashActivity.setContentView` threw InflateException on the first screen
of every launch. This project rebuilds the same app with the standard
Gradle/AGP system (the one that ships Easy Chat) and makes that whole class
of bug structurally impossible.

## Project layout (`~/workspace/madrasa-app-gradle/`)
Standard Gradle project; the manual project in `~/workspace/madrasa-app/`
is untouched and remains the fallback until this build is phone-verified.

- `settings.gradle`, `build.gradle` — AGP **8.7.3** (plugins DSL), google() +
  mavenCentral()
- `gradle/wrapper/` — Gradle **8.9** wrapper. The wrapper jar was extracted
  from the genuine Gradle 8.9 distribution (the `wrapper` task itself cannot
  run in this VM — Gradle's daemon needs loopback sockets, which are broken
  here); gradlew/gradlew.bat are the standard 8.x scripts.
- `gradle.properties` — useAndroidX; `nonTransitiveRClass=false` to match the
  old merged-resources behaviour.
- `app/build.gradle` — namespace/applicationId `com.madrasarecord.app`,
  compileSdk/targetSdk **34**, minSdk **26**, **versionCode 8 /
  versionName 1.0.7**. Release: `minifyEnabled true`, `shrinkResources
  false`, default `proguard-android-optimize.txt` + `proguard-rules.pro`.
  **No signing config** — CI builds unsigned; signing happens locally with
  the existing keystore, as before.
- Dependencies — identical to the manual build's resolved set
  (`deps/resolution.json`): appcompat 1.7.0, recyclerview 1.3.2, material
  1.12.0, Firebase BoM **33.1.2** → firebase-auth 23.0.0,
  firebase-firestore 25.0.0, firebase-storage 21.0.0.
- **Firebase init unchanged, in code.** `MadrasaApp` builds `FirebaseOptions`
  from `FbConfig` constants in `onCreate`; `UsersActivity` creates its
  secondary app the same way. The `com.google.gms.google-services` plugin
  is deliberately **NOT** applied and no google-services.json is used — the
  FirebaseInitProvider phase behaves exactly as in the shipped app.
- `app/proguard-rules.pro` — on top of AGP's auto-merged AAR consumer rules
  and aapt-generated layout keeps:
  `-keep class com.madrasarecord.app.** { *; }`,
  `-keep class * implements com.google.firebase.components.ComponentRegistrar { public <init>(); }`,
  `-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod`.
- Source/resources/assets copied unchanged from the manual project (27 Java
  files, 3 locales, 16 fonts, DAHR branding, 6-item bottom_nav), except the
  two audit-prescribed changes below.
- Binary files (16 TTF fonts, 5 launcher PNGs, emblem WebP, wrapper jar)
  cannot travel the text-only GitHub push route, so they are committed as
  base64 parts under `bin-b64/` (same pattern as the Easy Chat repo) and the
  workflow restores them before building. Round-trip sha256 verified
  locally: `38edafdc24eac584397a25aa7b2ea4d3363364494da8ee0b6c9ad3a791b4096f`.
- `.github/workflows/build.yml` — on push to main / workflow_dispatch:
  checkout → JDK 17 (temurin) → restore binaries → `./gradlew
  assembleRelease` → upload unsigned-APK artifact + R8 outputs
  (mapping/usage/seeds/configuration) → attach the unsigned APK to a
  clearly-marked CI **prerelease** `v1.0.7-ci` (retrieval route for local
  signing, same pattern as Easy Chat's releases; official releases are
  published separately and existing tags/assets are untouched).

## Audit-prescribed changes applied in this project
1. **CrashNet hardening.** Handler now installed in
   `MadrasaApp.attachBaseContext` (earliest lifecycle point — a crash during
   `onCreate` is now recorded too). `SplashActivity` peeks the stored crash
   **before** `setContentView` and calls `CrashNet.clear()` only inside the
   dialog-dismissed callback, so a failure while showing the dialog can no
   longer discard the record. Rest of CrashNet behaviour unchanged.
   Compile smoke check: sources compile against the manual project's exact
   dependency jars (MadrasaApp verified in isolation; full compile of the
   R-referencing classes happens in CI — the local aapt2 harness cannot
   merge library resource tables the way AGP's merger does).
2. **Rename (user order).** «ڈیجیٹل آسان حاضری رجسٹر» everywhere visible:
   - `app_name` was already the brand in all locales — values (default/Urdu)
     `ڈیجیٹل آسان حاضری رجسٹر`, values-en `Digital Asan Hazri Register`,
     values-ar `ڈیجیٹل آسان حاضری رجسٹر` (same brand string, as on the
     logo). No change needed.
   - Full-project grep for "Madrasa Record"/"MadrasaRecord" display text:
     the only hits were two build-file comments (cleaned) and
     `rootProject.name = "MadrasaRecord"` in settings.gradle — an internal
     build identifier, kept deliberately like the package name
     `com.madrasarecord.app` and the repo name (never user-visible).
   - CI filenames aligned: the unsigned artifact is exported as
     `Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk`; the final signed
     deliverable will be `~/workspace/your_files/Digital-Asan-Hazri-Register.apk`.

## Verification battery (runs on the signed APK once CI unblocks)
All v1.0.6 checks, with ground truth taken from AGP's own outputs
(mapping/seeds/usage from the CI build — never a hand-made list):
cert SHA-256 must equal `3f3a4aed…` + apksigner v2 + zipalign; vc8/1.0.7;
exactly 3 permissions; ComponentDiscoveryService ×1 with all 9 registrars;
InitializationProvider ×1 with 3 initializers; appComponentFactory present;
duplicate components 0; merged-manifest `"${"` placeholder scan = 0;
META-INF/services complete; okhttp defined; referenced-vs-defined (app
classes) 0 missing; findViewById ⊆ layout ids; strings 160/160/160
(default/en/ar); CNIC 0; 16 fonts present + parseable; **every
ContentProvider class in the merged manifest + its initializer classes
defined with key methods; every ComponentRegistrar defined with public
`<init>` AND `getComponents()`; and the mandatory new gate — every class
named in any binary XML of the final APK (expect ~47 named) defined in the
final dex, 0 missing, including the (Context, AttributeSet) constructors of
layout-named views.**

## CI result + local signing + verification battery (2026-10-27, Run #4)

- Run #3 (40528527741) failed ONLY at `:app:minifyReleaseWithR8`:
  `app/proguard-rules.pro` used `//` comments (ProGuard files require `#`).
  Fixed in place (comments → `#`, rules unchanged); everything before the
  R8 step had compiled cleanly.
- **Run #4 (40529602769) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/40529602769
  Prerelease `v1.0.7-ci` carried the unsigned APK (5,444,385 bytes,
  sha256 d94e72433c091e3f44e501c2dc5814fcccbcbc138cfe95072293044a09be6df9).
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk`
  **Size: 5,535,410 bytes — sha256 a36c6908b3733a7438855750aab3b702248b73beaae7cf5bee89866b34cfbafa**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true**; cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 8 / versionName 1.0.7** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. The merged manifest carries 5 `uses-permission` elements —
  the 2 extra are standard AGP/library contributions, itemized:
  `com.google.android.providers.gsf.permission.READ_GSERVICES`
  (play-services-basement) and
  `com.madrasarecord.app.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`
  (auto-added by AGP/androidx). The hand-merged v1.0.6 manifest lacked both.
- **ComponentDiscoveryService ×1 with all 9 registrars** (auth, firestore
  ×2, storage ×2, appcheck ×2, firebase-common ×2) — every registrar
  DEFINED with **public `<init>()`** AND **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with `<init>` plus
  create-shaped `(Context)Object` and dependencies-shaped `()List`
  methods (method names obfuscated consistently by R8) ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; duplicate components = **0** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every interface and every listed implementation class is defined in the
  dex, and each implementation's superclass matches its service interface ✓
- App referenced-vs-defined: 119 referenced, **0 missing** ✓
- findViewById ⊆ layout ids: only non-layout id is `android.R.id.content`
  (framework) ✓
- Strings in the APK itself: **160/160/160** (default/en/ar — every app
  string name has a value in each locale) ✓
- CNIC occurrences in dex + resources: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 42 classes named in binary XML; 41/41 app+library classes
  DEFINED, 0 missing** (the one remaining name, `android.widget.Space`,
  is a framework class resolved from the Android boot classpath).
  Layout-named views lacking a (Context, AttributeSet) constructor: **0**
  — including every v1.0.6 casualty (FitWindowsLinearLayout,
  FitWindowsFrameLayout, ContentFrameLayout, ViewStubCompat,
  TextInputLayout, CheckableImageButton, BaselineLayout,
  FloatingActionButton, AlertDialogLayout) and
  `SixBottomNavigationView` with all 3 constructors ✓

### One check NOT verifiable at name level — "okhttp defined"
By its literal v1.0.6 form (`com.squareup.okhttp` / `okhttp3` classes under
those names): **not present**. AGP's R8 **obfuscated** the Firestore
transport stack (the manual pipeline's R8 did not obfuscate, which is why
v1.0.6 shows real names: io/grpc 331 + com/squareup 178 + firestore 216).
Evidence the stack is present-but-renamed, not removed:
- Total defined classes 5,174 vs v1.0.6's 5,064 — removal of the ~700-class
  grpc+okhttp+firestore stack is arithmetically incompatible with the
  totals; protobuf kept its names exactly (102 = 102).
- The dex string pool carries the full gRPC runtime message set
  ("Failed to find OkHttpChannelProvider", "fire/25.0.0 grpc/",
  io.grpc.* provider literals).
- META-INF/services consistency (above): provider interfaces and
  implementations line up under their renamed names, superclass-verified.
- Name-level certainty would require `mapping.txt`, which this CI run
  uploaded as a workflow **artifact** (`r8-outputs`); artifact download
  needs an authenticated route not available to the verification agent
  (the GitHub MCP toolset exposes no Actions-artifact tool). Runtime
  confirmation therefore rests with the standing final gate: the phone
  test (sign-in + Firestore data load).

## Blocker (verbatim, 2026-10-27)
The prepared push of all 76 project files (2,654,804 bytes) to
`yousuf0313/Madrasa-Record @ main` (head `016c3c627afa…`, contents: only
`initial-commit.txt`; all project paths are new, no divergence) failed on
both connector write routes:

- push_files: `failed to create tree: POST https://api.github.com/repos/yousuf0313/Madrasa-Record/git/trees: 403 Resource not accessible by integration []`
- create_or_update_file (single-file probe): `failed to create/update file: PUT https://api.github.com/repos/yousuf0313/Madrasa-Record/contents/settings.gradle: 403 Resource not accessible by integration []`

Reads via the same connector work (repo contents, commits, Easy Chat
workflow). The Muse GitHub App installation therefore has read-only access
to this repository. **Exact missing piece: the installation must be granted
the Madrasa-Record repository with Contents read-and-write permission**
(GitHub → Settings → Applications → Muse → repository selection /
permissions). Per the connector rules no other auth route may be improvised
(gh CLI is not logged in; PATs/OAuth from chat are forbidden). Once access is
granted: re-run the snapshot push (manifest in /tmp/madrasa-paths.z +
BUILD-REPORT.md), the push triggers the workflow, download
`Digital-Asan-Hazri-Register-v1.0.7-unsigned.apk` from the `v1.0.7-ci`
prerelease, zipalign + sign locally with
`~/workspace/madrasa-app/madrasa.keystore`, run the battery above, and
complete this report with run URL, size and sha256.

---

# v1.0.8 (2026-10-28) — fragment-overlap fix + preview-faithful restyle

Status at writing: **sources + upload zip prepared locally; CI build is
GATED on the owner's explicit approval** (he reviews the preview first).
Nothing below claims a built APK.

## 1. Fragment-overlap bug — fixed (MainActivity rewritten)

Phone evidence (v1.0.7 screen recording): the app ran (login, tabs, data
all fine) but views of MULTIPLE fragments were visible simultaneously —
Settings' "Sign out"/"Check update" buttons and About text ghosted over
the Home, Attendance and Report screens.

Root cause: the old `MainActivity` kept a `Map<Integer, Fragment>` of
FRESH instances and switched with `add()` + `hide()`/`show()`, tracking
an `active` field. On activity recreation (rotation, process death, the
language/font pickers' `recreate()`), the FragmentManager restored the
previous fragments into `R.id.fragmentContainer`, but the map held new
instances and `active == null` — restored screens were never hidden and
stayed visible under everything, permanently.

Fix (`MainActivity.java`, only file with logic changes besides the two
noted below):
- `onCreate`: first removes EVERY fragment the FragmentManager already
  holds in `R.id.fragmentContainer` (restored orphans, single
  `commitNow()`), then installs a fresh `HomeFragment` via `replace()`.
- `switchTo(id)`: `replace()` with a new instance of the target class;
  `currentId`/`active` updated before commit. Exactly one fragment can
  exist in the container, so overlap is structurally impossible.
- The bottom nav gets `android:saveEnabled="false"` so its checked item
  cannot be restored out of sync with the always-Home recreation state.
- Preserved: header username (`headerUser`), the `UpdateCheck.check`
  call (fresh-create only), all 6 tabs through `SixBottomNavigationView`,
  and the post-switch `applyFontsSoon()` pass.

## 2. Version label — fixed

Settings hardcoded the version through `version_lbl` strings ("ورژن
1.0.6" in a 1.0.7 build). Now: the three `version_lbl` strings carry
only the label word (ورژن / Version / الإصدار), `fragment_settings.xml`
gives the TextView `android:id="@+id/versionTv"`, and
`SettingsFragment` sets `version_lbl + " " + BuildConfig.VERSION_NAME`.
`app/build.gradle`: `buildFeatures.buildConfig true`, **versionCode 9 /
versionName 1.0.8**.

## 3. Design spec extracted from the approved preview (space-7)

Source: `client/src/theme.css` + `client/src/App.tsx` (light theme; the
native app has a single light theme, so the preview's dark variant is
not mirrored).

Palette: page bg `#F6F1E3` (cream) · surface `#FFFDF4` · surface-alt
`#EFE8D2` · text `#1D2A1E` · dim `#6D7263` · border `#DDD2B4` · green
`#14532D` · green-deep `#0D3B21` · green-soft `#E3EFDD` · gold `#B8860B`
· gold-bright `#D9A92C` · gold-soft `#F3E5BD` · header sub-text
`#CFE3C8` · red `#B3352B` / red-soft `#F9E3E0` · amber `#9A6A00` /
amber-soft `#F7ECC9`.

Geometry/type: card radius 16dp, padding 16dp, 1dp sand border; inputs
radius 8dp, surface fill, sand border; buttons radius 12dp, min-height
48dp, bold; screen titles 18sp bold ink; card titles 16sp bold ink;
field labels 14sp bold ink; content inset 12dp.

Components:
- **Banner header**: floating card (12dp side inset, 8dp top), green
  gradient `#14532D → #0D3B21`, 2dp gold border, 16dp radius; DAHR mark
  46dp; name 19sp bold `#F3E5BD`; sub-line 12sp `#CFE3C8`; 3dp gold
  gradient rule (transparent → `#D9A92C` → transparent) inside the card.
- **RefCard** (ayah/hadith): gold 14sp bold title above a surface card;
  Arabic 18sp, line-spacing ~1.8; translation 16sp ink; reference 14sp dim.
- **Register table**: 2dp green frame, 12dp radius; header row green-soft
  with green-deep bold 13sp labels (admission over a green rule over DOB
  in one cell); cells ruled 1.5dp green; columns 9/23/14/28/13/13 %;
  rows alternate page-cream / surface; serial 16sp bold centred; dates
  13sp; reg-no 13sp centred; student cell = 30dp round avatar + name
  15sp bold + "sonOf father" 12sp dim; completion/duration 13sp centred.
- **Attendance**: rows on surface cards; status chips — unselected: soft
  tint bg + coloured bold text; selected: solid status colour + white
  text + "✓ " prefix; totals strip green-soft.
- **Selector chips** (level, language): radius 8dp; selected: green
  border + green-soft fill + green text; unselected: sand border +
  surface fill + ink text.
- **Auth**: centred DAHR mark 72dp, title 24sp bold green, brand line
  gold bold, then the form inside a surface card.
- **Bottom nav: all 6 labels always visible, as preview** — see §4.
- Settings/report: stacked surface cards with 16sp bold ink titles;
  logout = red-outline button on surface.

## 4. Bottom navigation (owner requirement, explicit)

`app:labelVisibilityMode="labeled"` on `SixBottomNavigationView` — the
icon **and** text label show under **every one of the 6 items, always**
(Material's default selected-only label behaviour, visible in the
owner's v1.0.7 recording, is gone). Surface background with a 1dp sand
rule above the bar; active item deep green / inactive dim
(`@color/nav_colors`); icon size 22dp; labels 11sp bold
(`NavLabelActive`/`NavLabelInactive`) so six icon+label items fit
cleanly on one bar. The preview's bar is labels-only with a gold top
segment on the active tab; the native bar keeps the app's existing six
icons (owner's wording: label under every icon) and takes its colours
from the preview.

## 5. Screen-by-screen mapping (preview → native)

- **App header** (`activity_main`): flat green bar → the banner card
  (§3); big line = app name, sub-line = signed-in user (native header
  content; the preview's card carries madrasa name + app name, which is
  exactly what `layout_madrasa_header` now shows in fragments).
- **Madrasa banner** (`layout_madrasa_header`, Home + Report): centred
  62dp emblem + centred name + full-width gold bar → banner card with
  46dp mark at the start, name 19sp gold-soft (Katibeh kept via
  `keepFont` + `Ui.headerTypeface`), app name beneath, gold gradient
  rule inside.
- **Home**: white blocks → RefCards for the daily ayah/hadith (gold
  title + surface card); the today-summary block → one surface card
  (native combines the preview's 3 stat cards and the two session
  cards into this single totals/session card — same data, native
  arrangement kept); session buttons → preview outline buttons.
- **Students (register)**: card-per-row list → the preview's paper-
  register **table**: green frame + header row (labels moved into the
  header; the in-cell "label:" prefixes were dropped in
  `StudentsFragment` binding) + ruled alternating rows; search →
  preview input; empty state → surface card; FAB retinted deep green
  (preview's add action is a header button + the home CTA; the native
  FAB is kept as the same action, recoloured).
- **Attendance hub**: section labels → two preview session cards
  (heading + status + primary button); date button → outline (input-
  like); weekly button → outline.
- **Attendance register** (`activity_register` + `item_register_row`):
  flat green header → banner card; "mark all" → primary button
  (preview); rows → surface cards with preview attendance-row layout;
  P/A/L buttons → preview status chips (§3, via `styleToggle` in
  `AttendanceRegisterActivity`); footer → green-soft totals strip.
- **Report**: sections → preview cards (morning, evening, absent-today,
  weekly summary); banner card included as on Home.
- **Ayat/Hadith library**: rows → RefCards with the preview's gold-soft
  kind chip (rounded), 18sp Arabic, ink translation, dim reference.
- **Settings**: loose sections → preview cards: account+language
  (language radios → selector chips), font (preview input + outline
  picker), madrasa name (card, teacher), users (card, teacher), update
  check (primary), about (card; version now real, §2), sign-out →
  preview's red-outline logout button.
- **Login/Setup** (`activity_auth`): → preview AuthShell composition:
  72dp mark, 24sp green title, gold bold brand line, form in a surface
  card; inputs keep Material outlined boxes, restyled to surface fill +
  8dp corners + green stroke (`MadrasaInput`).
- **Student form**: photo 110dp square → 80dp rounded frame (preview);
  photo pickers → outline buttons; class radios → selector chips
  (preview's level chips); field-group labels → preview field labels;
  date buttons → outline (input-like); "add number" → green text button
  (preview); save → primary. Inputs keep their floating-hint
  TextInputLayouts (see deviations).
- **Student detail**: photo → 110dp round avatar; body/mobiles/month/
  history blocks → surface cards with card titles; edit → primary,
  delete → solid red (preview).
- **Users**: rows → surface cards; role → gold-soft chip; delete →
  flat red-text button.
- **Weekly grid**: header → banner card; session buttons → outline
  pair; grid sits on a surface card; legend → green-soft strip (cells
  are built in code and inherit the re-pointed palette).
- **Splash / Not-authorized**: splash already matches (deep-green
  `#0D3B21` + gold-soft name); not-authorized content moved onto a
  surface card.

### Where exact mirroring was not possible (and why)
- **DAHR emblem corners/shadow**: the preview rounds the mark (12px)
  and shadows it; the native emblem is a WebP bitmap and the project
  has no CardView dependency, so the mark stays square in the banner.
  Colours/placement/sizes match.
- **Banner gradient angle**: CSS 150deg ≈ the drawable's 315deg
  two-stop green gradient (XML gradients are 45°-quantised); visually
  the same deep-green blend.
- **Preview's gold top segment on the active nav tab** is a CSS
  border trick with no BottomNavigationView equivalent; the bar takes
  the preview's surface bg, sand top rule and green/dim states instead.
- **Form inputs**: the preview uses label-above plain inputs; the
  native form keeps Material TextInputLayouts with floating hints
  (the existing Java binds `TextInputEditText` ids — swapping widget
  types would be a logic change, out of scope for a restyle). Boxes
  are restyled to the preview's surface/8dp/green-stroke look.
- **Register completion-label line**: the preview shows a completion
  label under the completion date; the native data model
  (`Db.Student`) has no completion-label field, so there is nothing
  to bind — the cell shows the date only, as before.
- **Preview home stat trio + view-only note**: native Home has no
  view-only banner element and combines stats into its summary card
  (see Home above); no elements were added or removed in this round.
- **Weekly grid internals**: cells are generated in code (no layout);
  they inherit the new palette via `R.color` but keep their existing
  padding/structure.
- **Dark theme**: the preview ships a dark variant; the app has a
  single light theme (as in v1.0.0–1.0.7) — out of scope.

## 6. Invariants kept

English digits only (no digit strings touched; the new `son_of` string
has no digits); strings 161/161/161 across values/values-en/values-ar
(one addition, `son_of` — ولد / s/o / بن, taken from the preview's own
i18n — needed to mirror the register's father line; label-only change
to `version_lbl` in all three); no CNIC anywhere; manual Firebase init
unchanged (no google-services plugin); `proguard-rules.pro` untouched
(`#` comments verified, zero `//` lines); wrapper jar untouched;
`minifyEnabled true`; package/keystore untouched.

## 7. Changed files

Java: `MainActivity.java` (rewritten switching), `SettingsFragment.java`
(version from BuildConfig), `StudentsFragment.java` (table-cell binding,
row alternation/divider), `AttendanceRegisterActivity.java`
(`styleToggle` → preview chips). Gradle: `app/build.gradle` (vc9/1.0.8,
buildConfig). Resources: `values/colors.xml` (palette re-pointed +
preview tokens added), `values/themes.xml` (preview button/input/title
styles + NavLabel appearances), strings ×3 (`version_lbl`, `son_of`),
`color/nav_colors.xml` (unchanged — inherits new palette),
`color/chip_text.xml` (new), drawables (new: `bg_card`, `bg_banner`,
`bg_gold_rule`, `bg_table`, `bg_table_header`, `bg_avatar`,
`bg_chip_gold`, `bg_input`, `bg_photo`, `bg_chip`), layouts (rewritten:
`activity_main`, `layout_madrasa_header`, `fragment_home`,
`fragment_students`, `item_student_row`, `fragment_attendance`,
`activity_register`, `item_register_row`, `fragment_report`,
`fragment_ayat`, `item_ayah`, `fragment_settings`, `activity_auth`,
`activity_student_detail`, `activity_student_edit`, `activity_users`,
`item_user_row`, `item_mobile_row`, `activity_weekly`,
`activity_not_authorized`).

## 8. Self-checks (local, pre-CI)

- All 48 res XML files parse (ElementTree); 0 malformed.
- All 137 `R.id.*` references in Java resolve to layout/menu ids.
- All `@color`/`@drawable`/`@style` references in layouts/values
  resolve; string sets identical across the 3 locales (161 each) and
  every `@string`/`R.string` reference resolves in every locale.
- Grep: no `1.0.6` remains in res/, java/ or gradle files (the visible
  version now comes only from BuildConfig); `app/build.gradle` inside
  the zip carries versionCode 9 / versionName 1.0.8.
- `app/proguard-rules.pro`: 0 lines starting with `//`.

---

## v1.0.8 — CI result + local signing + verification battery (2026-10-28, Run #6)

- **Run #6 (40610461859) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/40610461859
  (commit da0e84f, "v1.0.8: preview-matched redesign + fragment fix"; an
  earlier Run #5 was cancelled before completing and is ignored.)
  Prerelease `v1.0.8-ci` carried the unsigned APK (5,454,483 bytes,
  sha256 05e6fc5f54b60f7f59b5c5f91ba003e08e84d23b05a51d5f7ea0bc7d2f3a18eb).
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk` (overwrites v1.0.7)
  **Size: 5,548,328 bytes — sha256 f08a97c06ecc33b41f3aa12f62fcdb67942fc63e7435d4e560c5305aaf2f7805**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true**; cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 9 / versionName 1.0.8** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. Merged manifest again carries the same 2 standard
  AGP/library entries as v1.0.7 (READ_GSERVICES,
  DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION).
- **ComponentDiscoveryService ×1 with all 9 registrars** (same set as
  v1.0.7) — every registrar DEFINED with **public `<init>()V`** AND
  **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with public
  `<init>` plus create-shaped `(Context)Object` and dependencies-shaped
  `()List` methods ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; duplicate components = **0** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every listed implementation class is defined in the dex and reaches
  its service interface through the superclass/interface chain ✓
- **grpc/okhttp stack present (renamed, as v1.0.7)**: total defined
  classes 5,175 (v1.0.7: 5,174); protobuf kept its names exactly
  (102 = 102); the dex string pool carries the OkHttpChannelProvider
  runtime messages ✓
- App referenced-vs-defined: 120 referenced, **0 missing** ✓
- findViewById ⊆ layout ids: 126 ids, all present; the only
  non-layout id is `android.R.id.content` (framework) ✓
- Strings in the APK itself: **161/161/161** — every one of the 161
  source string names is present in the default, en and ar configs ✓
- CNIC occurrences in dex strings + resources: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 42 classes named in binary XML; 42/42 app+library
  classes DEFINED, 0 missing** (the one remaining name,
  `android.widget.Space`, is a framework class resolved from the
  Android boot classpath). Layout-named views lacking a
  (Context, AttributeSet) constructor: **0** — including
  `SixBottomNavigationView` with all 3 constructors ✓

### v1.0.8-specific checks
- **Bottom-nav labels**: the compiled `activity_main` layout (res/v9.xml
  in the APK) carries `app:labelVisibilityMode=1` on
  `SixBottomNavigationView` — 1 is Material's
  `LABEL_VISIBILITY_LABELED` (0=unlabeled, 1=labeled, 2=selected), so
  all 6 tab labels are always visible in the built APK, as the preview ✓
- **No hardcoded "1.0.6"**: 0 occurrences in the dex string pool and 0
  in the APK's resources ✓
- **Settings version is BuildConfig-driven**: the APK's `version_lbl`
  string is the label word only (ورژن / "Version" / الإصدار) in all 3
  locales — no version number is baked into resources; Settings appends
  `BuildConfig.VERSION_NAME` ✓

---

# v1.0.9 (2026-10-28) — chips fix + 3D pulled-back sheet + tightened register + Back→Home

Status at writing: **sources + upload zip prepared locally; CI build gated
on the parent agent's normal flow.** Nothing below claims a built APK.
The owner phone-tested v1.0.8 (design matched the preview, bottom labels
good) and approved these five items after reviewing them in the updated
preview (space-7); the preview's CURRENT `theme.css`/`App.tsx` values
are the spec.

## 1. Attendance chips clipping — fixed (item_register_row rewritten)

v1.0.8 put serial + photo + name block + all three chips on ONE
horizontal line; on a 360dp screen each chip was squeezed to ~55dp and
the owner's recording shows «غیر حاضر» losing its last letter and
«چھٹی» rendering as «چھٹ». The preview's fix, mirrored exactly: the
identity block (serial, avatar, name/father/dates) sits on top and the
chips get their OWN full-width row beneath it (`layout_marginTop 10dp`).
Chips: three equal `weight 1` buttons, height **52dp** (preview
min-height 44 + line-height 2 → generous native line room),
`app:insetTop/insetBottom 0dp` (Material's default 6dp insets no longer
eat the line box), `cornerRadius 8dp` (preview rounded-lg),
`singleLine`, 14sp bold, horizontal padding 4dp — at 360dp each chip is
~92dp wide, ~78dp even at 320dp, so حاضر / غیر حاضر / چھٹی and the
en/ar equivalents render whole in every bundled font. `styleToggle`
unchanged (tints + "✓ " prefix). `regDates` lost its
singleLine/ellipsize (now `maxLines 2` — it was truncating mid-word in
the squeezed block; with the full-width block it fits or wraps).

## 2. 3D pulled-back card look (preview sheet/card system)

Preview values: backdrop `linear-gradient(160deg, #175C33, #0D3B21
55%, #082A17)`; sheet = calc(100%−16px) wide, margin-y 8px, radius
26px, 1px gold border, deep cast shadow + lit top edge; cards carry
`--card-shadow` (soft drop + inset top highlight); bottom nav = fixed
card, bottom 12px, width calc(100%−28px), radius 20px, gold border.

Native mapping:
- NEW `bg_backdrop.xml` (3-stop green gradient, angle 270 — XML is
  45°-quantised, 160° becomes straight top-to-bottom) set as the theme
  `windowBackground`, so the backdrop frames every sheet and shows
  during transitions.
- NEW `bg_sheet.xml` (cream gradient face, 1dp gold stroke, 26dp
  radius). Every screen root is now the sheet: `layout_margin 8dp` +
  `bg_sheet` + `elevation 12dp` (the cast shadow; Android elevation
  shadows are neutral grey — the CSS shadow's green tint has no
  pre-API-33 equivalent). Applied to `activity_main`'s content column
  and the roots of auth, register, student detail, student edit,
  users, weekly, not-authorized. Fragments ride inside MainActivity's
  sheet unchanged.
- Inner cards: `bg_card` face is now a lit-top gradient
  (surface → `#FAF5E7`) and **every** `bg_card` use site (25) gained
  `android:elevation="6dp"`; the register table frame gained 6dp too;
  banner cards (`bg_banner`, 4 sites) gained 4dp.
- Bottom nav: floating card — sibling of the sheet in a FrameLayout,
  `layout_gravity bottom`, margins 14/14/12dp, NEW `bg_nav.xml`
  (surface, 1dp gold stroke, 20dp radius), `elevation 8dp`. All 6
  labels stay always visible (`labelVisibilityMode="labeled"`,
  unchanged). The fragment container got `paddingBottom 68dp` +
  `clipToPadding false` so scrolled content can never slide under the
  floating bar (preview equivalent: main's pb-32).

Applied consistently: Home, Students, Attendance hub, register
activity, Report, Ayat, Settings, auth, student form/detail, users,
weekly, not-authorized. Splash untouched (it is the brand screen; the
preview's own splash equivalent is the bare backdrop).

## 3. Register table tightened (preview's latest values)

Preview: `.reg-table` cell padding 7px→**3px**, line-height 1.8→**1.55**;
admission/DOB header divider mt-0.5/pt-0.5; delete-button spacing
reduced (no native delete button exists inside register rows — delete
lives on the detail screen/long-press menu, so that sub-item has no
native counterpart).
Native: header row `paddingVertical 6dp→3dp`; header DOB divider
`marginVertical 3dp→1dp`; row cells `paddingVertical 5dp→3dp`
(admission cell + student cell); row DOB divider margins `3dp→1dp`;
explicit `android:lineHeight` at 1.55× on every cell text (13sp→20dp,
15sp→23dp, 16sp→25dp, 12sp→19dp) in both the header (7 labels) and the
row (9 fields) — compact like the paper register while staying at the
preview's glyph-safe floor.

## 4. Back → Home (MainActivity)

`OnBackPressedDispatcher` callback registered in `onCreate`: if
`currentId != R.id.navHome`, Back selects Home in the bottom bar (the
existing listener performs the replace() switch and checks the item);
on Home the callback disables itself and re-dispatches, so Back exits
normally. Secondary activities (register, student detail/edit, users,
weekly) keep their normal Back-to-caller behaviour, as specified.

## 5. Font-clipping audit (all layouts swept)

Sweep method: every layout searched for `singleLine`/`ellipsize`,
fixed small heights, and multi-line Urdu text without line spacing.
Changed:
- Chips (item 1) — the proven clip site: full-width row, 52dp,
  insets zeroed.
- `regDates`: singleLine/ellipsize removed → wraps to 2 lines.
- Line spacing added where Urdu body text wraps: Home ayah/hadith
  translations `lineSpacingMultiplier 1.6`, their references `1.5`
  (Arabic already 1.8 from v1.0.8); Ayat list translation `1.6`,
  reference `1.5`; Settings about text `1.7`; not-authorized
  description `1.6`. (Student-detail body already carried 1.5 from
  v1.0.8 — left as is.)
- Ayat kind chip: vertical padding 4dp→6dp (12sp label room).
Checked, adequate, unchanged: selector chips (language/level —
wrap_content + 10dp vertical padding, they grow with the font);
Material buttons (`MadrasaButton` family, minHeight 48dp at 15–16sp);
search EditText (12dp padding, input-managed line box); bottom-nav
labels (owner-verified good on the phone in v1.0.8); register table
(name/father/dates cells keep singleLine+ellipsize BY DESIGN — the
table's fixed columns must not wrap; these truncate with an ellipsis
rather than cutting glyphs, and §3 gave their lines the preview's
1.55 height); `headerUser` single line in the banner (name slot, by
design). Code-built dialog texts have no layout to audit.

## 6. Version

`app/build.gradle`: **versionCode 10 / versionName "1.0.9"** (Settings
keeps reading BuildConfig, so the label follows automatically).

## Invariants kept

Manual Firebase init, no google-services plugin; `proguard-rules.pro`
byte-untouched (mtime 2026-10-27, `#` comments, 0 `//` lines — verified
again after a checker caught `--` sequences inside XML *comments* in
three new resource files, which were reworded: XML comments cannot
contain `--`); wrapper jar untouched (mtime 2026-10-27); minifyEnabled
true; strings 161/161/161 identical key sets, NO new strings this
round; no CNIC; English digits only; SixBottomNavigationView +
labeled mode; replace()-based switching from v1.0.8 intact.

## Changed files (26)

Java: `MainActivity.java` (Back→Home callback). Gradle:
`app/build.gradle` (vc10/1.0.9). Resources: `values/colors.xml`
(+backdrop_start/backdrop_end/card_bottom), `values/themes.xml`
(windowBackground → bg_backdrop), drawables NEW `bg_backdrop.xml`,
`bg_sheet.xml`, `bg_nav.xml`; REWRITTEN `bg_card.xml` (lit-top
gradient); layouts: `activity_main.xml` (sheet + floating nav),
`item_register_row.xml` (chip row), `item_student_row.xml` +
`fragment_students.xml` (table tightening; students also got the table
frame elevation), `fragment_home.xml`, `item_ayah.xml`,
`fragment_settings.xml`, `activity_not_authorized.xml` (audit line
spacing), sheet roots + card/banner elevations across
`activity_auth.xml`, `activity_register.xml`,
`activity_student_detail.xml`, `activity_student_edit.xml`,
`activity_users.xml`, `activity_weekly.xml`,
`fragment_attendance.xml`, `fragment_report.xml`,
`item_user_row.xml`, `layout_madrasa_header.xml`.

## Self-checks (local, pre-CI)

- All 52 res XML files parse (ElementTree); 0 malformed.
- Every `@color/@drawable/@style/@string/@layout/@menu` reference in
  layouts resolves (the only checker "misses" are `chip_text` /
  `nav_colors`, which live in `res/color/` as selector resources —
  present, as in v1.0.8).
- All `R.id/R.color/R.string/R.layout` references in Java resolve
  (framework exceptions only: `android.R.id.content`,
  `android.R.layout.simple_spinner_dropdown_item` — same as v1.0.8).
- String key sets identical across the 3 locales (161/161/161).
- Inside the zip: versionCode 10 / versionName "1.0.9"; chip row is
  full-width with 52dp weight-1 chips; `OnBackPressedCallback`
  present in MainActivity; activity_main carries bg_sheet + bg_nav +
  labeled nav + bg_backdrop; proguard 0 `//` lines; wrapper jar
  present.
- Upload zip: `~/workspace/your_files/madrasa-project.zip` — 137
  entries (134 + 3 new drawables), **1,927,876 bytes, sha256
  5b96244aa46ca3444a483c0bfbd177243216436d1b0e11c0b7a59d8d32692761**
  (bin-b64/ and .github/ excluded, same recipe as v1.0.8).

**Run #8 failure + fix (2026-10-28):** AAPT linking failed — item_register_row.xml used Material-only attrs (app:insetTop/insetBottom) on plain <Button> tags (declared-class styleable lacks them even though the Material theme substitutes MaterialButton at runtime). Fix: the three chips are now declared as com.google.android.material.button.MaterialButton (attrs legal; Holder/styleToggle use Button supertype, unchanged). Zip rebuilt 1,931,431 bytes, sha256 9c0915733e252821bf548af796088def55611a641f52b9d5a3e06e26ad48ca61; zip-only re-upload triggers the next run with the existing v1.0.9 workflow.

**Run #9 failure + corrected fix (2026-10-28):** Run #9 failed with the IDENTICAL six AAPT errors — app:insetTop/insetBottom are not declared attributes in Material 1.12.0 at all (the MaterialButton tag change alone could not help). The inset-zeroing was speculative (the v1.0.8 clipping was horizontal width squeeze, already remedied by the full-width row + 52dp height + minWidth 0). Corrected fix: both inset attributes REMOVED from item_register_row.xml (verified app:inset count 0 in source and inside the zip); MaterialButton tags + cornerRadius kept (cornerRadius links cleanly). Zip rebuilt, sha256 c98984686535a8092ba0052af64830831af5668d0e94662402b93e4d7b4fede1.

---

## v1.0.9 — CI result + local signing + verification battery (2026-10-28, Run #10)

- **Run #10 (40632155296) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/40632155296
  (commit c25b289 — the Run #9 fix with both undeclared `app:inset*`
  attributes removed; Run #7 was cancelled and Runs #8/#9 failed on
  that AAPT issue, as recorded above.)
  Prerelease `v1.0.9-ci` carried the unsigned APK (5,457,127 bytes,
  sha256 487319a55f01b2179b8907a350969c0eb19b25c94a4e8d102695c5a0738265cc).
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk` (overwrites v1.0.8)
  **Size: 5,548,496 bytes — sha256 b847968ee837633ecce5e724ed49213d777fa754d4d636d0d6e3afb37081dadc**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true** (v3 also true); cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 10 / versionName 1.0.9** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. Merged manifest again carries the same 2 standard
  AGP/library entries as v1.0.7/v1.0.8 (READ_GSERVICES,
  DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION).
- **ComponentDiscoveryService ×1 with all 9 registrars** (same set as
  v1.0.7/v1.0.8) — every registrar DEFINED with **public `<init>()V`**
  AND **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with public
  `<init>` plus create-shaped `(Context)Object` and dependencies-shaped
  `()List` methods ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; manifest components
  17, duplicate names = **0** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every listed implementation class is defined in the dex and reaches
  its service interface through the superclass/interface chain
  (implementations carry R8-renamed names, as before) ✓
- **grpc/okhttp stack present (renamed, as v1.0.7/v1.0.8)**: total
  defined classes **5,177** (v1.0.8: 5,175); protobuf kept its names
  exactly (**102 = 102**); the dex string pool carries the
  OkHttpChannelProvider runtime messages ("Failed to find
  OkHttpChannelProvider", "Failed to construct OkHttpChannelProvider",
  …) and 20 `io.grpc` literals ✓
- App referenced-vs-defined: bytecode-level scan of all 121 defined
  app classes (hierarchy + method protos + instruction type/field/
  method references) found 341 distinct referenced class types,
  **0 missing** outside the framework (a broader net than the earlier
  rounds' source-level count; the gate — zero missing — holds) ✓
- findViewById ⊆ layout ids: 137 `R.id` references in Java vs 138 ids
  defined in layouts/menus; the only non-layout id is
  `android.R.id.content` (framework) ✓
- Strings in the APK itself: **161/161/161** — every one of the 161
  source string names is present in the default, en and ar configs ✓
- CNIC occurrences in dex strings + resource values: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 42 classes named in binary XML; 41/41 app+library
  classes DEFINED, 0 missing** (the one remaining name,
  `android.widget.Space`, is a framework class resolved from the
  Android boot classpath). Layout-named views lacking a
  (Context, AttributeSet) constructor: **0** ✓

### v1.0.9-specific checks
- **Bottom-nav labels**: the compiled `activity_main` layout
  (res/v9.xml in the APK) carries `app:labelVisibilityMode=0x1`
  (`LABEL_VISIBILITY_LABELED`) on `SixBottomNavigationView` — all 6
  labels always visible; the bar is the floating card (margins
  14/14/12dp, elevation 8dp) ✓
- **Attendance chips**: the compiled `item_register_row` layout
  (res/Ho.xml) has the identity block on top and its own full-width
  row beneath holding exactly **3
  `com.google.android.material.button.MaterialButton`** chips
  (source lines 39/44/49) ✓
- **No `app:inset*` attributes**: `app:insetTop`/`app:insetBottom`
  occurrences across **all** compiled XML in the APK = **0** (the 28
  `android:insetTop/Bottom` hits are framework attributes inside
  library resources, not app-namespace attributes) ✓
- **No stale hardcoded version numbers**: app string values containing
  1.0.6/1.0.7/1.0.8 = **0** in resources; exact dex strings
  "1.0.6"/"1.0.7"/"1.0.8" = **0**; `version_lbl` is the label word only
  (ورژن / "Version" / الإصدار) in all 3 configs, and "1.0.9" occurs
  exactly once in the dex — `BuildConfig.VERSION_NAME`, which Settings
  displays ✓
- **Back→Home compiled in**: `MainActivity$1` (the registered
  callback) extends the R8-renamed OnBackPressedCallback
  (`Landroidx/activity/n;`) and retains its `handleOnBackPressed`
  method in the dex ✓

No check failed. Runtime confirmation rests with the standing final
gate: the owner's phone test.

---

## v1.0.10 — code phase (fix round for the v1.0.9 on-device death + invisible nav + session layout)

Owner's phone on v1.0.9: app dies seconds after every launch, no Java
exception recorded (CrashNet empty), live Firestore data verified clean.
Strategy (parent-directed): keep the approved v1.0.9 LOOK, render it the
v1.0.8 way — flat drawables, no giant elevation shadows. versionCode 11 /
versionName "1.0.10" (app/build.gradle).

### 1. Bottom nav (proven fix)
- `activity_main.xml`: the sheet `LinearLayout` carried
  `android:elevation="12dp"` and drew OVER the `SixBottomNavigationView`
  (8dp) — the bar was covered and untouchable. Sheet elevation REMOVED
  (0); nav keeps 8dp + bg_nav + 14/14/12dp margins, so it now renders
  above the sheet.

### 2. Sheet/cards without the elevation stack
- Sheet elevation removed from every bg_sheet root: activity_main,
  activity_register, activity_users, activity_student_edit,
  activity_student_detail, activity_weekly, activity_auth,
  activity_not_authorized. bg_sheet itself unchanged (8dp inset, 26dp
  radius, gold stroke, cream gradient — the look stays).
- Every bg_card use site: elevation 6dp → 3dp (v1.0.8-proven range),
  incl. the item_register_row root whose attributes span two lines.
- themes.xml: `android:windowBackground` reverted from
  `@drawable/bg_backdrop` to flat `@color/cream`. bg_backdrop.xml
  DELETED (0 references remain). activity_main root background is now
  flat `@color/green_deep` (#0D3B21 — the project's existing deep-green
  token; no `deep_green` name exists) so the green frame around the
  sheet is kept without a gradient window background.
- Remaining elevations > 3dp (deliberately untouched — none is a sheet
  root or a bg_card): the bg_banner header bars at 4dp (activity_main,
  activity_register, activity_weekly, layout_madrasa_header — the
  v1.0.8-era header treatment) and the students table container
  (bg_table) at 6dp inside fragment_students. Sanctioned exception:
  the bottom nav at 8dp.

### 3. Attendance sessions compact at the top (owner's words)
- `fragment_attendance.xml`: the two large stacked full-width session
  cards are replaced by ONE horizontal row directly under the date
  selector holding two compact side-by-side cards (weight 1 each, 8dp
  gap, 12dp padding, bg_card @ 3dp), each with session title + status
  + its button. All ids preserved (dateBtn, morningStatus,
  eveningStatus, morningBtn, eveningBtn, weeklyBtn); AttendanceFragment
  Java untouched; weeklyBtn stays below the row. No new strings —
  reuses morning/evening/mark_attendance.
- Home NOT mirrored: fragment_home has no stacked session-card pair —
  its sessions live as two labelled sections inside ONE combined
  summary card, so the pattern the owner objected to does not exist
  there; left alone per the brief's condition.

### 4. Data-read hardening (zero behavior change, insurance)
- `Db.loadMadrasaName`: unguarded `doc.getString("madrasaName")`
  replaced with a get()+instanceof read (SplashActivity.strField
  pattern).
- `Db.Student(DocumentSnapshot)`: all String fields now read via a new
  `str(Object)` instanceof helper (name, fatherName, bform, classGroup,
  admissionDate, notes, photoUrl — photoUrl was previously a raw
  getString — registrationNumber, dateOfBirth, completionDate,
  ageManual), so a non-String stored value yields "" instead of a
  ClassCastException. `createdAt` read via instanceof Timestamp
  (non-Timestamp → 0) instead of getTimestamp.
- The six unchecked `(Map) doc.get("marks")` casts are now
  instanceof-guarded (non-Map → null, surrounding logic identical):
  HomeFragment.fillSession, AttendanceFragment.loadStatus,
  ReportFragment (both sites), WeeklyGridActivity, 
  AttendanceRegisterActivity, StudentDetailActivity.

### 5. Kept from v1.0.9
Chips row (52dp MaterialButtons), Back→Home callback, tightened register
table, font line-spacing fixes — all untouched.

## Self-checks (local, pre-CI) — v1.0.10

- All 50 res XML files parse (ElementTree); 0 malformed.
- Every @color/@drawable/@style/@string/@layout/@menu reference in
  layouts/themes resolves (only checker "misses" are chip_text /
  nav_colors — res/color selector resources, present, as before).
- All R.* references in Java resolve (framework exceptions only:
  android.R.id.content, android.R.layout.simple_spinner_dropdown_item,
  and the nav* ids defined in menu/bottom_nav.xml — same as v1.0.9).
- findViewById ⊆ layout ids: 0 missing; the restructured attendance
  ids keep their exact view types (Buttons/TextViews).
- String key sets identical across the 3 locales (161/161/161); no new
  strings added.
- `app:inset` attributes: 0. `bg_backdrop` references: 0 (file deleted).
- Elevation audit: no screen/sheet root above 3dp; exceptions listed in
  item 2 above (banner bars 4dp, students bg_table 6dp, nav 8dp).
- No unchecked `(Map) doc.get(...)` casts remain; no getTimestamp /
  getString("madrasaName") reads remain in Db.
- Upload zip: `~/workspace/your_files/madrasa-project.zip` — 136 entries (v1.0.9's 137 minus the deleted bg_backdrop.xml), **1,934,752 bytes, sha256 1636b32579f942bd5ffbe2bc9463d199f570de501d723e9a5f88e85bcd901757**
  (bin-b64/ and .github/ excluded, same recipe as before).

---

## v1.0.10 — CI result + local signing + verification battery (2026-10-28, Run #13)

- **Run #13 (40636370315) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/40636370315
  (manually re-triggered on commit 297bb38 after Run #12 was cancelled
  at the owner's earlier instruction and then un-cancelled by his
  newer order — same commit, same zip as the v1.0.10 code-phase entry
  above; Run #11 was the cancelled workflow-only run.)
  Prerelease `v1.0.10-ci` carried the unsigned APK (5,456,567 bytes,
  sha256 7e6115bb3e1a29e5f78cb47a85a96cf488fc51c27fcb941a6aff7edcadd39cec).
  Note: the release asset took ~1 minute to become visible via the API
  after the run completed (eventual consistency) — the asset is
  present and byte-count exact.
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk` (overwrites v1.0.9)
  **Size: 5,548,440 bytes — sha256 b292c86d76298bce38548c3d806bce02b19aa3865ff62c601127e4867454752c**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true** (v3 also true); cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 11 / versionName 1.0.10** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. Merged manifest again carries the same 2 standard
  AGP/library entries as v1.0.7–v1.0.9 (READ_GSERVICES,
  DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION).
- **ComponentDiscoveryService ×1 with all 9 registrars** (same set as
  v1.0.7–v1.0.9) — every registrar DEFINED with **public `<init>()V`**
  AND **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with public
  `<init>` plus create-shaped `(Context)Object` and dependencies-shaped
  `()List` methods (R8-renamed, shape-verified) ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; manifest components
  22, component-name duplicates = **0** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every listed implementation class is defined in the dex and reaches
  its service interface through the superclass/interface chain
  (implementations carry R8-renamed names, as before) ✓
- **grpc/okhttp stack present (renamed, as v1.0.7–v1.0.9)**: total
  defined classes **5,177** (identical to v1.0.9); protobuf kept its
  names exactly (**102 = 102**); the dex string pool carries the
  OkHttpChannelProvider runtime messages ("Failed to find
  OkHttpChannelProvider", "Failed to construct OkHttpChannelProvider",
  …) and 23 `io.grpc` string occurrences ✓
- App referenced-vs-defined: bytecode-level scan of all defined
  app classes (hierarchy + method protos + instruction type/field/
  method references) found 365 distinct referenced class types,
  **0 missing** outside the framework ✓
- findViewById ⊆ layout ids: 137 `R.id` references in Java vs 293 ids
  defined in the APK's compiled layouts+menus; **0 missing** (the only
  non-layout id, `android.R.id.content`, is framework) ✓
- Strings in the APK itself: **161/161/161** — every one of the 161
  source string names is present in the default, en and ar configs ✓
- CNIC occurrences in dex strings + resource values: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 42 classes named in binary XML; 41/41 app+library
  classes DEFINED, 0 missing** (the one remaining name,
  `android.widget.Space`, is a framework class resolved from the
  Android boot classpath). Layout-named views lacking a
  (Context, AttributeSet) constructor: **0** ✓
- **No stale hardcoded version numbers**: app string values containing
  1.0.6/1.0.7/1.0.8/1.0.9 = **0** in resources; exact dex strings
  "1.0.6"/"1.0.7"/"1.0.8"/"1.0.9" = **0**; "1.0.10" occurs exactly once
  in the dex — `BuildConfig.VERSION_NAME` ✓

### v1.0.10-specific checks
- **No `bg_backdrop`**: occurrences in the resources dump = **0** and
  in the APK file list = **0** (file deleted, window background is the
  flat cream color again) ✓
- **Bottom nav above the sheet**: the compiled `activity_main` layout
  (res/v9.xml) — the sheet `LinearLayout` carries **no elevation
  attribute at all** (absent → 0; root background is the flat
  `@color/green_deep`), while `SixBottomNavigationView` carries
  `android:elevation=8.0dp` and `app:labelVisibilityMode=0x1`
  (`LABEL_VISIBILITY_LABELED`) — the bar now renders above the sheet
  with all 6 labels visible ✓
- **Attendance sessions compact row**: the compiled
  `fragment_attendance` layout (res/US.xml) holds, directly under the
  date button, a **horizontal `LinearLayout` (orientation=0) with two
  sibling vertical cards**; ids appear in tree order dateBtn →
  morningStatus → morningBtn → eveningStatus → eveningBtn →
  weeklyBtn — all six ids present, weeklyBtn below the row ✓
- **Attendance chips unchanged**: the compiled `item_register_row`
  layout (res/Ho.xml) still holds exactly **3
  `com.google.android.material.button.MaterialButton`** chips ✓
- **Back→Home compiled in**: `MainActivity$1` extends the R8-renamed
  OnBackPressedCallback (`Landroidx/activity/n;`, same as v1.0.9) and
  retains its `handleOnBackPressed` method in the dex ✓
- **No layout root above 8dp**: layout roots carrying any elevation
  are only item_ayah (3dp), item_register_row (3dp), item_user_row
  (3dp) and layout_madrasa_header (4dp) — the sanctioned bg_card /
  banner-bar exceptions from the code-phase entry; **none above
  8dp** ✓

No check failed. Runtime confirmation rests with the standing final
gate: the owner's phone test.

## v1.0.11 — code phase (2026-10-31)

Owner-ordered round with exactly four items. versionCode 12 /
versionName "1.0.11" in app/build.gradle. Project zip rebuilt:
1,939,127 bytes, sha256 eba81284b662aa7a93488db8497e180ec9899a2bd943e606abe871e795d22ce4 (136 entries; the copy inside the zip carries the ZIPFACTS placeholder, per house pattern).

### Item 1 — register table: nothing truncated
Column order unchanged. Header (fragment_students.xml) and row
(item_student_row.xml) now share weights serial 0.8 / dates 2.9 /
reg 1.4 / name 3.1 / completion 0.9 / duration 0.9 (was
0.9/2.3/1.4/2.8/1.3/1.3). All `singleLine`/`ellipsize` removed from
the row file (count after change: 0/0). Name: maxLines 2, 15sp bold;
father: maxLines 2, 12sp, "ولد …" prefix unchanged; admission + DOB:
maxLines 1 at 12sp; age: maxLines 2 at 11.5sp (composed string is
`age_lbl + ": " + age_years_months` = «عمر: 16 سال 5 ماہ»); reg:
maxLines 2 at 12sp; completion/duration: maxLines 3 at 10.5sp with
breakStrategy="simple" (values are almost always "—"; a full date
wraps instead of being cut). Photo shrunk 30dp -> 26dp, name-cell
text starts 4dp after it. Students fragment side padding 12dp -> 8dp.
Header sizes: 11sp (serial/dates), 12sp (name), 10sp (reg), 10.5sp
(completion/duration), lineHeight 18dp; header labels wrap at spaces
only — no header cell carries singleLine/ellipsize.

Fit math (360dp screen, item 2's 16dp sheet inset applied):
sheet width = 360 - 2*16 = 328dp; fragment padding 8dp x2 -> 312dp;
table frame padding 2dp x2 -> 308dp; five 1.5dp rules -> 300.5dp of
column space; weights sum 10.0 -> 30.05dp per unit. Columns:
serial 24.0dp, dates 87.1dp (text 79.1dp after 2x4dp cell padding),
reg 42.1dp, name 93.2dp (text 55.2dp after padding+26dp photo+4dp
gap), completion 27.0dp, duration 27.0dp.
- Dates: "2013-05-15" = 10 Latin glyphs; digit advance at 12sp
  ~6.7dp (0.556em) -> ~67dp <= 79.1dp, ~12dp slack, ONE line.
- Age «عمر: 16 سال 5 ماہ» at 11.5sp ~ <=75dp worst case -> one line
  typically; maxLines 2 guarantees it can never be cut.
- Name at 15sp bold (Urdu advance ~0.47em ~ 7.0dp/char): ~7.9
  chars/line x 2 lines ~ 15+ chars; «محمد عبداللہ» = 12 chars fits.
- Father at 12sp (~6.0dp/char): ~9.2 chars/line x 2 ~ 18 chars;
  «ولد قاری سمیع اللہ» = 18 chars fits.
- Header's longest word «رجسٹریشن» (8 chars) at 10sp, worst-case
  0.5em advance -> ~40dp <= 42.1dp, one word per line; «نمبر» at
  11sp -> ~22dp <= 24.0dp; completion header words ~26.3dp <= 27.0dp.

### Item 2 — sheet pulled back further
Every bg_sheet root's layout_margin 8dp -> 16dp (verified by scan:
activity_main, activity_auth, activity_not_authorized,
activity_register, activity_student_detail, activity_student_edit,
activity_users, activity_weekly — all 16dp). The inset lives in the
use-site margins, not in bg_sheet itself; the drawable only gained
radius 26dp -> 28dp. Sheet roots still carry NO elevation (flat,
v1.0.10 rule). Bottom nav in activity_main: side margins 14dp ->
16dp (aligned with the sheet's new edge), bottom margin 12dp ->
20dp so the card's bottom edge rests 4dp inside the sheet's lower
edge, exactly the v1.0.10 relationship; elevation 8dp and
labelVisibilityMode="labeled" untouched; fragment container bottom
padding stays 68dp (nav top now reaches ~62dp above the sheet's
bottom edge, still covered).

### Item 3 — camera photo straight (EXIF)
Db.saveCompressed (Db.java:249ff) is the single funnel for BOTH
sources — StudentEditActivity hands it the camera FileProvider Uri
and the gallery content Uri, and uploadPhoto() uploads the local
file this method writes. It now (Db.java:258-273) reads
TAG_ORIENTATION via android.media.ExifInterface(InputStream)
(minSdk 26 OK) from a separate stream, decodes, then
applyExifOrientation (Db.java:285ff) rotates/flips the bitmap
(all 8 orientation values) BEFORE the 720px scale + JPEG compress.
The bytes written to photos/<id>.jpg — and therefore the uploaded
bytes — are the orientation-corrected bitmap. No-EXIF/read-failure
falls back to ORIENTATION_NORMAL (previous behaviour). Previously
saved photos are untouched, as specified.

### Item 4 — attendance not automatic
AttendanceRegisterActivity.load(): the default is GONE — a student
with no saved mark gets NO entry in the marks map (was
`v == null ? Db.MARK_PRESENT : ...`). onBindViewHolder: `cur` is
now `marks.get(s.id)` (null = unmarked -> all three chips render in
the unselected soft style via the existing styleToggle, since
MARK_*.equals(null) is false). updateTotals() counts marks.values()
— only selected marks exist in the map, so only they are counted.
save() writes `new HashMap<>(marks)` — unselected students get no
entry in Firestore. Reopen shows saved marks selected, others
unselected. «سب کو حاضر کریں» (line 70) still fills the map — an
explicit tap, unchanged. Long-press excluded behaviour unchanged.
Grep proof (AttendanceRegisterActivity): remaining MARK_PRESENT
uses are only line 70 (mark-all), the totals counter, the chip
style/pick handlers — no default in the load or bind path.
Other readers audited — NONE treats a missing mark as present, no
reader fix needed: HomeFragment and AttendanceFragment iterate
marks.values() counting "P"; ReportFragment iterates entries the
same way (x2); WeeklyGridActivity: missing mark falls to the
day_none letter; StudentDetailActivity gates on
marks.containsKey(studentId) before reading.

### Local checks (code phase)
- 50 res XML parsed, 0 malformed; strings 161/161/161, key sets
  equal (no new strings); app:inset occurrences 0.
- findViewById ids missing from layouts: 0; unresolved R.id only
  android.R.id.content (framework). No Java id/type changes were
  made in this round (layout attributes + Db/register logic only).
- Layout ROOT elevations: only the sanctioned item/header roots
  (3dp/3dp/3dp/4dp); no root above 8dp. (The students table
  container's inner 6dp from v1.0.8 is not a root and is unchanged.)
- Header and row column weights verified identical.

### v1.0.11 ADDITION — Forgot password (owner-ordered, same build, 2026-10-31)

Mechanism findings (inspected before implementing): account creation
(UsersActivity.createAccount) builds a secondary FirebaseApp ("secondary",
FbConfig options) and createUserWithEmailAndPassword on it, then writes the
user doc at madrasa_users/<NEW AUTH UID> with {name, email=pseudoEmail,
role, loginType:"mobile", mobile:canonical}; the main session is untouched.
Login (v1.0.10 and earlier) derived the sign-in email directly:
AuthHelp.pseudoEmail(canonicalMobile). Splash routes via
madrasa_users.document(CURRENT auth uid) — user docs are KEYED BY AUTH UID
and carried NO uid/authEmail fields (identity = doc ID + the "email"
field). config/setup.ownerUid is written at setup and read nowhere.
whereEqualTo is used nowhere in the codebase; user lookups are
full-collection reads matched in memory (UsersActivity.load).

DEVIATION from the original design sketch (forced by the code above,
closest working variant): the reset cannot "update uid + authEmail fields
in place" — there is no uid field and the doc ID itself is the uid. So
AccountReset MOVES the doc to the new uid in one WriteBatch
(set users/<newUid> + delete users/<oldUid>); in the moved doc the ONLY
changed values are the identity fields "email" and the new "authEmail"
(both = the new unique pseudo-email) — every other field is copied
verbatim. If the replaced account is the owner, config/setup ownerUid +
ownerEmail move in the same batch. The invariant doc-ID == auth-uid that
Splash/Login rely on is preserved, so the chain (auth uid → doc) keeps
working for legacy docs (never moved) and replaced identities alike.

Implemented:
- AccountReset.java (new): unique pseudo-email <canon>.<6 SecureRandom
  alphanumerics>@madrasa.local; secondary-app createUser (UsersActivity
  technique); doc move batch; secondary signOut+delete on all paths.
- ForgotPasswordActivity.java + activity_forgot.xml (new; registered in
  the manifest, exported=false; sheet root mirrors activity_auth; Back =
  normal stack return to Login). Stage 1: mobile → lookup by the doc's
  mobile field (full-collection read, instanceof-safe). Stage 2 (only
  when recoveryHash present): code + new password; verify
  AuthHelp.recoveryHash = SHA-256 hex of (canonicalMobile + ":" + code);
  wrong code = plain error, no state change. On success: AccountReset,
  then MAIN-auth sign-in with the new email + password and routing
  identical to Login (doc exists → session + Main; else NotAuthorized;
  sign-in hiccup → Login, where the new password works). No recoveryHash
  or unknown number → ONE uniform message (forgot_teacher_help).
- LoginActivity: «پاس ورڈ بھول گئے؟» link (forgotLink added to
  activity_auth.xml, gone by default — SetupActivity shares the layout
  and never shows it). Sign-in email is now RESOLVED from the user doc
  (by mobile): authEmail → legacy email → derived pseudoEmail; lookup
  failure falls back to the derived pseudoEmail, so the legacy path is
  byte-for-byte the old behaviour when authEmail is absent. After a
  successful sign-in, a doc lacking authEmail is backfilled with the
  email just used (fire-and-forget update).
- Settings: recovery-code card for EVERY signed-in user (fragment_
  settings.xml recoveryBtn + SettingsFragment.showRecoveryDialog).
  Choice recorded: being signed in is enough (no password re-entry) —
  the write touches only the user's own doc. Code (min 4 chars, trimmed)
  is stored ONLY as recoveryHash = SHA-256(canonMobile + ":" + code);
  the mobile comes from the user's own doc.
- UsersActivity (teacher only): tapping a user row (never the teacher's
  own row) opens «نیا پاس ورڈ بنائیں» → new password (min 6) →
  AccountReset.replacePassword with the row's full doc data → success
  toast reset_done_teacher (teacher conveys the password himself) +
  list reload. Delete behaviour untouched.
- AuthHelp.recoveryHash added. Strings: +16 keys in ALL THREE locales
  (forgot_password, forgot_title, forgot_desc, forgot_continue,
  forgot_teacher_help, recovery_code_lbl, new_password,
  change_password_btn, err_recovery_wrong, recovery_desc, recovery_btn,
  recovery_hint, recovery_short, recovery_saved, reset_password_title,
  reset_done_teacher) — counts now 177/177/177, key sets equal.

Local checks (this addition): 52 res XML parse, 0 malformed; strings
177/177/177 equal sets; every new findViewById resolves with a matching
layout class (ForgotPasswordActivity 10/10, LoginActivity forgotLink,
SettingsFragment recoveryBtn); app:inset = 0; manifest carries
.ForgotPasswordActivity; grep proof of the legacy fallback
(LoginActivity lines 74 + 77: pseudoEmail(canon) on absent authEmail and
on lookup failure); grep proof the reset's only changed values are
email + authEmail (AccountReset data.put ×2, everything else putAll of
the old doc). Version unchanged: vc12 / "1.0.11".

Refinement (owner, same day): the recovery code has NO fixed length.
It is a normal single text field on both screens (Settings dialog +
ForgotPasswordActivity stage 2) — no PIN boxes, no length== validation
anywhere (grep-verified: the only code-length check is the minimum,
SettingsFragment `c.length() < 4`; the `< 6` checks are the Firebase
password minimum, unrelated). Minimum 4 characters, no fixed length,
sane cap 64 (LengthFilter in the Settings dialog, android:maxLength=64
on the forgot screen). Helper text recovery_len_hint under/above the
field on both screens says the user may choose as long a code as they
wish. The hash (SHA-256 of canonicalMobile + ":" + code) is
length-agnostic, unchanged. Strings now 178/178/178 (+recovery_len_hint
in all three locales, sets equal); XML 52 files, 0 malformed.

---

## v1.0.11 — CI result + local signing + verification battery (2026-10-31, Run #15)

- **Run #15 (41170007541) — SUCCESS:**
  https://github.com/yousuf0313/Madrasa-Record/actions/runs/41170007541
  (commit e3fb805; run started ~09:48 PKT 2026-10-31, completed ~09:52.)
  Prerelease `v1.0.11-ci` carried the unsigned APK (5,475,519 bytes,
  sha256 6fe838d0b52fdbfa3bf55ee6144e698ec301a02064f6d02a522b2d8bd68e0a7a).
- **Signed locally** (zipalign + apksigner, `~/workspace/madrasa-app/madrasa.keystore`):
  `~/workspace/your_files/Digital-Asan-Hazri-Register.apk` (overwrites v1.0.10)
  **Size: 5,568,976 bytes — sha256 e2a26a0b5fe790d13ef2d3dc2211da1de095b26da2e0e05dc0d15e1d0f03aa1f**

### Battery results (on the signed APK)
- apksigner: **v2 scheme true** (v3 also true); cert SHA-256 =
  `3f3a4aed08067f94e34f270197c09878cc32e8605648c94003ec8b170305636c` (exact
  match); `zipalign -c` OK.
- **versionCode 12 / versionName 1.0.11** ✓
- Permissions: app-declared **exactly 3** (INTERNET, ACCESS_NETWORK_STATE,
  CAMERA) ✓. Merged manifest again carries the same 2 standard
  AGP/library entries as v1.0.7–v1.0.10 (READ_GSERVICES,
  DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION).
- **ComponentDiscoveryService ×1 with all 9 registrars** (auth,
  firestore ×2, storage ×2, appcheck ×2, firebase-common ×2 — real
  class names read from the manifest meta-data) — every registrar
  DEFINED with **public `<init>()V`** AND **`getComponents()`** ✓
- **InitializationProvider ×1 with 3 initializers** (EmojiCompat,
  ProcessLifecycle, ProfileInstaller) — each defined with public
  `<init>` plus create-shaped `(Context)Object` and dependencies-shaped
  `()List` methods ✓
- All 3 manifest providers (FileProvider, FirebaseInitProvider,
  InitializationProvider) defined with `onCreate()Z`;
  ComponentDiscoveryService + CoreComponentFactory defined;
  **appComponentFactory present** ✓
- Merged-manifest `"${"` placeholder scan = **0**; manifest components
  **23** (v1.0.10's 22 + ForgotPasswordActivity), component-name
  duplicates = **0**; **all 23 component classes DEFINED in the dex** ✓
- **META-INF/services present and fully consistent**: 5 service files;
  every listed implementation class is defined in the dex and reaches
  its service interface through the superclass/interface chain ✓
- **grpc/okhttp stack present (renamed, as before)**: total defined
  classes **5,192** (v1.0.10: 5,177; +15 = the forgot-password round's
  new classes); protobuf kept its names exactly (**102 = 102**); the
  dex string pool carries the OkHttpChannelProvider runtime messages
  and 23 `io.grpc` occurrences ✓
- App referenced-vs-defined: bytecode-level scan of the app classes
  (hierarchy + method protos + field types + instruction type/field/
  method references) found 394 distinct referenced class types,
  **0 missing** outside the framework ✓
- findViewById ⊆ layout ids: 148 `R.id` references in Java vs ids
  defined in the source layouts/menus; **0 missing** (the only
  framework id used is `android.R.id.content`) ✓
- Strings in the APK itself: **178/178/178** — every one of the 178
  source string names is present in the default, en and ar configs,
  including all 17 forgot-password keys ✓
- CNIC occurrences in dex strings + resource values: **0** ✓
- Fonts: **16 present, 16 parseable** (fontTools) ✓
- app_name: «ڈیجیٹل آسان حاضری رجسٹر» (default/ar), "Digital Asan Hazri
  Register" (en) ✓
- **XML gate: 6 fully-qualified classes named in the app's binary
  layouts** (RecyclerView, MaterialButton, FloatingActionButton,
  TextInputLayout, TextInputEditText, SixBottomNavigationView) —
  **all DEFINED, 0 missing**; layout-named views lacking a
  (Context, AttributeSet) constructor: **0**. (The layouts' remaining
  element names are framework shorthand tags — LinearLayout, TextView,
  FrameLayout, ScrollView, etc. — resolved from the Android boot
  classpath, exactly as in prior rounds.) ✓
- **No stale hardcoded version numbers**: exact dex strings
  "1.0.6"/"1.0.7"/"1.0.8"/"1.0.9"/"1.0.10" = **0**; "1.0.11" occurs
  exactly once in the dex — `BuildConfig.VERSION_NAME` ✓

### v1.0.11-specific checks
- **(a) Register row fit**: the compiled `item_student_row` layout
  (res/Sk.xml) contains **no `ellipsize` and no `singleLine`
  attribute** anywhere; the column row's cell weights, in order, are
  exactly **0.8 / 2.9 / 1.4 / 3.1 / 0.9 / 0.9** (serial / dates / reg /
  name / completion / duration), and the `fragment_students` header
  row carries the identical weight sequence ✓
- **(b) Sheet pulled back**: all **8 bg_sheet roots** (activity_main,
  activity_auth, activity_not_authorized, activity_register,
  activity_student_detail, activity_student_edit, activity_users,
  activity_weekly) carry `layout_margin=16.000000dp` in the compiled
  layouts, with no elevation on the sheet; the bottom nav in
  activity_main carries `layout_marginBottom=20.000000dp`, side
  margins 16dp, `elevation=8.000000dp` and
  `labelVisibilityMode=1` (`LABEL_VISIBILITY_LABELED`) ✓
- **(c) EXIF photo straightening**: the dex defines
  `com.madrasarecord.app.Db` with an `applyExifOrientation` method,
  and Db's code items reference `Landroid/media/ExifInterface;` —
  the orientation-correction path is compiled in ✓
- **(d) Forgot password**: `ForgotPasswordActivity` appears exactly
  once as a manifest activity **and** is defined in the dex; the
  compiled `activity_auth` layout (res/G4.xml) contains the
  `forgotLink` id (0x7f0800df); `layout/activity_forgot` is compiled
  in; the dex string pool carries `authEmail` and `recoveryHash`;
  strings are 178 per locale (see above) ✓
- **(e) No bg_backdrop / no tall roots**: `bg_backdrop` occurrences in
  the APK file list and the resource table = **0**; layout roots
  carrying any elevation are only item_ayah (3dp), item_register_row
  (3dp), item_user_row (3dp) and layout_madrasa_header (4dp) — the
  sanctioned bg_card / banner-bar exceptions; **none above 8dp** ✓

No check failed. Runtime confirmation rests with the standing final
gate: the owner's phone test.

## v1.1.0 — implementation (2026-11-05, code phase; CI run pending)

Full redesign to the APPROVED preview (artifact space-7, approved by the
owner 2026-11-05 07:53 PKT: «اب بلڈ کر دو، یہ زبردست بنا ہوا ہے»).
versionCode 13 / versionName "1.1.0" in app/build.gradle. Package,
keystore, FbConfig manual init, google-services non-use, Firestore
rules, and the UpdateCheck catalog id are all unchanged.

### What was implemented
- **Blue design system**: colors.xml rewritten (navy #14479E / navy-deep
  #0B2A63 / navy-mid #1D5CC4, page bg #E8EEFB, surface white, idbox
  #BFD7F8 + border #8FB0E6, gold #C19A1F, green #1E9E57, red #D43A2F,
  amber #D9930D, purple #7B4FD0); legacy color names re-pointed so old
  references compile. New drawables: bg_navy_header, bg_idbox, mark
  cells (p/a/l/none), summary pill, waqt dots, status chips, dotted
  signature line, sub-tab states. Flat rendering (no new elevations).
- **5 bottom tabs**: حاضری (ClassFragment, home) / وقت حاضری / سبق حاضری /
  رپورٹ / ترتیبات; labelVisibilityMode stays LABELED. Class tab hosts the
  sub-views حاضری | رجسٹر | 🎓 فارغ التحصیل. Deleted: HomeFragment,
  AttendanceFragment, AyatFragment, AttendanceRegisterActivity + their
  layouts + the manifest entry.
- **کلاس حاضری**: 3 sessions (morning/midday NEW/evening) on one screen;
  boxed rows [نام idbox][ولدیت idbox][36dp صبح][دوپہر][شام]; tap cycles
  حاضر ✓ → غیر حاضر ✕ → رخصت ر → خالی; manual only (nothing pre-marked);
  every tap saves immediately (Db.saveMark, set-merge on the day doc);
  per-session «سب کو حاضر»; slim content-width summary pills; Gregorian
  date picker; dual-date header; long-press (teacher) removes a student
  from the whole day's register (excluded honoured on load).
- **وقت حاضری**: punc_morning/punc_midday/punc_evening docs in the same
  madrasa_attendance collection; per session two 40dp dots (وقت پر green
  / لیٹ amber), tap toggles, auto-save. **سبق حاضری**: per-student cards,
  session key "lesson", values ontime/late/none, three status chips.
- **Roles**: MadrasaApp.canMark() = teacher only; canManage() = any
  signed-in role. Muhtamim gets add/edit/delete students,
  graduate/reactivate, reports, settings, backup/restore, users,
  madrasa-name — everything except marking (marking UIs render
  read-only with the preview's no-mark note; write paths gate on
  canMark as well).
- **Login**: prominent «نیا اکاؤنٹ بنائیں» under the login button →
  CreateAccountActivity (name/mobile/password/recovery code/madrasa
  name; secondary-app creation like UsersActivity; user doc with
  recoveryHash; config madrasaName merge only — owner fields untouched;
  immediate sign-in). SetupActivity gained the same recovery + madrasa
  fields (recovery stored as hash on the first teacher too).
  Mobile+password only; no email field; no SMS/OTP; no CNIC anywhere.
- **Student record page**: navy photo header + chips; 3 sections
  (ذاتی معلومات / رابطے کی تفصیل tap-to-call / داخلہ و تکمیل) with dual
  dates; edit + delete here (both roles). **عہد نامہ section**: full
  pledge text («مدرسہ سیدنا فاروق اعظم» in clause 2), note, three BLANK
  dotted signature lines, per-student checkbox striking clause 2 in red
  (stored pledgeClause2Struck, merged on toggle), print = pledge only
  (WebView print adapter). History counts CLASS sessions only.
- **Alumni**: «فارغ التحصیل قرار دیں» dialog (completion date + کیا مکمل
  کیا → graduated/completionDate/completionLabel on the doc);
  «واپس فعال کریں» keeps completion details. Graduated students are
  filtered out of all 3 attendance tabs, the active register, the
  report (incl. weekly counts) and the weekly grid; the فارغ التحصیل
  sub-view shows the total count + list and opens full records.
- **Dual dates + Hijri**: new Hijri.java — android.icu IslamicCalendar,
  ISLAMIC_UMALQURA, conversion via UTC epoch millis (Calendar.set would
  misinterpret the fields); Pakistani-Urdu month names fixed list;
  suffix ھ / هـ / AH per locale; offset from madrasa_config/setup
  hijriOffsetDays, loaded at splash/sign-in/main; HijriAdjust dialog
  (±1 day buttons, clamp −10..+10, live preview, save, «خودکار پر واپس»)
  opened from all three attendance headers. Independent sanity check:
  2026-11-05 → 25/5/1448 (جمادی الاولی) at offset 0 ✓.
- **Register**: preview column weights 0.6/3.0/0.9/2.8/1.4/1.3; header
  labels shrink-to-fit one line (never split mid-word); dates DUAL —
  Gregorian one line + Hijri on its own shrink-to-fit line (font
  padding left ON, no hard clip); completion cell shows dual date +
  completionLabel in green, else «ابھی جاری»; NO delete in register
  rows (long-press menu removed); NO ayat/hadith block on this screen.
- **Names one line**: Ui.fitOneLine shrinks text size (floor 8sp) until
  the complete name/father fits one line in attendance rows, waqt rows,
  sabaq cards, graduate rows and register Hijri lines.
- **«آج کی آیت و حدیث» page**: DailyActivity from the TOP of Settings
  (not a tab, not on the register screen); large bold Hijri (gold) +
  Gregorian (white) in a navy card; verse + hadith cards, Arabic in
  Naskh (Ui.applyNaskh after the font pass). Content.java replaced with
  the preview's 30 AYAT + 30 AHADITH verbatim; rotation by epoch-day,
  identical to the preview.
- **Report**: «آج کی رپورٹ — dual date», 3 session blocks (totals incl.
  unmarked + absent names), last-7-days table (reversed, dual date +
  per-session حاضر/غیر حاضر/رخصت) — the range query FILTERS to class
  sessions so punc_*/lesson docs never pollute counts. WeeklyGrid
  extended to 3 sessions, graduated filtered out.
- **Settings order**: daily-page entry → guide (10 preview topics,
  accordion) → backup/restore → language/font/recovery → madrasa name →
  users → about/update/sign-out. Backup = one JSON (students incl.
  pledgeClause2Struck/graduated/completionLabel + createdAt as
  Timestamp; ALL attendance docs; config madrasaName +
  hijriOffsetDays), CreateDocument/OpenDocument; restore replaces
  students + attendance in chunked batches, merges the two config
  keys, never touches accounts.
- **Font**: genuine Jameel Noori Nastaleeq bundled
  (assets/fonts/JameelNooriNastaleeq.ttf, subsetted Arabic+Latin) and
  made the default script font (id "jameel"; stored "nastaliq" ids fall
  back to it). The rejected font's file was DELETED from assets and all
  references removed. Arabic scripture stays Naskh.
- **Back rule** unchanged: any tab → حاضری home; home → exit.
- **Strings**: +97 keys × 3 locales (275/275/275, identical key sets) —
  nav labels, midday, punctuality/lesson labels, alumni, pledge,
  Hijri adjustment, daily page, the preview's 10-topic guide (ur/en/ar),
  backup. Guide topic 2's register-delete clause was aligned to the
  owner's later order (delete only from the student page).

### Local static checks (pre-CI)
- XML well-formedness: 77 files (all res + manifest) parse ✓
- Strings parity: 275 / 275 / 275, identical key sets ✓
- Unresolved references sweep (Java R.* after android.R exclusion,
  layout @string/@drawable/@color/@layout): 0 / 0 ✓ — this sweep caught
  and fixed a real bug: the new bottom_nav referenced ic_attendance /
  ic_report / ic_settings; the files are ic_nav_attendance /
  ic_nav_report / ic_nav_settings.
- findViewById ⊆ layout ids: covered by the same sweep (0 unresolved) ✓
- CNIC scan over java + res: 0 ✓
- `app:insetTop|insetBottom` grep: 0 ✓
- Rejected-font grep (name + file): 0 in source/res; asset file absent;
  assets/fonts holds exactly 16 fonts, all referenced ones present ✓
- Font verification (fontTools on the INSTALLED subset): internal name
  IDs 1/4/6 = "Jameel Noori Nastaleeq"; coverage True for Urdu
  (ب ٹ ڑ ے ھ ۃ), Arabic marks (fatha etc.), Latin digits 0/5/9, Latin;
  GSUB/GPOS/GDEF present; 10,249,808 bytes ✓
- javac (JDK 17, android-34 android.jar only): 0 syntax errors across
  all sources; remaining errors are classpath-only (androidx/Firebase/
  R/BuildConfig), as expected without Gradle ✓
- Zip contents: versionCode 13 / versionName "1.1.0" read back from the
  zipped app/build.gradle; gradle-wrapper.jar present; Jameel font
  present; bin-b64/.github absent ✓

### Package
- Zip: ~/workspace/your_files/madrasa-project.zip (size + sha256 in the
  delivery note accompanying this section).
- Workflow: ~/workspace/your_files/bootstrap-build-1.1.0.yml — from the
  1.0.11 template with ALL version strings replaced (tag v1.1.0-ci,
  asset Digital-Asan-Hazri-Register-v1.1.0-unsigned.apk) AND the
  extract-step font check repointed to JameelNooriNastaleeq.ttf
  (reusing the old workflow verbatim would have failed the extract
  step, the 1.0.11 file's font test named the deleted font).

Runtime confirmation rests with the standard gates: CI battery on the
compiled APK, then the owner's phone test.
